#
# Copyright (c) 2021 Qualcomm Technologies, Inc. and/or its
# subsidiaries.  All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""Encapsulate trap calls for QCC514x."""
from ksp.lib.firmware.kymera import Kymera

class KymeraQCC514x(Kymera):
    """Trap calls for AuraPlus1.1"""

    def load_downloadable(self, index, download_type=0):
        """Loads the downloadable in the firmware.

        Args:
            index (int): The file index which is found using find_file
                method.
            download_type (int): This value is being ignored.

        Return:
            int: handle for the loaded downloadable.

        Raises:
            FirmwareError: Some unexpected happen in the firmware.
        """
        return super().load_downloadable(index, 0)
