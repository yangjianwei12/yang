#
# Copyright (c) 2021 Qualcomm Technologies, Inc. and/or its
# subsidiaries.  All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""Encapsulate trap calls for QCC307x and QCC507x."""
from ksp.lib.firmware.kymera import Kymera


class KymeraQCC307xQCC517x(Kymera):
    """Trap calls for QCC307x and QCC517x"""

    def load_downloadable(self, index, download_type=0):
        """Loads the downloadable in the firmware.

        Args:
            index (int): The file index which is found using find_file
                method.
            download_type (int): This value will be ignored if it is QCC307x and
                other value is something other than 0.

        Return:
            int: handle for the loaded downloadable.

        Raises:
            FirmwareError: Some unexpected happen in the firmware.
        """
        bdl = super().load_downloadable(index, download_type=download_type)
        if not bdl and download_type != 0:
            # There is a good chance it is QCC307x, where there is no P1. Load
            # the downloadable exclusively for P0.
            bdl = super().load_downloadable(index, download_type=0)

        return bdl
