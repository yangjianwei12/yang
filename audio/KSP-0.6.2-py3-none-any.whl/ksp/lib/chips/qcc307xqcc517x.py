#
# Copyright (c) 2021 Qualcomm Technologies, Inc. and/or its
# subsidiaries.  All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""QCC3071 and QCC5171 Chip interface."""
import logging

from ksp.lib.chips.chipbase import GenericChip
from ksp.lib.firmware.kymera_qcc307xqcc517x import KymeraQCC307xQCC517x
from ksp.lib.logger import method_logger

logger = logging.getLogger(__name__)


class QCC307xQCC517x(GenericChip):
    """KSP Emulator for QCC5171 and QCC3071 Chip types.

    Full version:      0x2050
    """
    @method_logger(logger)
    def __init__(self, device):
        super().__init__(device)

        _, apps1 = (
            device.chip.apps_subsystem.p0,
            device.chip.apps_subsystem.p1
        )
        self._firmware = KymeraQCC307xQCC517x(apps1)
