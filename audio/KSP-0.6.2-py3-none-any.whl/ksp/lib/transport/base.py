#
# Copyright (c) 2022 Qualcomm Technologies, Inc. and/or its
# subsidiaries.  All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""Transport base class."""
import abc


class Transport(abc.ABC):
    """Transport abstract class."""

    @property
    @abc.abstractmethod
    def total_bytes(self):
        """Total bytes received by the transport."""

    @abc.abstractmethod
    def start(self, filename, stop_event):
        """Reads raw data into file."""

    @abc.abstractmethod
    def stop(self):
        """Stop the transport transactions."""
