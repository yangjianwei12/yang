#
# Copyright (c) 2022 Qualcomm Technologies, Inc. and/or its
# subsidiaries.  All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""Module for capturing KSP packets sent by audio subsystem via TestTunnel."""
import logging
import sys

# Remove the pylint commands once the correct pydbg is updated in the requirements
# pylint: disable=no-name-in-module
from csr.test_tunnel.test_tunnel_protocol import get_test_tunnel
# pylint: enable=no-name-in-module
from csr.test_tunnel.trans_audio import TransAudio

from ksp.lib.transport.base import Transport

logger = logging.getLogger(__name__)


class TTTransport(Transport):
    """Reads KSP packets received from TestTunnel.

    Args:
        apps1 (object): Apps P1 subsystem.
        firmware (object): The firmware object of the audio.
        p0_op_id (int): The ID of the KSP operator on P0 to get data from.
        verbose (bool): Determine the output to be verbose or not.
        wait_time (float): The amount of time to wait in seconds before terminating
            the transport in case there is no data to receive.
    """

    def __init__(self, apps1, firmware, p0_op_id, **kwargs):
        wait_time = kwargs.pop('wait_time')
        self._firmware = firmware
        if wait_time:
            logger.warning("Test Tunnel does not support idle timeout.")

        self._verbose = kwargs.pop('verbose', True)

        self._sink_ep = None
        # Remove the pylint commands once the correct pydbg is updated in the requirements
        # pylint: disable=unexpected-keyword-arg
        self._tt_aud = TransAudio(apps1, get_test_tunnel(apps1), connect_accmd=False)
        # pylint: enable=unexpected-keyword-arg

        self._create_tester_ep(p0_op_id)

        self._total_bytes = 0
        self._tt_aud.start()
        logger.info("Connected to TestTunnel")

    @property
    def total_bytes(self):
        return self._total_bytes

    def _create_tester_ep(self, p0_op_id):
        """Create tester endpoint to transfer data through TestTunnel."""
        ksp_source = p0_op_id | 0x2000

        meta_len = 8
        self._sink_ep = self._tt_aud.create_source("TESTER", ksp_source, meta_len)["endpoint_id"]
        conn_id = self._firmware.connect_stream(ksp_source, self._sink_ep)
        logger.debug('conn_id=%s', conn_id)

    def _destroy_tester_ep(self):
        """Destroy tester endpoint."""
        logger.debug("Source to destroy: %s", self._sink_ep)
        self._tt_aud.destroy_source(self._sink_ep)

    def start(self, filename, stop_event):
        """Reads raw data into file.

        Args:
            filename (str): output file.
            stop_event (threading.Event): if true prints the number of bytes
                received so far. This is used when the reader used in a thread.
        """
        self._tt_aud.tt_data.start_file_from_source(self._sink_ep, filename)

        total_bytes_logged = 0
        while not stop_event.is_set():
            self._tt_aud.tt_data.wait_for_file_complete_poll([self._sink_ep])
            self._total_bytes = self._tt_aud.tt_data.endpoint_files[self._sink_ep]["bytes"]
            if self._total_bytes > total_bytes_logged + (1 << 14):
                total_bytes_logged = self._total_bytes
                if self._verbose:
                    sys.stdout.write(
                        "Bytes written to the output file: {0}\r".format(
                            self._total_bytes,
                        )
                    )
                    sys.stdout.flush()

    def stop(self):
        self._tt_aud.stop()

    def __del__(self):
        self._destroy_tester_ep()
