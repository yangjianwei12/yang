#
# Copyright (c) 2021 Qualcomm Technologies, Inc. and/or its
# subsidiaries.  All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""Module for capturing KSP packets sent by audio subsystem via TRB."""
import logging
import sys
import time

from trbtrans.trbtrans import Trb, TrbErrorBridgeLinkIsDown

from ksp.lib.exceptions import TransportError
from ksp.lib.transport.base import Transport

logger = logging.getLogger(__name__)


class TRBTransport(Transport):
    """Reads KSP packets received from transaction bridge.

    Args:
        device (str): TRB device name.
        device_id (str): The ID of the TRB device.
        wait_time (float): Timeout for waiting for data in seconds. To
            make it more precise, fraction of seconds is also possible.
    """
    # Number of transaction to poll each time.
    NUM_TRANSACTIONS = 100
    TIMEOUT_MS = 20

    SRC_BLOCK_ID = 0x7
    SRC_SUBSYS_ID = 0x3

    def __init__(self, device="scar", device_id=None, wait_time=None, verbose=True):
        self._trb = Trb()
        self._trb.sample_stream_open(device, dongle_id=device_id)
        logger.info(
            "Connected to device:%s:%s.",
            device,
            0 if device_id is None else device_id
        )
        self._wait_time = wait_time
        self._total_bytes = 0
        self._total_bytes_rem = 0
        self._output_filename = None

        self._verbose = verbose

    @property
    def total_bytes(self):
        """Total bytes received by the transport."""
        return self._total_bytes

    def start(self, filename, stop_event):
        """Reads raw data into file.

        Args:
            file_name (str): output file.
            stop_event (threading.Event): if true prints the number of bytes
                received so far. This is used when the reader used in a thread.
        """
        self._output_filename = filename
        self._record_transactions(stop_event)

    def stop(self):
        """Stop recording the data from the transport layer."""

    def _record_transactions(self, stop_event):
        last_read_time = time.time()
        while not stop_event.is_set():
            try:
                results = self._read_transactions()
            except RuntimeError as error:
                logger.error("Recording transactions has failed: %s", error)
                break

            try:
                if self._write(results):
                    last_read_time = time.time()
            except OSError as error:
                logger.error("Writing transactions has failed: %s", error)

            else:
                wait_time = time.time() - last_read_time
                if self._wait_time and wait_time > self._wait_time:
                    logger.warning(
                        "Terminating the reader after being idle "
                        "for %d seconds", self._wait_time
                    )
                    break

    def _write(self, results):
        written_any = False

        with open(self._output_filename, 'ab') as handle:
            for msg in results:
                if not self._check_msg(msg):
                    # The message is invalid, continue with the next one.
                    continue

                written_any = True
                payload = bytearray(msg.payload[1:])
                handle.write(payload)

                self._total_bytes += len(payload)
                self._total_bytes_rem += len(payload)
                if self._total_bytes_rem > (1 << 14):
                    self._total_bytes_rem -= (1 << 14)
                    if self._verbose:
                        sys.stdout.write(
                            "\rBytes written to the output file: {0}".format(
                                self.total_bytes
                            )
                        )
                        sys.stdout.flush()

        if self._verbose:
            sys.stdout.write('\r')

        return written_any

    def _read_transactions(self):
        try:
            results, _count, is_wrapped = self._trb.read_raw_transactions(
                self.NUM_TRANSACTIONS,
                timeout_millis=self.TIMEOUT_MS
            )
        except TrbErrorBridgeLinkIsDown as error:
            raise TransportError(error)

        if is_wrapped:
            raise RuntimeError(
                "TRB driver shows wrapping, read data is invalid. Reset "
                "the device."
            )

        return results

    def _check_msg(self, msg):
        if msg.timestamp == 0 and \
                msg.src_block_id_and_dest_subsys_id == 0 and \
                msg.opcode_and_src_subsys_id == 0 and \
                msg.payload[:] == [0] * len(msg.payload[:]):
            # It is a null transaction.
            return False

        # Check Source Block ID.
        m_src_block_id = msg.src_block_id_and_dest_subsys_id >> 4
        if self.SRC_BLOCK_ID != m_src_block_id:
            logger.warning(
                "Source Block ID not matching: %s.", m_src_block_id
            )
            logger.debug("msg=%s", self._msg_to_str(msg))
            # Source Block ID mismatch.
            return False

        # Check Source Subsystem ID.
        m_src_subsys_id = msg.opcode_and_src_subsys_id & 0xf
        if m_src_subsys_id != self.SRC_SUBSYS_ID:
            logger.warning(
                "Source Subsystem ID not matching: %s",
                m_src_subsys_id
            )
            logger.debug("msg=%s", self._msg_to_str(msg))
            # Source Subsystem mismatch.
            return False

        # Check flags, specific to KSP operator.
        if (msg.payload[0] & 0x3F) != 0x2C:
            logger.warning(
                "flags not matching: 0x{0:x}".format(msg.payload[0])
            )
            logger.debug("msg=%s", self._msg_to_str(msg))
            # Flags mismatch.
            return False

        return True

    @staticmethod
    def _msg_to_str(msg):
        """Converts the content of a TRB message to a readable string.

        Args:
            msg (TRB message): a received TRB message.

        Returns:
            str: The message content in a more human readable form.
        """
        m_src_block_id = msg.src_block_id_and_dest_subsys_id >> 4
        m_dest_subsys_id = msg.src_block_id_and_dest_subsys_id & 0xf
        m_opcode = msg.opcode_and_src_subsys_id >> 4
        m_src_subsys_id = msg.opcode_and_src_subsys_id & 0xf
        payload = msg.payload[:]

        msg_content = "src_block_id={0},".format(m_src_block_id)
        msg_content += "dest_subsys_id={0},".format(m_dest_subsys_id)
        msg_content += "opcode={0},".format(m_opcode)
        msg_content += "src_subsys_id={0},".format(m_src_subsys_id)
        msg_content += " ".join(["{0:02x}".format(val) for val in payload])

        return msg_content
