#
# Copyright (c) 2022 Qualcomm Technologies, Inc. and/or its
# subsidiaries.  All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""Transport factory and tools."""
import logging

from ksp.lib.exceptions import TransportError
from ksp.lib.logger import function_logger
from ksp.lib.transport.testtunnel import TTTransport
from ksp.lib.transport.trb import TRBTransport

logger = logging.getLogger(__name__)


@function_logger(logger)
def is_testtunnel(device):
    """Check whether a connected device is connected via Test Tunnel.

    Args:
        device (object):
    """
    if hasattr(device.transport, 'dongle_name'):
        return False

    return True


@function_logger(logger)
def get_transport(**kwargs):
    """Transport factory.

    Gets the parameters to instantiate a transport object and based on
    the parameters create a appropriate transport instance.

    Args:
        kwargs: Arbitrary keyword arguments. The accepted ones are:
            device, wait_time, verbose, apps1, firmware, p0_op_id.

    Returns:
        obj: An instance of a transport object.

    Raises:
        TransportError: When there is an unexpected keyword argument and
            the factory can not determine which transport it is.
        TransportError: Something goes wrong with instantiating from the
            transport object.
    """
    device = kwargs.pop('device', None)
    wait_time = kwargs.pop('wait_time', None)
    verbose = kwargs.pop('verbose', None)

    apps1 = kwargs.pop('apps1')
    firmware = kwargs.pop('firmware')
    p0_op_id = kwargs.pop('p0_op_id')

    if kwargs:
        raise TransportError("Unexpected keywords: %s" % kwargs.keys())

    if hasattr(device.transport, 'dongle_name'):
        # TRB
        dongle_name = device.transport.dongle_name
        dongle_id = device.transport.trb.get_dongle_details().id
        return TRBTransport(
            device=dongle_name,
            device_id=dongle_id,
            wait_time=wait_time,
            verbose=verbose
        )

    if p0_op_id is None:
        raise TransportError(
            "The transport is Test Tunnel. The KSP Operator ID on P0 is required."
        )

    # Test Tunnel
    return TTTransport(
        apps1=apps1,
        firmware=firmware,
        p0_op_id=p0_op_id,
        wait_time=wait_time
    )
