############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2012 - 2019 Qualcomm Technologies, Inc. and/or its
# subsidiaries. All rights reserved.
#
############################################################################
"""Live SPI Interface.

Module to connect to an SPI or trb port.
"""
import logging
import time

from ACAT.Core import Arch
from ACAT.Core import LiveChip

##################################################
logger = logging.getLogger(__name__)


class LiveSpi(LiveChip.LiveChip):
    """Provides access to chip data on a live chip over SPI.

    Args:
        connection
        processor
        wait_for_proc_to_start
    """

    def __init__(self, connection, processor, wait_for_proc_to_start):
        LiveChip.LiveChip.__init__(self)

        self._connection = connection
        self.processor = processor

        # Try and connect without providing a subsys or processor ID.
        # This should Just Work on Bluecore chips, and Hydra chips if using a
        # version of KalimbaLab older than 22a. If it doesn't work, things
        # get a bit harder.

        # Connect to the chip.
        self.reconnect()

        if wait_for_proc_to_start:
            # Wait until the chip is booted up otherwise ACAT will fail
            # anyways.  Just checking if the processor is running is not
            # enough to tell if the processor was booted. However, reading
            # form the PM ram region gives error if the chip wasn't
            # booted.
            message_displayed = False
            while True:
                try:
                    self._connection.read_pm(0)
                    break  # proc booted exit now
                except BaseException:
                    if not message_displayed:
                        print("Waiting for the audio subsystem to boot...")
                        message_displayed = True
                    time.sleep(0.1)
            print("Audio subsystem booted.")

    def reconnect(self):
        """Reconnects to the chip."""
        self._connection.reconnect()
