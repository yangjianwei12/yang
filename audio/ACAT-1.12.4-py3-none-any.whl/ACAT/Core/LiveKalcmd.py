############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2016 - 2019 Qualcomm Technologies, Inc. and/or its
# subsidiaries. All rights reserved.
#
############################################################################
"""Live Kalcmd Interface.

Module used to connect to a Kalcmd simulation.
"""
import logging

from . import LiveChip

from ACAT.Core.connections.kalcmd import KalcmdConnection
from ACAT.Core.exceptions import ChipdataError

logger = logging.getLogger(__name__)


class LiveKalcmd(LiveChip.LiveChip):
    """Provides access to chip data on a live chip over SPI.

    Args:
        kalcmd_object
        processor
    """

    def __init__(self, kalcmd_object, processor):
        LiveChip.LiveChip.__init__(self)

        self._kalcmd_object = kalcmd_object
        self.processor = processor
        logger.info("Initialising connection with Kalcmd")
        self._connection = KalcmdConnection(kalcmd_object, processor)

    def get_banked_reg(self, address, bank=None):
        """Return the value of a banked register in a specific bank.

        Note:
            Default is the current value in the register.

        Args:
            address: Address of the banked register.
            bank
        """
        raise ChipdataError("get_banked_reg not supported!")

    def get_all_banked_regs(self, addr_bank_sel_reg):
        """Gets all banked registers.

        Returns a string containing all banks in a banked register given
        the address of the register used to select the bank.

        Args:
            addr_bank_sel_reg: The address of the bank select register
                that controls the bank.
        """
        raise ChipdataError("get_all_banked_regs not supported!")
