############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2021 Qualcomm Technologies, Inc. and/or its
# subsidiaries. All rights reserved.
#
############################################################################


class SectionHeaderInfoItem:
    """Debugging section header information item.

    Args:
        name: Name of the header section.
        address: Starting address of the section.
        num_bytes: Number of bytes.
        type: Type.
        flags: Flag value.

    """
    def __init__(self, name, address, num_bytes, type, flags):
        self.name = name
        self.address = address
        self.num_bytes = num_bytes
        self.type = type
        self.flags = flags
