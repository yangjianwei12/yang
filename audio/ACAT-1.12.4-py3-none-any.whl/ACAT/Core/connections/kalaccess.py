############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2021 Qualcomm Technologies, Inc. and/or its subsidiaries. All
# rights reserved.
#
############################################################################
"""Connection Kalaccess connection class."""
import logging

import kalaccess
from ka_exceptions import KalaccessError

from ACAT.Core import Arch
from ACAT.Core.connections.base import Connection
from ACAT.Core.exceptions import UsageError

logger = logging.getLogger(__name__)


class KalaccessConnection(Connection):
    """Kalaccess connection.

    Args:
        transport (str): Transport string.
        processor (int): Processor number. This can be either 0 or 1.
    """
    def __init__(self, transport, processor):
        super().__init__(transport, processor)

        self._kalaccess = kalaccess.Kalaccess()
        self._dm = self._kalaccess.dm
        self._pm = self._kalaccess.pm

        self.reconnect()
        self._chip_select()
        self._throttled_read_dm_block()

        try:
            version = self._kalaccess.get_matching_kalimbalab()
        except AttributeError:
            # 24 or older Kalimbalabs does not have
            # get_matching_kalimbalab methods Fist element form the list
            # is the kal version.
            version = "pre 24b " + self._kalaccess.get_version()[0]
        logger.info("Initialising connection with KalAccess %s", version)

    def reconnect(self):
        """Reconnects to the chip."""
        spi_trans = self._uri_to_device(self._transport)

        if spi_trans.startswith("device://"):
            spi_trans += "/audio/p{}".format(str(self._processor))
            connect_func = self._kalaccess.connect_with_uri

        else:
            connect_func = self._kalaccess.connect

        try:
            connect_func(spi_trans)

        except (SystemExit, KeyboardInterrupt, GeneratorExit):
            raise

        except Exception as error:
            usage_errors = (
                'Chip mismatch',
                'Could not connect',
                'Transport failure'
            )
            if any([usage_error in str(error) for usage_error in usage_errors]):
                raise UsageError(error)

            else:
                # Assume a compatibility problem and try again.
                # Supply defaults for mul(-1) and ignore_fw (0), we don't
                # care about them.  Audio is always subsystem 3 on a Hydra
                # chip, now and for the forseeable future.
                try:
                    connect_func(spi_trans, -1, 0, 3, self._processor)
                    state = self._kalaccess.get_exec_state()
                    if state.state == state.KA_STATE_CLOCK_OR_POWER_OFF:
                        raise UsageError('Audio subsystem is not running.')
                except KalaccessError as error:
                    raise UsageError(error)

    def get_register(self, name):
        """Get the value of a register.

        Args:
            name (str): Register name.

        Returns:
            Value of the given register.
        """
        return self._kalaccess.reg.read_register(
            self._kalaccess.reg.get_register_id(name)
        )

    def get_register_names(self):
        """Get all the register names.

        Returns:
            A list of register names.
        """
        return self._kalaccess.reg.get_register_names()

    @staticmethod
    def _uri_to_device(device_uri):
        """Remove the leading `device://` string from unsupported URIs.

        Some URIs aren't supported in `kalaccess.connect_with_uri` yet. We
        have to remove the leading bit and use the `kalaccess.connect` method
        instead.
        """
        startswith_uris = (
            'device://trb/usb2trb/',
            'device://lauterbach/jtag/',
            'device://usb2tc/',
        )
        if device_uri.lower().startswith(startswith_uris):
            device_uri = device_uri[len('device://'):]

        return device_uri

    def _chip_select(self):
        # From KalimaLab23 onwards, we can read the chip ID. If we can't
        # get it, just pass in zero so that any compatibility issue
        # becomes obvious.
        try:
            Arch.chip_select(
                self._kalaccess.arch.get_arch(), "Hydra",
                self._kalaccess.arch.get_global_chip_version(),
                self._get_chip_revision()
            )
        except AttributeError:
            Arch.chip_select(self._kalaccess.arch.get_arch(), "Hydra", 0)

    def _get_chip_revision(self):
        """Returns the chip revision number from the SLT."""
        try:
            addr_per_word = self._kalaccess.dm.addresses_per_word()
            slt_ptr = self._kalaccess._memory.read_pm_block(
                Arch.pRegions_Crescendo['SLT'][0] + addr_per_word, 1
            )
            # first 7 entries
            slt_entries = self._kalaccess._memory.read_dm_block(slt_ptr[0], 14)

            # the address of register that holds the chip version is at entry 4
            # currently, the chip revision is only used to differentiate
            # between d00 and d01 Crescendo digits
            # for different platforms, entry 4 might not even exist or the chip
            # revision might be at a different entry
            for i, entry in enumerate(slt_entries):
                if entry == 4:
                    # chip version address
                    chip_version_addr = slt_entries[i + 1]

            chip_revision = self._kalaccess._memory.read_dm_block(
                chip_version_addr, 1
            )[0] >> 8
            return chip_revision

        except BaseException:
            return None

    def _throttled_read_dm_block(self):
        # Throttle the memory read to avoid audio stalls. This is a workaround
        # to avoid the exhaustion of the transaction bridge.
        old_reader = self._dm.__dict__['_reader']

        def reader(address, words_to_fetch):
            """Slows the memory read.

            This happens by fragmenting the memory read to "maximum_read"
            words.

            Args:
                address
                words_to_fetch
            """
            maximum_read = 32

            # When the number of words to fetch is large, we have to split
            # it into chunks of maximum_read sizes.
            values = []
            while words_to_fetch:
                if words_to_fetch < maximum_read:
                    fetch_words = words_to_fetch
                else:
                    fetch_words = maximum_read

                values.extend(old_reader(address, fetch_words))

                # Re calculate the address and outstanding words to fetch
                address += fetch_words * Arch.addr_per_word
                words_to_fetch -= fetch_words

            return values

        self._dm.__dict__['_reader'] = reader

    def read_dm(self, start, end=None):
        """Read from the Data Memory.

        Args:
            start (int): Starting address to read.
            end (int): Ending address to read.
        """
        if end:
            return self._dm[start: end]

        return self._dm[start]

    def read_pm(self, start, end=None):
        """Read from the Program Memory.

        Args:
            start (int): Starting address to read.
            end (int): Ending address to read.
        """
        if end:
            return self._pm[start: end]

        return self._pm[start]

    def set_dm(self, address, value):
        """Setting a value to a Data Memory

        Args:
            address (int): The address to write.
            value (int): The value to write in the given address.
        """
        self._dm[address] = value
