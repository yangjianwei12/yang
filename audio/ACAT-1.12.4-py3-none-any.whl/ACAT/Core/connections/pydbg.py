############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2021 Qualcomm Technologies, Inc. and/or its subsidiaries. All
# rights reserved.
#
############################################################################
"""Connection Pydbg connection class."""
from urllib.parse import urlparse

from csr.front_end.pydbg_front_end import PydbgFrontEnd
from kalmemaccessors import DmMemoryBlock, PmMemoryBlock

from ACAT.Core import Arch
from ACAT.Core.connections.base import Connection


class PydbgConnection(Connection):
    """Pydbg connection.

    Args:
        transport (str): Transport string.
        processor (int): Processor number. This can be either 0 or 1.
    """

    def __init__(self, transport, processor):
        super().__init__(transport, processor)
        self._fix_transport_url()
        self._audio, self._chip = self._init_objects()
        self._chip_select()

        self._dm = self._audio.dm
        self._pm = self._audio.pm

    def _fix_transport_url(self):
        if self._transport.startswith('device://'):
            # Convert the illegal `device://tc/usb2tc/101/qcc517` to `tc:usb2tc:101`
            parsed_url = urlparse(self._transport)
            parts = [parsed_url.netloc]
            for part in parsed_url.path.split('/'):
                if part and 'qcc' not in part:
                    parts.append(part)

            self._transport = ':'.join(parts)

    def _init_objects(self):
        device, _ = PydbgFrontEnd.attach({
            'device_url': self._transport,
        })
        chip = device.chip
        audio = None
        for subsystem in device.chip.subsystems.values():
            if subsystem.name.lower() == 'audio':
                if self._processor == 0:
                    audio = subsystem.p0
                    break
                else:
                    audio = subsystem.p1
                    break

        if audio:
            return audio, chip

        raise RuntimeError("Cannot find the Audio subsystem.")

    def _chip_select(self):
        # From KalimaLab23 onwards, we can read the chip ID. If we can't
        # get it, just pass in zero so that any compatibility issue
        # becomes obvious.
        try:
            chip_version = self._chip.device.chip.curator_subsystem.core.data[0xFE81]
            Arch.chip_select(
                self.ADDRESS_PER_WORD,
                "Hydra",
                chip_version & 0x00ff,
                chip_version >> 8
            )
        except AttributeError:
            Arch.chip_select(4, "Hydra", 0)

    def reconnect(self):
        """Reconnect the chip."""
        # This is automatic in Pydbg, no action is needed.

    def get_register(self, name):
        """Get the value of a register.

        Args:
            name (str): Register name.

        Returns:
            Value of the given register.
        """
        try:
            return getattr(self._audio.regs, name).read()
        except AttributeError:
            if len(name) < 8 and name[:8] != 'REGFILE_':
                return getattr(
                    self._audio.regs,
                    'REGFILE_' + name
                ).read()

    def get_register_names(self):
        """Get all the register names.

        Returns:
            A list of register names.
        """
        regs = []
        for attribute in dir(self._audio.regs):
            if not isinstance(attribute, str):
                continue
            if not attribute[:len('REGFILE_')] == 'REGFILE_':
                continue
            if attribute == attribute.upper() and attribute[0] != '_':
                regs.append(attribute)

        return regs

    def _memory_convert(self, value):
        words = [
            value[i:i+self.ADDRESS_PER_WORD]
            for i in range(0, len(value), self.ADDRESS_PER_WORD)
        ]
        output = []
        for word in words:
            word_strings = []
            word.reverse()
            for value in word:
                if value is None:
                    # Unlike kalaccess, if the memory address is invalid, pydbg
                    # returns None. Change this value to 0 to keep the ACAT's
                    # behaviour consistent with kalaccess.
                    value = 0

                hex_value_str = str(hex(value)[2:])
                word_strings.append(hex_value_str.zfill(2))

            output.append(int(''.join(word_strings), 16))

        return output

    def read_dm(self, start, end=None):
        """Read from the Data Memory.

        Args:
            start (int): Starting address to read.
            end (int): Ending address to read.

        Returns:
            int: When the a single memory address is asked.
            DmMemoryBlock: When a block of memory is being asked by specifying
                the `end`
        """
        if end:
            res = self._memory_convert(self._dm[start: end])
            return DmMemoryBlock(start, 32, res, 32, self.ADDRESS_PER_WORD)

        res = self._memory_convert(self._dm[start: start+self.ADDRESS_PER_WORD])
        return res[0]

    def read_pm(self, start, end=None):
        """Read from the Program Memory.

        Args:
            start (int): Starting address to read.
            end (int): Ending address to read.

        Returns:
            int: When the a single memory address is asked.
            PmMemoryBlock: When a block of memory is being asked by specifying
                the `end`
        """
        if end:
            res = self._memory_convert(self._pm[start: end])
            return PmMemoryBlock(start, 32, res, 32, self.ADDRESS_PER_WORD)

        res = self._memory_convert(self._pm[start:start+self.ADDRESS_PER_WORD])
        return res[0]

    def set_dm(self, address, values):
        """Setting a value to a Data Memory

        Args:
            address (int): The address to write.
            values (list): List of integers. Each integer represents a word in
                Kymera.
        """
        for i, value in enumerate(values):
            self._dm[address + i*self.ADDRESS_PER_WORD] = value

