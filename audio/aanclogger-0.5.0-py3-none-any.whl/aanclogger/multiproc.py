############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2020 Qualcomm Technologies, Inc. and/or its subsidiaries.
# All rights reserved.
#
############################################################################
"""Module to provide support for running ACAT in multiprocessing mode.

This allows a dual class to be created that can access fields from both
devices.

"""

import argparse
from enum import Enum
from multiprocessing.managers import BaseManager, NamespaceProxy
import operator
import numpy as np


from ACAT.Core.CoreUtils import qformat_factory
from ACAT.Core.logger import config_logger
from ACAT.Analysis.Opmgr import Capability, Operator
from aanclogger.connect import CONN_DEVICE1, CONN_DEVICE2
from aanclogger.graph import OPERATOR_NAME, OPERATOR_CAP_ID, OPERATOR_CAP_IDX, \
    HANDLE_BINS
from aanclogger.graph import HANDLE_TYPE, HANDLE_TYPE_POINT, HANDLE_TYPE_AFB, \
    HANDLE_TYPE_BAR
from aanclogger.graph import HANDLE_NAME, HANDLE_OPERATOR, HANDLE_ATTR, \
    HANDLE_CONVERSION, HANDLE_LOG_FMT, HANDLE_MISSING
from aanclogger.graph import CONVERSION_BITMASK, CONVERSION_OFFSET, \
    CONVERSION_QFMT, CONVERSION_SCALE, CONVERSION_SIGNED, \
    CONVERSION_SAMPLE_RATE, CONVERSION_NPTS

from aanclogger.graph import PLOT_MAGNITUDE, PLOT_FREQUENCY, \
    PLOT_DATAPOINTS_WIDTH, PLOT_COLOR

from aanclogger.graph import NoOperatorsException

BYTES_PER_WORD = 4
DEFAULT_BAR_COLOR = 'red'
DEFAULT_BAR_HIGHLIGHT_COLOR = 'green'


class MyManager(BaseManager):
    """Custom manager to multi-process ACAT instances."""


class AANCProxy(NamespaceProxy):
    """Proxy for AANC."""
    _exposed_ = ('__getattribute__', 'read', 'do_analysis', 'refresh',
                 'reload', 'log_fmt', 'valid')

    def read(self, attr):
        """read values bypassing the need to pickle intermediate objects."""
        callmethod = object.__getattribute__(self, '_callmethod')
        return callmethod('read', (attr,))

    def log_fmt(self, attr):
        """Return the log format for a given attribute."""
        callmethod = object.__getattribute__(self, '_callmethod')
        return callmethod('log_fmt', (attr,))

    def do_analysis(self):
        """Run an ACAT analysis."""
        callmethod = object.__getattribute__(self, '_callmethod')
        return callmethod('do_analysis')

    def reload(self, operators, handles):
        """Reload object data."""
        callmethod = object.__getattribute__(self, '_callmethod')
        return callmethod('reload', (operators, handles,))

    def valid(self):
        """Return object validity."""
        callmethod = object.__getattribute__(self, '_callmethod')
        return callmethod('valid')

    def __getattribute__(self, attr):
        if '.' in attr:
            return self.read(attr)

        return super().__getattribute__(attr)


class VarType(Enum):
    """Represent variable type.

       Allows distinction between a single point and an analysis filter bank
       """
    POINT = 1
    BAR = 2
    AFB = 3


class ACATChipBar:  # pylint: disable=too-many-instance-attributes,too-few-public-methods
    """Represent a frequency domain buffer in ACAT.

    Args:
        handle (var): ACAT operator or string
        oprs (dict): Dictionary of ACAT operator objects
        attr (str): Frequency vector address
        conversion (dict): Conversion dictionary
        missing (int): Value to return if data is missing
    """
    def __init__(self, handle, oprs, attr, conversion, missing, log_fmt=""):  # pylint: disable=too-many-arguments
        self._handle = handle
        self._oprs = oprs
        self.attr = attr

        self.log_fmt = log_fmt

        self.qfmt = conversion[CONVERSION_QFMT]
        if self.qfmt:
            fmtvals = [int(val) for val in self.qfmt.split('.')]
            self.qfmt = qformat_factory(*fmtvals)

        self.qfmt = qformat_factory(1, 31)
        self.missing = missing

        self.ptr = eval(self.attr, self._oprs) # pylint: disable=eval-used
        self._chipdata = self.ptr._chipdata

        self.npts = conversion[CONVERSION_NPTS]
        self.nbytes = self.npts * BYTES_PER_WORD

        self.color = [DEFAULT_BAR_COLOR] * self.npts

    def read(self):
        """Read the attribute."""
        try:
            mag = self._chipdata.get_data(self.ptr.value, self.nbytes)
        except TypeError:
            # Kalimba access error
            return {PLOT_MAGNITUDE: [self.missing], PLOT_COLOR: self.color}

        if self.qfmt:
            mag = [self.qfmt(value) for value in mag]

        return {PLOT_MAGNITUDE: mag, PLOT_COLOR: self.color}


class ACATChipAFB:  # pylint: disable=too-many-instance-attributes,too-few-public-methods
    """Represent an AFB analysis in ACAT.

    Args:
        handle (var): ACAT operator or string
        oprs (dict): Dictionary of ACAT operator objects
        attr (str): AFB attribute to read
        conversion (dict): Conversion dictionary
        missing (int): Value to return if data is missing
    """
    def __init__(self, handle, oprs, attr, conversion, missing, bins=None,  # pylint: disable=too-many-arguments
                 log_fmt=""):
        self._handle = handle
        self._oprs = oprs
        self.attr = attr

        self.log_fmt = log_fmt

        self.qfmt = qformat_factory(1, 31)
        self.sample_rate = conversion[CONVERSION_SAMPLE_RATE]
        self.missing = missing

        self.bins = bins

        self.color = []
        self.all_bins = []

        self.afb = eval(self.attr, self._oprs)  # pylint: disable=eval-used
        self._chipdata = self.afb._chipdata
        self.fft = self.afb.freq_output_object_ptr.deref

        self.npts = self.afb.fft_object_ptr.deref.num_points.value
        self.nbytes = self.npts * BYTES_PER_WORD

        self.fs_scale = self.sample_rate / (2.0 * self.npts)

        self._process_bins()

    def _process_bins(self):
        """
        This function is responsible to validate the bin configuration and
        generate required data for plotting
        """
        if self.bins is None:
            print("Bins are not specified, grabbing the information from ACAT")
            self.bins = [0, self.npts]

        if len(self.bins) >= 2:
            self.all_bins = list(range(self.bins[0], self.bins[-1] + 1))

        self.color = [DEFAULT_BAR_COLOR] * len(self.all_bins)

        # Make only the specified bins a certain color based on the range
        if len(self.bins) == 2:
            self.color = [DEFAULT_BAR_HIGHLIGHT_COLOR] * len(self.all_bins)
        else:
            for idx, current_bin in enumerate(self.bins):
                if idx == 0:
                    self.color[idx] = DEFAULT_BAR_HIGHLIGHT_COLOR
                else:
                    diff = current_bin - self.bins[0]
                    self.color[diff] = DEFAULT_BAR_HIGHLIGHT_COLOR

        self.freq = np.arange(self.bins[0], self.bins[-1] + 1) * self.fs_scale
        self.width = self.fs_scale

    def read(self):
        """Read the attribute."""
        try:
            first_value = self.bins[0]
            last_value = self.bins[-1]
            npts = last_value - first_value + 1

            real = self._chipdata.get_data(self.fft.real_ptr.value +
                                           first_value * BYTES_PER_WORD,
                                           npts * BYTES_PER_WORD)
            imag = self._chipdata.get_data(self.fft.imag_ptr.value +
                                           first_value * BYTES_PER_WORD,
                                           npts * BYTES_PER_WORD)
            bexp = self._chipdata.get_data(self.fft.exp_ptr.value)
        except TypeError:
            # Kalimba access error
            return {
                PLOT_FREQUENCY: [0],
                PLOT_MAGNITUDE: [self.missing],
                PLOT_DATAPOINTS_WIDTH: [1],
                PLOT_COLOR: self.color
            }

        realq = [self.qfmt(value) for value in real]
        imagq = [self.qfmt(value) for value in imag]
        bexpv = 2.0 ** -bexp
        mag = bexpv * np.sqrt(np.square(realq) + np.square(imagq))

        return {
            PLOT_FREQUENCY: self.freq,
            PLOT_MAGNITUDE: mag,
            PLOT_DATAPOINTS_WIDTH: self.width,
            PLOT_COLOR: self.color
            }


class ACATChipVar:  # pylint: disable=too-many-instance-attributes,too-few-public-methods
    """Represent a chip variable in ACAT.

    Args:
        handle (var): ACAT operator or string
        oprs (dict): Dictionary of ACAT operator objects
        attr (str): Attribute to read
        conversion (dict): Conversion dictionary
        missing (int): Value to return if data is missing
        log_fmt (str): Format for logging data

    This stores the address of the variable & format to read it in to allow
    for refresh commands this side of the proxy.

    The input dictionary is the context used to evaluate the attribute string.
    """
    def __init__(self, handle, oprs, attr, conversion, missing, log_fmt=""):  # pylint: disable=too-many-arguments
        self._handle = handle
        self._oprs = oprs
        self.attr = attr

        self.conv = argparse.Namespace()
        self.conv.signed = conversion[CONVERSION_SIGNED]
        self.conv.qfmt = conversion[CONVERSION_QFMT]
        self.conv.scale = conversion[CONVERSION_SCALE]
        self.conv.offset = conversion[CONVERSION_OFFSET]
        self.conv.bitmask = conversion[CONVERSION_BITMASK]

        self.missing = missing
        self.log_fmt = log_fmt

        # Make sure bitmask is an integer - could be passed as a hex string
        if self.conv.bitmask:
            self.conv.bitmask = int(self.conv.bitmask, 16)

        # Scale can be passed as a string, e.g. '2**-16'. Convert to a number
        # via eval.
        if isinstance(self.conv.scale, str):
            self.conv.scale = eval(self.conv.scale) # pylint: disable=eval-used

        # Generate Q format conversion factory
        if self.conv.qfmt:
            fmtvals = [int(val) for val in self.conv.qfmt.split('.')]
            self.conv.qfmt = qformat_factory(*fmtvals)

        # If the handle is a string (e.g. 'constant') then no chip data is read
        if isinstance(self._handle, str):
            return

        # Read the chip data and get the address and size, along with a handle
        # to read data later. Python's evaluation is used on the attribute
        # string to provide robust handling of the input attribute.
        var_handle = eval(self.attr, self._oprs) # pylint: disable=eval-used
        self.address = var_handle.address
        self.size = var_handle.size
        if self.size not in [1, 2, 4]:
            raise ValueError(f"Unhandled variable size: "
                             f"{self.size} ({self.attr})")
        self._chipdata = var_handle._chipdata

    def read(self):
        """Read the attribute."""
        # Return the constant value if just a constant
        if isinstance(self._handle, str):
            return self.attr

        # Read a raw word & convert to bytes. This is needed if we need to
        # access a sub-chunk.
        try:
            data = self._chipdata.get_data(self.address)
            data_bytes = data.to_bytes(4, 'little')
        except TypeError:
            # Kalimba access error
            return self.missing

        data_bytes = data_bytes[self.address % 4:]

        # Reinterpret the byte string
        data = int.from_bytes(data_bytes, 'little', signed=self.conv.signed)
        if self.size == 2:
            data = data & 0xFFFF
        elif self.size == 1:
            data = data & 0xFF

        # Apply any conversions: Q format is standalone
        if self.conv.qfmt:
            return self.conv.qfmt(data)

        if self.conv.bitmask:
            data = data & self.conv.bitmask

        return (data * self.conv.scale) + self.conv.offset


class AANCLauncher:
    """Launch an AANC class.

    Args:
        params (list): List of parameters to launch ACAT with.

    """
    def __init__(self, params):
        self._params = params
        self._operators = {}
        self.handles = {}
        self._opmgr = None
        self._ids = []
        self._session = None

    def load_session(self):
        """Load the ACAT session."""
        # ACAT import has to be within the class to be encapsulated inside
        # the subprocess.
        print("Loading Session")
        try:
            import ACAT # pylint: disable=import-outside-toplevel
            config_logger(False)
            ACAT.parse_args(self._params)
            self._session = ACAT.load_session()
        except TypeError:
            print("Load session failed: audio processor booted?")
            self._session = None
        # Kalimba exception caught by text rather than type
        except Exception: # pylint: disable=broad-except
            print("Load session failed: could not connect")
            self._session = None

    def initialize_operators(self, operators):
        """Initialize operators.

        Args:
            operators (list(dict)): List of operator definitions.
        """
        print("Initializing Operators")
        if not operators:
            raise ValueError("No operators to initialize")

        if self._session is None:
            raise NoOperatorsException("Session not initialized")

        self._opmgr = operator.attrgetter("p0.opmgr")(self._session)
        # Get a list of operator entries and corresponding capability IDs
        oplist = self._opmgr.get_oplist('entry')
        if not oplist:
            raise NoOperatorsException("No operators found in the graph.")

        capids = [entry.cap_data.deref.id.value for entry in oplist]
        # Create a handle for each object specified in the graph
        for obj in operators:
            tgtid = obj[OPERATOR_CAP_ID]
            # Find operator IDs that match the required capability ID
            idxs = [idx for idx, capid in enumerate(capids) if capid == tgtid]
            if not idxs:
                raise NoOperatorsException(
                    f"No operators found for capability {tgtid}")
            try:
                # Select the capability based on the index
                opentry = oplist[idxs[obj[OPERATOR_CAP_IDX]]]
                elfid = self._opmgr.debuginfo.table.get_elf_id_from_address(
                    opentry.cap_data.deref['handler_table'].value)
                # Assume it's a built-in capability if not in the downloadable
                # table
                if elfid is None:
                    elfid = self._opmgr.debuginfo.get_kymera_debuginfo().elf_id
                cap = Capability(opentry.cap_data.deref, self._opmgr, elfid)
                opr = Operator(opentry, self._opmgr, cap)
                self._operators[obj[OPERATOR_NAME]] = opr
            except IndexError as err:
                raise IndexError(f"Operator index {obj[OPERATOR_CAP_IDX]} "
                                 f"not found for capability {tgtid} "
                                 f"({len(idxs)} operators found)") from err

    def initialize_handles(self, handles):
        """Initialize handles.

        Args:
            handles (list(dict)): List of handle definitions.
        """
        print("Initializing Handles")
        self._ids = []
        for handle in handles:
            op_name = handle[HANDLE_OPERATOR]

            # If the op_name isn't a real operator and is just a constant
            # then don't dereference to a handle to the operator
            if op_name.lower() == '(constant)':
                opr = op_name
            else:
                if op_name not in self._operators.keys():  # pylint: disable=consider-iterating-dictionary
                    raise ValueError(f"Couldn't find operator {op_name} in "
                                     f"existing handles "
                                     f"({self._operators.keys()})")
                opr = self._operators[op_name]
                self._ids.append(opr.id)
            # Store the handle
            if handle[HANDLE_TYPE] == HANDLE_TYPE_POINT:
                self.handles[handle[HANDLE_NAME]] = ACATChipVar(
                    opr, self._operators, handle[HANDLE_ATTR],
                    handle[HANDLE_CONVERSION], handle[HANDLE_MISSING],
                    handle[HANDLE_LOG_FMT])
            elif handle[HANDLE_TYPE] == HANDLE_TYPE_AFB:
                self.handles[handle[HANDLE_NAME]] = ACATChipAFB(
                    opr, self._operators, handle[HANDLE_ATTR],
                    handle[HANDLE_CONVERSION], handle[HANDLE_MISSING],
                    handle[HANDLE_BINS], handle[HANDLE_LOG_FMT])
            elif handle[HANDLE_TYPE] == HANDLE_TYPE_BAR:
                self.handles[handle[HANDLE_NAME]] = ACATChipBar(
                    opr, self._operators, handle[HANDLE_ATTR],
                    handle[HANDLE_CONVERSION], handle[HANDLE_MISSING],
                    handle[HANDLE_LOG_FMT])

    def reload(self, objects, handles):
        """Reload chip data."""
        if self._session is None:
            self.load_session()

        # Re-check whether loading the session worked.
        if self._session is None:
            return

        try:
            self.initialize_operators(objects)
            self.initialize_handles(handles)
        except TypeError:
            # argument of type 'KalaccessError' is not iterable is thrown
            # if the device is reset/audio processor not started
            print("Reload failed: audio processor booted?")
            self._session = None
            return

    def valid(self):
        """Check for operator validity before reading data."""
        if self._opmgr is None:
            return False

        try:
            oprs = self._opmgr.get_oplist()
        except TypeError:
            # argument of type 'KalaccessError' is not iterable is thrown
            # if the device is reset/audio processor not started
            print("Validity check failed: audio processor booted?")
            self._session = None
            return False

        if not oprs:
            return False

        for opid in self._ids:
            if opid not in oprs:
                return False

        return True

    def read(self, attr):
        """Read an attribute value."""
        return self.handles[attr].read()

    def log_fmt(self, attr):
        """Return the format value for an attribute."""
        return self.handles[attr].log_fmt

    def do_analysis(self):
        """Do the ACAT analysis."""
        # ACAT import has to be within the class to be encapsulated inside
        # the subprocess.
        import ACAT # pylint: disable=import-outside-toplevel
        ACAT.do_analysis(self._session)


MyManager.register('AANC', AANCLauncher, AANCProxy)


class DualConnection(): # pylint: disable=too-few-public-methods
    """Represent a dual connection to two AANC devices.

    Args:
        device1 (AANCProxy): Proxy to the device2 connection
        device2 (AANCProxy, optional): Proxy to the device1 connection.
            Defaults to None.
    """
    def __init__(self, device1, device2):
        self.device1 = device1
        self.device2 = device2
        self.device1_operators = []
        self.device2_operators = []
        self.device1_attrs = []
        self.device2_attrs = []

    def reload(self, operators, handles):
        """Initialize operators and handles.

        Args:
            operators (list(dict)): List of operator definitions.
            handles (list(dict)): List of handle definitions.
        """
        self.device1_operators = operators[CONN_DEVICE1]
        device1_names = [oper[OPERATOR_NAME] for oper in self.device1_operators]
        device1_handles = [handle for handle in handles if
                           handle[HANDLE_OPERATOR] in device1_names or
                           handle[HANDLE_OPERATOR].lower() == '(constant)']
        self.device1_attrs = [handle[HANDLE_NAME] for handle in device1_handles]

        self.device2_operators = operators[CONN_DEVICE2]
        device2_names = [oper[OPERATOR_NAME] for oper in self.device2_operators]
        device2_handles = [handle for handle in handles if
                           handle[HANDLE_OPERATOR] in device2_names]
        self.device2_attrs = [handle[HANDLE_NAME] for handle in device2_handles]

        if self.device1 is not None:
            self.device1.reload(self.device1_operators, device1_handles)
        if self.device2 is not None:
            self.device2.reload(self.device2_operators, device2_handles)

    def read(self, attr):
        """Read a value."""
        if attr in self.device1_attrs:
            return self.device1.read(attr)
        if attr in self.device2_attrs:
            return self.device2.read(attr)
        raise ValueError(f"Unknown attribute: {attr}")

    def log_fmt(self, attr):
        """Return the log format for a given attribute."""
        if attr in self.device1_attrs:
            return self.device1.log_fmt(attr)
        if attr in self.device2_attrs:
            return self.device2.log_fmt(attr)
        raise ValueError(f"Unknown attribute: {attr}")

    @property
    def valid(self):
        """Return the validity of the session."""
        if self.device1 is not None and not self.device1.valid():
            return False
        if self.device2 is not None and not self.device2.valid():
            return False
        return True


class SingleConnection(): # pylint: disable=too-few-public-methods
    """Represent a single connection to an AANC device.

    The principle here is to expose the same `device1` member as a
    `DualConnection` to allow graphs connecting to a single device to work
    with either mode.

    Args:
        params (list): List of parameters to launch ACAT with.

    """
    def __init__(self, params):
        self.device1 = AANCLauncher(params)
        self.device1_attrs = []

    def reload(self, operators, handles):
        """Initialize operators and handles.

        Args:
            operators (list(dict)): List of operator definitions.
            handles (list(dict)): List of handle definitions.
        """
        self.device1_attrs = [handle[HANDLE_NAME] for handle in handles]
        self.device1.reload(operators[CONN_DEVICE1], handles)

        # self.device1.initialize_operators(operators)
        # self.device1.initialize_handles(handles)

    def read(self, attr):
        """Read a value."""
        if attr in self.device1_attrs:
            return self.device1.read(attr)
        raise ValueError(f"Unknown attribute: {attr}")

    def log_fmt(self, attr):
        """Return the log format for a given attribute."""
        if attr in self.device1_attrs:
            return self.device1.log_fmt(attr)
        raise ValueError(f"Unknown attribute: {attr}")

    @property
    def valid(self):
        """Return the validity of the session."""
        return self.device1.valid()
