"""
Configure Logging

This module is used to configure the python logging module in a consistent
manner for all scripts. It adds additional PRINT and TRACE logging levels.

Configure Logging supports 4 pre-defined logging configurations
- detailed (default)
- brief
- console
- file

If the selected config supports a file handler, output is written to the
configured logging folder, using the name of the calling script as the log
file name.

Parameters can be set by the command line or environment variables. Command line
parameters will override environment parameters. See built-in help for command
line parameters.

Supported Envronmnet variables
- ADK_DEFAULT_LOG_LEVEL : Sets the default log level to use
- ADK_DEFAULT_LOG_FILE_PATH : Sets the default path log files are saved to
- ADK_DEFAULT_LOGGING_CONFIG : Sets the default logging config to use
- ADK_CONSOLE_OVERRIDE_LOG_LEVEL : Override the console log level independent of any other settings
- ADK_FILE_OVERRIDE_LOG_LEVEL : Override the file log level independent of any other settings

This Module should be used in conjunction with .configure_logging _arguments.

"""

import logging
import logging.config
import pkgutil
import sys
from os import environ, makedirs
from pathlib import Path

import yaml

CONFIG_FILE = '{config}.yaml'
LOGGING_RESOURCE_PATH = ['resources', 'logging', CONFIG_FILE]
PRINT_LOGGING_LEVEL = logging.INFO + 5
TRACE_LOGGING_LEVEL = logging.DEBUG -5
ADK_DEFAULT_LOG_LEVEL = PRINT_LOGGING_LEVEL
ADK_DEFAULT_LOGGING_CONFIG = 'brief'
ADK_CONSOLE_OVERRIDE_LOG_LEVEL = 'ADK_CONSOLE_OVERRIDE_LOG_LEVEL'
ADK_FILE_OVERRIDE_LOG_LEVEL = 'ADK_FILE_OVERRIDE_LOG_LEVEL'
ADK_DEFAULT_LOG_FILE_PATH = '.'


def log_level_to_int(log_level):
    """Return an integer value for a log level represented by a string."""
    try:
        level = int(log_level)
    except ValueError:
        level = getattr(logging, log_level.upper(), None)
        if not level:
            raise ValueError(f'Invalid string value passed for log level: {log_level}') from None
    return level


def _log_level_to_string(log_level):
    """Return a string representing a numeric log level."""
    try:
        return logging.getLevelName(int(log_level))
    except ValueError:
        if isinstance(log_level, str):
            return log_level.upper()
        raise RuntimeError(f'Invalid log level: {log_level}') from None


def update_log_level(config, handler, log_level):
    if log_level is not None:
        try:
            config['handlers'][handler]['level'] = _log_level_to_string(log_level)
        except KeyError:
            # Silently ignore failed attempt to set a logging level
            pass


def _update_console_log_level(config, log_level):
    if ADK_CONSOLE_OVERRIDE_LOG_LEVEL in environ:
        log_level = environ[ADK_CONSOLE_OVERRIDE_LOG_LEVEL]
    update_log_level(config, 'console', log_level)


def _update_file_log_level(config, log_level):
    if ADK_FILE_OVERRIDE_LOG_LEVEL in environ:
        log_level = environ[ADK_FILE_OVERRIDE_LOG_LEVEL]
    else:
        if 'file' in config['handlers']:
            current_file_log_level = config['handlers']['file']['level']
            # lower log levels display more detail
            log_level = min(log_level_to_int(log_level), log_level_to_int(current_file_log_level))
    update_log_level(config, 'file', log_level)


def _update_log_levels(config, log_level):
    _update_console_log_level(config, log_level)
    _update_file_log_level(config, log_level)


def _get_logfile_name():
    """Use the name of the calling file to name the log file."""
    return f'{Path(sys.argv[0]).stem}.log'


def _get_log_file(log_file_path):
    """Return the full path to the logfile."""
    log_file_path = Path(log_file_path).resolve()
    makedirs(log_file_path, exist_ok=True)
    return Path(log_file_path, _get_logfile_name())


def _update_log_file_path(config, log_file_path):
    """Update logging file name when using pre-defined configs."""
    log_file = _get_log_file(log_file_path)
    try:
        # Not all configs support file handlers
        config['handlers']['file']['filename'] = log_file
    except KeyError:
        # Silently ignore attempt to set a logging filename
        pass


def _get_resource_path(config_name):
    return str(Path(*LOGGING_RESOURCE_PATH)).format(config=config_name)


def read_logging_config(config_name):
    """Returns a dictionary object representing the named logging config."""
    try:
        package = __name__.split('.', maxsplit=1)[0]
        data = pkgutil.get_data(package, _get_resource_path(config_name))
        return yaml.safe_load(data)
    except FileNotFoundError:
        raise RuntimeError(f'Invalid logging config: {config_name}') from None


def _get_config(config, log_level, log_file_path):
    """Read the logging config and update levels and filename."""
    if isinstance(config, dict):
        return config
    config_data = read_logging_config(config)
    if config_data:
        _update_log_levels(config_data, log_level)
        _update_log_file_path(config_data, log_file_path)
        return config_data
    raise RuntimeError(f'Invalid logging config: {config}')


def configure_logging(log_level=ADK_DEFAULT_LOG_LEVEL,
                      log_file_path=ADK_DEFAULT_LOG_FILE_PATH,
                      logging_config=ADK_DEFAULT_LOGGING_CONFIG):
    """Configure Logging."""
    add_print_logging_level()
    add_trace_logging_level()
    logging_config = _get_config(logging_config, log_level, log_file_path)
    logging.config.dictConfig(logging_config)


def add_print_logging_level():
    """Adds the custom logging level 'print' to the logging module.
    This function should be called by any piece of code that uses logging.print()
    """
    add_logging_level('PRINT', PRINT_LOGGING_LEVEL)


def add_trace_logging_level():
    """Adds the custom logging level 'trace' to the logging module.
    This function should be called by any piece of code that uses logging.trace()
    """
    add_logging_level('TRACE', TRACE_LOGGING_LEVEL)


def add_logging_level(level_name, level):
    """Adds a new custom logging level to the logging module."""

    def log_for_level(self, message, *args, **kwargs):
        if self.isEnabledFor(level):
            self._log(level, message, args, **kwargs)  # pylint: disable=protected-access

    def log_to_root(message, *args, **kwargs):
        logging.log(level, message, *args, **kwargs)

    level_function = level_name.lower()
    logging.addLevelName(level, level_name)
    setattr(logging, level_name, level)
    setattr(logging.getLoggerClass(), level_function, log_for_level)
    setattr(logging, level_function, log_to_root)
