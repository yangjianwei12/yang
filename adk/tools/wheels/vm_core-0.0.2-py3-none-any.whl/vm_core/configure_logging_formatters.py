"""
Module to provide additional Argparse formatter classes
"""

from argparse import ArgumentDefaultsHelpFormatter, RawDescriptionHelpFormatter


class RawDefaultsHelpFormatter(ArgumentDefaultsHelpFormatter, RawDescriptionHelpFormatter):
    """
    Implements a formatter for argparse that supports raw data for the help text
    and also adds default arguments
    """
