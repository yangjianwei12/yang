"""
Use this class to populate argparse args from os environment variables.
If an OS ENV is set, it will override and
Priority
========
    1. passed in argument
    2. OS Environment variable
    3. Default setting

Usage
=====
from argparse import ArgumentParser
from vm_utils.argparse_actions import EnvDefault

parser=ArgumentParser()
parser.add_argument(
    "-c", "--chip_family",
    action=EnvDefault,
    envvar='ADK_CHIP_FAMILY',
    required=True
)
args=parser.parse_args()

"""

from argparse import Action
from os import environ

class EnvDefault(Action):  # pylint: disable=too-few-public-methods
    def __init__(self, envvar, required=True, default=None, **kwargs):
        if envvar in environ:
            default = environ[envvar]
        if required and default:
            required = False
        super().__init__(default=default, required=required, **kwargs)

    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, values)
