import pkg_resources

def entry_points(package_name):
    """Return a list of console script entrypoints provided by the named package."""
    return (entrypoint
            for entrypoint in pkg_resources.iter_entry_points('console_scripts')
            if entrypoint.module_name.startswith(package_name))
	