"""
Usage:

Any script that is using configure_logging should provide a means to control logging config
at the point of the script execution. This can be achieved by adding the following code
to the scripts argparse logic.

from vm_utils import configure_logging_arguments

def process_commandline_arguments():
    ...
    configure_logging_arguments.add_arguments(parser)

"""

from .argparse_actions import EnvDefault  # pylint: disable=unused-import
from .configure_logging import ADK_DEFAULT_LOG_LEVEL, ADK_DEFAULT_LOGGING_CONFIG, ADK_DEFAULT_LOG_FILE_PATH


def add_arguments(parser, log_level=None, log_file=None, logging_config=None):
    parser.add_argument(
        '-l', '--log', '--log_level',
        default=log_level or ADK_DEFAULT_LOG_LEVEL,
        action=EnvDefault,
        envvar='ADK_DEFAULT_LOG_LEVEL',
        dest='log_level',
        help='Set the logging level. This can be an integer, or a string representing the logging default values.'
    )
    parser.add_argument(
        '--log_file_path',
        default=log_file or ADK_DEFAULT_LOG_FILE_PATH,
        dest='log_file_path',
        action=EnvDefault,
        envvar='ADK_DEFAULT_LOG_FILE_PATH',
        help='Set the path used for storing logfiles'
    )
    parser.add_argument(
        '--logging_config',
        default=logging_config or ADK_DEFAULT_LOGGING_CONFIG,
        dest='logging_config',
        action=EnvDefault,
        envvar='ADK_DEFAULT_LOGGING_CONFIG',
        help='The logging config to use. Either a predefined config, or a valid logging config dictionary'
    )


def add_logging_arguments(parser):
    add_arguments(parser)
