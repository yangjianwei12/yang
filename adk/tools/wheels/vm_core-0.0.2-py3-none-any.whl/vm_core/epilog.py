
from .entry_points import entry_points


def console_scripts(package):
    """
    Return a string containing the console scripts provided by a package.
    """
    if package:
        output = 'Console scripts:\n'
        scripts = list(entry_points(package))
        if scripts:
            for script in scripts:
                output += f'- {script.name}\n'
            return output
    return ''


def package_version(package, version):
    """
    Return a formatted string containing the top level package name and current
    version of that package.
    """
    if package:
        return f'From {package.split(".", maxsplit=1)[0]}=={version}'
    return ''
