"""
A class to display package information

Usage:
Save the following source as scripts/package_info.py inside your package, and make available as a CLI script

========= scripts/package_info.py =========

from vm_utils.package_info import PackageInfo

from ..version import __version__


def main():
    print(PackageInfo(__package__, __version__))


if __name__ == '__main__':
    main()

=================== end ===================

And then add a reference to package_info:main() to the package config
e.g. for setup.py
entry_points={
  "console_scripts": ['vm_release = vm_release.scripts.package_info:main']
}

e.g. for pyproject.toml
[project.scripts]
[package_name] = '[package_name].scripts.package_info:main'

"""

from argparse import ArgumentParser, RawDescriptionHelpFormatter

from .epilog import console_scripts, package_version


class PackageInfo():
    def __init__(self, name, version):
        self._name = name
        self._version = version
        self._parser = self._get_parser()
        self.parser.parse_args()

    @property
    def name(self):
        return self._name.split('.', maxsplit=1)[0]

    @property
    def version(self):
        return self._version

    @property
    def parser(self):
        return self._parser

    def __str__(self):
        output = f'Information for package: {self.name}\n'
        output += console_scripts(self.name)
        output += '\n'
        output += package_version(self.name, self.version)
        return output

    def _get_parser(self):
        return ArgumentParser(
            formatter_class=RawDescriptionHelpFormatter,
            description=f'Report {self.name} package information',
            epilog=package_version(self.name, self.version)
        )
