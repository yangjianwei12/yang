from vm_build.version import __version__
