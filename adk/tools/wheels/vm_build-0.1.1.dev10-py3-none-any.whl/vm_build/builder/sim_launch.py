"""
%%fullcopyright(2019)
%%version
Provides mechanisms for launching and killing simulators
"""

from __future__ import print_function
import subprocess
import time
import os

def launch_audio_kse_env(devkit_root, kse_path, fw_name, kalsim_name, enable_debug, scripts, platform, patch_bundle, bundle_path, kalsim_log_level, kalsim_timer_update):
    print('Kalsim mode selected (KALSIM_MODE project property is set to true)')
    cmd = r"start cmd.exe /C {dquotes}{d_root}\tools\python27\python.exe -m kse.kalsim.kalsim_shell --ks_path {k_name} --log_level {l_level} --ks_timer_update_period {period}".format(dquotes = "\"",d_root=devkit_root, k_name=kalsim_name,l_level=kalsim_log_level,period=kalsim_timer_update)
    cmd = cmd + " --ks_firmware {}".format(os.path.splitext(fw_name)[0])
    cmd = cmd + " --acat_use"
    if bundle_path != "":
        cmd = cmd + " --acat_bundle {}".format(os.path.splitext(bundle_path)[0])
    if enable_debug == "true":
        cmd = cmd + " --ks_debug --ka_skip"
    cmd = cmd + " --platform {} ".format(platform)
    if patch_bundle != "":
        cmd = cmd + " --hydra_ftp_server_directory {}".format(os.path.dirname(patch_bundle))
    if scripts != "":
        scripts = scripts.replace(","," ")
        cmd = cmd + " --script \"{}\"".format(scripts)
    cmd = cmd + " & pause\""
    my_env = os.environ.copy()
    my_env["KATS_WORKSPACE"] = kse_path
    print("KSE launch command:", cmd)
    subprocess.Popen(cmd, env=my_env, shell=True)

    return True

def launch_sim(working_dir, kalsim_exe, kapfile):
    """
    Emulates deploying to a physical target device by using a simulator instead.
    Kills any instances of Kalsim currently running and then starts a fresh one.
    Loads the new Kalsim with the supplied kap file.
    """
    killallkal()

    cmd_line = kalsim_exe + ' ' + kapfile + ' -d --initial-pc 0x4000000'
    print('KALSIM CMD', cmd_line)

    si = subprocess.STARTUPINFO()
    si.dwFlags = subprocess.STARTF_USESTDHANDLES | subprocess.STARTF_USESHOWWINDOW| subprocess.CREATE_NEW_CONSOLE


    process_h = subprocess.Popen(cmd_line, startupinfo=si, cwd=working_dir)

    print('New Kalsim PID =', process_h.pid)

def killallkal():
    """
    Kills any instances of Kalsim currently running
    """

    print('Killing all old instances of Kalsim')

    killed = subprocess.call('taskkill /F /IM kalsim*', shell=True)


