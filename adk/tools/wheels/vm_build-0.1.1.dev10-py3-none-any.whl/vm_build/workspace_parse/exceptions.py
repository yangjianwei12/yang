"""
Copyright (c) 2018 Qualcomm Technologies International, Ltd.
"""


class InvalidProjectElement(RuntimeError):
    pass


class ParseError(RuntimeError):
    pass
