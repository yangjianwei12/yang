"""
Writing information to database structure
"""

#
# QUALCOMM_COPYRIGHT_STATEMENT
#

from sqlalchemy import (Column, Integer, VARCHAR, Text, Boolean,
                        ForeignKey, text)
from sqlalchemy.dialects.sqlite import DATETIME
from sqlalchemy.orm import declarative_base, sessionmaker, relationship

# SQLalchemy expected naming convention
# pylint: disable=invalid-name
Base = declarative_base()
# pylint: enable=invalid-name

# Define datetime format to match previous perl implementation
# pylint: disable=invalid-name
dt = DATETIME(storage_format="%(year)04d-%(month)02d-%(day)02d "
                             "%(hour)02d:%(minute)02d",
              regexp=r"(\d+)-(\d+)-(\d+) (\d+):(\d+)"
              )
# pylint: enable=invalid-name



class SchemaVersion(Base):
    """
    Schema definition for Hydra schema_version table
    """
    __tablename__ = 'schema_version'

    schema_version = Column(Integer, primary_key=True, nullable=False)
    minor_version = Column(Integer, nullable=False)
    comment = Column(VARCHAR(100))


class SystemVersions(Base):
    """
    Schema definition for Hydra system_versions table
    """
    __tablename__ = 'system_versions'

    system_uid = Column(Integer, primary_key=True, nullable=True)
    chip_name = Column(VARCHAR(80))
    chip_id = Column(Integer)
    rom_name = Column(VARCHAR(80))
    rom_version = Column(Integer)
    patch_release_level = Column(Integer)
    system_version_label = Column(VARCHAR(80))
    system_description = Column(Text)
    customer_name = Column(VARCHAR(80))
    system_release_date_time = Column(dt)
    # an MD5 hash of the hashes of all elements relevant to this
    # combination of subfw_ids
    metadata_hash = Column(VARCHAR(33))


class SubsystemFirmwareVersions(Base):
    """
    Schema definition for Hydra subsystem_firmware_versions table
    """
    __tablename__ = 'subsystem_firmware_versions'

    subfw_uid = Column(Integer, primary_key=True, nullable=True)
    subsystem_name = Column(VARCHAR(20))
    subsystem_layer = Column(VARCHAR(20))
    subsystem_alias = Column(VARCHAR(20))
    # enum value from FILENAME_SUBSYSTEM_ID defined in filename.xml or
    # filename_prim.h
    subsystem_id = Column(Integer)
    version = Column(Integer)
    variant = Column(Integer, default=0)
    description = Column(Text)
    build_date_time = Column(dt)


class SystemSubfwVersions(Base):
    """
     Schema definition for Hydra systtem _subfw_versions table
    """
    __tablename__ = 'system_subfw_versions'

    system_uid = Column(Integer,
                        ForeignKey('system_versions.system_uid'),
                        primary_key=True, nullable=True,
                        )
    subfw_uid = Column(Integer,
                       ForeignKey('subsystem_firmware_versions.subfw_uid'),
                       primary_key=True, nullable=True)
    system_versions = relationship("SystemVersions")
    subsystem_firmware_versions = relationship("SubsystemFirmwareVersions")


class SystemEfuseHashes(Base):
    """
     Schema definition for Hydra system_efuse_Hashes table
    """
    __tablename__ = 'system_efuse_hashes'

    # rowid is a fake primary key to keep SQLalchemy
    rowid = Column(Integer, primary_key=True)
    system_uid = Column(Integer, ForeignKey('system_versions.system_uid'))
    system_versions = relationship("SystemVersions")
    efuse_hash = Column(Integer)


class PatchFiles(Base):
    """
    Schema dfinition for Hy
    """
    __tablename__ = 'patch_files'

    # rowid is a fake primary key to keep SQLalchemy
    rowid = Column(Integer, primary_key=True)
    subfw_uid = Column(Integer,
                       ForeignKey('subsystem_firmware_versions.subfw_uid'))
    subsystem_firmware_versions = relationship("SubsystemFirmwareVersions")
    patch_level = Column(Integer)
    # an MD5 hash of the patch file
    patch_hash = Column(VARCHAR(33))


# An element might appear in a table as a Value, and under these
# circumstances there'll be a table name specified in the config_element.
# the Indexes surrounding the tabled value are specified in the
# config_table_indices above. a particular elem_uid can appear as an index in
#  several tables, but a Value can appear only in one table,
# i.e. the config_element itself will name the table it's in.
# contains just unique versions of these items
class ConfigElements(Base):
    """
    Schema definition for Hydra config_elements table
    """
    __tablename__ = 'config_elements'
    # this is the unique ID for this version of the config element
    elem_uid = Column(Integer, primary_key=True, nullable=True)
    # this is the PSID-like ID.  There might be several versions of elems all
    # with this ID.  These mignt also be NULL IDs, e.g. for array elements
    # which are actually structures, and for table indices
    psid = Column(Integer)
    name = Column(VARCHAR(80))
    label = Column(Text)
    category = Column(VARCHAR(40))
    is_internal = Column(Boolean, default=False, server_default=text('0'))
    format = Column(VARCHAR(20))
    range_min = Column(Integer)
    range_max = Column(Integer)
    # BER encoded dotted decimal number for this, when referring to wi-fi data
    oid = Column(VARCHAR(20))
    # either integer, octet_string, uint8, int8, uint16, int16, uint32, int32,
    # uint64, int64, a struct_name or an enum_name
    type = Column(VARCHAR(80), nullable=False)
    units = Column(VARCHAR(80))
    # -- indicates that this element can contain a number of elements of the
    # defined type, where the number may be constrained by array_length_min
    # and/or array_length_max.
    is_array = Column(Boolean, default=False, server_default=text('0'))
    array_length_min = Column(Integer)
    array_length_max = Column(Integer)
    description_user = Column(Text)
    description_internal = Column(Text)
    additional_information = Column(Text)
    # -- description of the origin of this config element.
    source_reference = Column(Text)
    source_default = Column(VARCHAR(20))
    # -- One of read_write, read_only, write_only, not_accessible.
    access_rights = Column(VARCHAR(14))
    # -- an MD5 hash of the contents of all the fields in the config_elements
    # table (except for the elem_uid)
    hash = Column(VARCHAR(33))

    def __repr__(self):
        return f"<ConfigElement(elem_uid='{self.elem_uid}', " + \
               f"psid='{self.psid}', " + \
               f"name='{self.name}', " + \
               f"label='{self.label}', " + \
               f"category='{self.category}', " + \
               f"is_internal='{self.is_internal}', " + \
               f"format='{self.format}', " + \
               f"range_min='{self.range_min}', " + \
               f"range_max='{self.range_max}', " + \
               f"oid='{self.oid}', " + \
               f"type='{self.type}', " + \
               f"units='{self.units}', " + \
               f"is_array='{self.is_array}', " + \
               f"array_length_min='{self.array_length_min}', " + \
               f"array_length_max='{self.array_length_max}', " + \
               f"description_user='{self.description_user}', " + \
               f"description_internal='{self.description_internal}', " + \
               f"additional_information='{self.additional_information}', " + \
               f"source_reference='{self.source_reference}', " + \
               f"source_default='{self.source_default}', " + \
               f"access_rights='{self.access_rights}', " + \
               ">"


class SubfwElements(Base):
    """
    Schema definition for Hydra subfw_elements table
    """
    __tablename__ = 'subfw_elements'

    subfw_uid = Column(Integer,
                       ForeignKey('subsystem_firmware_versions.subfw_uid'),
                       primary_key=True, nullable=True)
    elem_uid = Column(Integer,
                      ForeignKey('config_elements.elem_uid'),
                      primary_key=True, nullable=True)
    enum_uid = Column(Integer, ForeignKey('enum_defs.enum_uid'))
    struct_uid = Column(Integer, ForeignKey('struct_defs.struct_uid'))
    table_uid = Column(Integer, ForeignKey('config_tables.table_uid'))
    subsystem_firmware_versions = relationship("SubsystemFirmwareVersions")
    config_elements = relationship("ConfigElements")
    enum_defs = relationship("EnumDefs")
    struct_defs = relationship("StructDefs")
    config_tables = relationship("ConfigTables")


# contains just unique versions of these items
class EnumDefs(Base):
    """
    Schema definition for Hydra  enum_defs table
    """
    __tablename__ = 'enum_defs'

    enum_uid = Column(Integer, primary_key=True, nullable=True)
    enum_name = Column(VARCHAR(80))
    # an MD5 hash of the enum_name, the enum_include and all of the enum
    # entries' names and values.
    hash = Column(VARCHAR(33))


class EnumEntry(Base):
    """
    Schema definition for Hydra enum_entry table
    """
    __tablename__ = 'enum_entry'
    enum_entry_uid = Column(Integer, primary_key=True, nullable=True)
    enum_uid = Column(Integer, ForeignKey('enum_defs.enum_uid'))
    enum_def = relationship("EnumDefs")
    enum_label = Column(VARCHAR(80))
    enum_value = Column(Integer)
    enum_description = Column(Text)


class StructDefs(Base):
    """
    Schema definition for Hydra struct_defs table
    """
    __tablename__ = 'struct_defs'

    struct_uid = Column(Integer, primary_key=True, nullable=True)
    struct_name = Column(VARCHAR(80))
    #  an MD5 hash of struct_name and all the config_element contents pointed
    #  to by structure elements referencing this structure definition.
    hash = Column(VARCHAR(33))


# contains just unique versions of these items
class StructureElements(Base):
    """
    Schema definition for Hydra structure_elements table
    """
    __tablename__ = 'structure_elements'

    struct_uid = Column(Integer,
                        ForeignKey('struct_defs.struct_uid'),
                        primary_key=True, nullable=True)
    elem_uid = Column(Integer,
                      ForeignKey('config_elements.elem_uid'),
                      primary_key=True, nullable=True)
    struct_defs = relationship("StructDefs")
    config_elements = relationship("ConfigElements")
    # the position in bits of this structure element, counting from the
    # msb in the parent object, little-endian
    lsb_bit_position = Column(Integer)
    # -- the length in bits represented by this structure element in
    # the'master' element, at offset above.
    bit_width = Column(Integer)


# Tables are first-class objects, at the level of config_elements.
# They contain rows and columns.  The columns are config elements themselves.
class ConfigTables(Base):
    """
    Schema definition for Hydra config_tables table
    """
    __tablename__ = 'config_tables'

    table_uid = Column(Integer, primary_key=True, nullable=True)
    table_name = Column(VARCHAR(80))
    description_user = Column(Text)
    description_internal = Column(Text)
    # the BER encoded (dotted decimal) representation of the table.
    oid = Column(VARCHAR(20))
    # description of the origin of this table.
    source_reference = Column(Text)
    is_internal = Column(Boolean, default=False, server_default=text('0'))
    num_indices = Column(Integer)
    # -- an MD5 hash of the contents of the name and the index info
    hash = Column(VARCHAR(33))


class ConfigTableIndices(Base):
    """
    Schema definition for Hydra config_table_indices table
    """
    __tablename__ = 'config_table_indices'

    table_uid = Column(Integer,
                       ForeignKey('config_tables.table_uid'),
                       primary_key=True, nullable=True)
    elem_uid = Column(Integer,
                      ForeignKey('config_elements.elem_uid'),
                      nullable=False, primary_key=True)
    config_table = relationship("ConfigTables")
    config_elements = relationship("ConfigElements")
    position = Column(Integer)


class ConfigElementDefaultValues(Base):
    """
    Schema definition for Hydra config_element_default_values table
    """
    __tablename__ = 'config_element_default_values'

    def_uid = Column(Integer, primary_key=True, nullable=False)
    # -- the 'leaf' element for which this default value applies
    elem_uid = Column(Integer,
                      ForeignKey('config_elements.elem_uid'),
                      nullable=False)
    config_elements = relationship("ConfigElements")
    value_string = Column(Text)
    value_int = Column(Integer)
    index1_value = Column(Integer)
    index2_value = Column(Integer)
    index3_value = Column(Integer)
    # -- an MD5 hash of the contents of the name and the index info
    hash = Column(VARCHAR(33))


class SubfwDefaults(Base):
    """
    Schema definition for Hydra subfw_defaults table
    """
    __tablename__ = 'subfw_defaults'

    subfw_uid = Column(Integer,
                       ForeignKey('subsystem_firmware_versions.subfw_uid'),
                       primary_key=True, nullable=True)
    def_uid = Column(Integer,
                     ForeignKey('config_element_default_values.def_uid'),
                     primary_key=True, nullable=True)
    subsystem_firmware_versions = relationship("SubsystemFirmwareVersions")
    config_element_default_values = relationship("ConfigElementDefaultValues")


class DefaultArrays(Base):
    """
    Schema definition for Hydra default_arrays table
    """
    __tablename__ = 'default_arrays'

    # rowid is a fake primary key to keep SQLalchemy
    rowid = Column(Integer, primary_key=True)
    def_uid = Column(Integer,
                     ForeignKey('config_element_default_values.def_uid'))
    config_element_default_values = relationship("ConfigElementDefaultValues")
    value = Column(Integer)


class Functions(Base):
    """
    Schema definition for Hydra functions table
    """
    __tablename__ = 'functions'

    func_uid = Column(Integer, primary_key=True, nullable=True)
    elem_uid = Column(Integer, ForeignKey('config_elements.elem_uid'))
    config_element = relationship('ConfigElements')
    function_name = Column(VARCHAR(80))
    type = Column(VARCHAR(20))
    is_for_vif = Column(Boolean, default=False)
