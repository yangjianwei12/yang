"""Create consistent logger for all modules"""
import logging


def create_logger():
    """helper function to create logger in xml2sdb modules"""
    logger = logging.getLogger("xml2sdb")
    if not logger.hasHandlers():
        strm_hndlr = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        strm_hndlr.setFormatter(formatter)
        logger.addHandler(strm_hndlr)
    return logger
