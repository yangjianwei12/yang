"""
Write HTML Documentation of XML contents
"""
#
# QUALCOMM_COPYRIGHT_STATEMENT
#

from pathlib import Path
from re import sub

import jinja2

from xml2sdb.mib import Mib

jinja2_env = jinja2.Environment(loader=jinja2.PackageLoader("xml2sdb", "templates"))


def _clean_string(data):
    """
    For backwards compatibility with the previous implementation in Perl,
    there is a need to do special processing on some strings
    """
    data = sub(r'^\s*\n+', '', data)
    data = sub(r'\n\s+$', '', data)
    data = sub(r'^\s+$', '', data)
    data = sub(r'^\\n', '', data)
    data = data.rstrip()
    if data.isspace():
        data = None
    return data


def process_config_elements(config_elem):
    """
    For a given config_element, find all the values in and under it
    for adding into the database
    """
    needs_clean = ['description_user', 'description_internal', 'label']
    default_list = []
    local_values = dict(config_elem.attrib).copy()

    for sub_elems in config_elem.getchildren():
        if sub_elems.tag == 'default_list':
            for i in range(config_elem.default_list.countchildren()):
                default_list.append(
                    [config_elem.default_list.default[i],
                     config_elem.default_list.default[i].attrib])

        if sub_elems.text:
            local_values[sub_elems.tag] = sub_elems.text
    for tag, data in local_values.items():
        if tag == 'is_internal':
            local_values[tag] = data == 'true'
        elif tag == 'is_array':
            if data.isdigit():
                local_values[tag] = bool(int(data))
            else:
                local_values[tag] = data == 'true'
        elif tag in needs_clean:
            local_values[tag] = _clean_string(data)
    return local_values


def parse_xml_file(xml_file, xsd_file):
    """
    Read XML file and write to external sdb database file
    """
    config_elems = []
    xml_data = Mib(xml_xsd=xsd_file)
    xml_data.parse(xml_file)
    for mdata in xml_data.xml_doc.iter('metadata_list'):
        for metadata in mdata.iterchildren('metadata'):
            for config_element in metadata.iterchildren('config_element'):
                config_elems.append(process_config_elements(config_element))
    return config_elems


def write_html(data, html_file):
    """
    Write data dictionary to html file
    """
    template = jinja2_env.get_template('base.jinja2')
    output_str = template.render(data=data)
    Path(html_file).write_text(output_str, encoding='utf-8')
