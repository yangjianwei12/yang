"""
Writing information to database file
"""

#
# QUALCOMM_COPYRIGHT_STATEMENT
#

from sqlalchemy import (Column, Integer, VARCHAR, Text, Boolean,
                        ForeignKey, text)
from sqlalchemy import create_engine, func, select
from sqlalchemy.dialects.sqlite import DATETIME
from sqlalchemy.orm import declarative_base, sessionmaker, relationship

from xml2sdb.schema import (
    Base,
    ConfigElementDefaultValues,
    ConfigElements,
    ConfigTableIndices,
    ConfigTables,
    DefaultArrays,
    EnumDefs,
    EnumEntry,
    Functions,
    SchemaVersion,
    StructDefs,
    StructureElements,
    SubfwElements,
    SubsystemFirmwareVersions,
    SystemEfuseHashes,
    SystemSubfwVersions,
    SystemVersions,
)


class ConnectDB:
    """
    Comment to the database object
    """
    def __init__(self, db_filename, memory_only=False, echo=False):
        if memory_only:
            self.engine = create_engine('sqlite:///:memory:', echo=echo)
        else:
            self.engine = create_engine(
                'sqlite:///{}'.format(db_filename),
                echo=echo)
        # pylint: disable=invalid-name
        self.Session = sessionmaker(bind=self.engine)
        # pylint: enable=invalid-name
        self.session = self.Session()

    def create_new(self):
        """
        Create empty tables in the specified database
        """
        Base.metadata.drop_all(self.engine)
        Base.metadata.create_all(self.engine)
        self.add_schema_version(3, 1, '')

    def get_subsystems(self):
        """Return the rows from the subsystem_firmware_versions table"""
        return [row for row in self.session.query(
            SubsystemFirmwareVersions).all()]

    def get_subsys_firm_ver(self, subsystem_name, fw_version,
                            fw_layer=None, fw_variant=None):
        """
        For the specified parameters, return the database row
        """
        # stmt = (
        #     select(SubsystemFirmwareVersions).where(
        #         SubsystemFirmwareVersions.subsystem_name == subsystem_name)
        # )
        #
        # for result in self.session.execute(stmt):
        #     print(result)
        # return result[0]

        queries = self.session.query(SubsystemFirmwareVersions, func.max(
            SubsystemFirmwareVersions.subfw_uid))
        if subsystem_name:
            queries = queries.filter_by(subsystem_name=subsystem_name)
        if fw_version:
            queries = queries.filter_by(version=fw_version)
        if fw_layer:
            queries = queries.filter_by(subsystem_layer=fw_layer)
        if fw_variant:
            queries = queries.filter_by(variant=fw_variant)
        return queries.one().SubsystemFirmwareVersions


    def get_subsystem_firmware_versions(self, subfw_uid):
        """
        Return the rows from subsystem_firmware_versions table with the given
        subfw_uid
        """
        # "SELECT version FROM subsystem_firmware_versions
        # WHERE subfw_uid=$subfw_uid";
        return [r.version for r in
                self.session.query(
                    SubsystemFirmwareVersions.version).filter_by(
                        subfw_uid=subfw_uid
                    )]

    def add_chip_data(self, data):
        """
        Add chip specification into database
        """
        # system_uid = self.get_last_system_uid()
        sub_sys_info = data['subsystem_info']
        # metadat_hash = self.calculate_metadata_hash(sub_sys_info)
        metadat_hash = 'no_implemented'
        # INSERT INTO system_versions (system_uid, chip_name, chip_id,
        # rom_name, rom_version, patch_release_level, system_version_label,
        # system_description, customer_name, system_release_date_time,
        # metadata_hash) ";

        sys_ver = SystemVersions(
            chip_name=data['chip_name'],
            chip_id=data['chip_id'],
            rom_name=data['rom_name'],
            rom_version=data['rom_version'],
            patch_release_level=data['patch_release_level'],
            system_version_label=data['system_version_label'],
            system_description=data['system_description'],
            customer_name=data['customer_name'],
            # system_release_date_time=build_dt_obj,
            system_release_date_time=data['system_release_date_time'],
            metadata_hash=metadat_hash)
        self.session.add(sys_ver)
        # INSERT INTO system_efuse_hashes (system_uid, efuse_hash) ";
        for efuse_hash in data['efuse_hash']:
            sys_efuse_hash = SystemEfuseHashes(system_versions=sys_ver,
                                               efuse_hash=efuse_hash)
            self.session.add(sys_efuse_hash)
        # "INSERT INTO system_subfw_versions (system_uid, subfw_uid)
        # VALUES ($system_uid, $subfw_uid)");
        sysfw_vers = []
        for sub_sys in sub_sys_info:
            ss_firm_ver = self.get_subsys_firm_ver(
                subsystem_name=sub_sys,
                fw_version=sub_sys_info[sub_sys]['fw_version'],
                fw_layer=sub_sys_info[sub_sys]['layer'],
                fw_variant=sub_sys_info[sub_sys]['fw_variant']
            )
            sysfw_ver = SystemSubfwVersions(
                system_versions=sys_ver,
                subsystem_firmware_versions=ss_firm_ver
            )
            
            self.session.add(sysfw_ver)
        # "INSERT INTO patch_files (subfw_uid, patch_level, patch_hash)
        # VALUES ($subfw_uid, $patch_level, '$patch_hash')"
        # print(system_uid, subfw_uid)
        # self.session.add_all([sysfw_vers,
        #                       sys_efuse_hash])
        # self.session.add_all(sysfw_vers)
        self.session.commit()

    def add_schema_version(self, schema_version, minor_version, comment):
        """
        Add scheme information into the database
        """
        data_dict = {'schema_version': schema_version,
                     'minor_version': minor_version,
                     'comment': comment}
        if not self.get_instance(SchemaVersion, **data_dict):
            self.session.query(SchemaVersion).delete()
            schema_version = SchemaVersion(**data_dict)
            self.session.add(schema_version)
            self.session.commit()

    def get_instance(self, model, **data_dict):
        """Return first instance found."""
        return self.session.query(model).filter_by(**data_dict).first()

    def get_all(self, model):
        """Return all instances in a table"""
        return self.session.query(model).all()

    def get_enum_for_subfw_uid(self, subfw_uid):
        """Get all enum_defs for a given subfw_uid"""
        sub_query = self.session.query(
            SubfwElements.enum_uid).distinct().filter_by(
                subfw_uid=subfw_uid)
        return [row for row in self.session.query(
            EnumDefs).filter(EnumDefs.enum_uid.in_(sub_query))]

    def get_enum_entries_for_enum_uid(self, enum_uid):
        """Get all the enum_entries for a give enum_uid"""
        return [row for row in self.session.query(
            EnumEntry).filter_by(enum_uid=enum_uid).all()]

    def get_enum_entries_for_enum_name(self, enum_name):
        """Get all enum entries for a given enum_name"""
        sub_query = self.session.query(EnumDefs.enum_uid).filter_by(
            enum_name=enum_name)
        return [row
                for row in self.session.query(EnumEntry).filter(
                    EnumEntry.enum_uid.in_(sub_query))
                ]

    def get_functions_by_elem_uid(self, elem_uid):
        """Get all the functions for a given elem_uid"""
        return [row
                for row in self.session.query(
                    Functions).filter_by(elem_uid=elem_uid)]

    def get_struct_by_subfw_uid(self, subfw_uid):
        """Get all subfw_elements rows for a give subfw_uid"""
        sub_query = self.session.query(
            SubfwElements.struct_uid).distinct().filter_by(
                subfw_uid=subfw_uid)
        return [row for row in self.session.query(
            StructDefs).filter(StructDefs.struct_uid.in_(sub_query))]

    def get_struct_elem_by_struct_uid(self, struct_uid):
        """Get all structure_elements for a given struct_uid"""
        return [row for row in self.session.query(
            StructureElements).filter_by(struct_uid=struct_uid).all()]

    def get_structure_elements(self, struct_name):
        """
        Get all structure elements for a given struct_name.
        Returned in order (based on little-endian)
        i.e not the order specified by the lsb_bit_position
        """
        msb_unorder = {}
        result = []
        for row in self.session.query(StructureElements).join(
                ConfigElements).join(StructDefs).filter(
                    StructDefs.struct_name == struct_name):

            msb_unorder[self._msb_position(row.lsb_bit_position)] = row
        for msb_key in sorted(msb_unorder.keys()):
            result.append(msb_unorder[msb_key])
        return result

    def get_config_elem_by_subfw_uid(self, subfw_uid):
        """Get all subfw_elements for a given subfw_uid"""
        return [row for row in self.session.query(
            SubfwElements).filter_by(
                subfw_uid=subfw_uid).outerjoin(
                    ConfigTables).all()]

    def get_config_table_by_subfw_uid(self, subfw_uid):
        """Get all comfig_table rows for a give subfw_uid"""
        sub_query = self.session.query(
            SubfwElements.table_uid).filter_by(subfw_uid=subfw_uid)
        return [row for row in self.session.query(ConfigTables).filter(
            ConfigTables.table_uid.in_(sub_query))]

    def get_default_by_elem_uid(self, elem_uid):
        """
        For a given elem_uid, look in the config_element_default_values and
        default_arrays tables and return values associated with the elem_uid
        """
        non_array = self.session.query(ConfigElementDefaultValues).filter_by(
            elem_uid=elem_uid).all()
        return non_array

    def get_default_array_by_def_uid(self, def_uid):
        """Get all default_array rows for a given def_uid"""
        output = self.session.query(DefaultArrays.value).filter_by(
            def_uid=def_uid).all()
        # flatten the list before returning
        return [row[0] for row in output]

    def get_table_index_by_table_uid(self, table_uid):
        """Get all table indices for a given table_uid"""
        return [row
                for row in self.session.query(
                    ConfigTableIndices).filter_by(
                        table_uid=table_uid).join(ConfigElements)
                ]

    def get_type_for_default(self, ce_type, type_list=None):
        """
        Recursively look up what type structure_elements while they are a
        struct_def or enum_def
        """
        if type_list is None:
            type_list = []
        # get type
        enum_lookup = self.get_enum_entries_for_enum_name(ce_type)
        is_enum = len(enum_lookup) > 0
        struct_lookup = self.get_structure_elements(ce_type)
        is_struct = len(struct_lookup) > 0

        if is_enum:
            type_list.append(ce_type)
        elif is_struct:
            type_list.append([])
            for struct in struct_lookup:
                type_list[-1].extend(
                    self.get_type_for_default(
                        struct.config_elements.type)
                )
        else:
            type_list.append(ce_type)
        return type_list

    def row_with_hash(self, hash_value, table_model):
        """
        Return the row from a given table with matching hash value
        """
        return self.session.query(table_model).filter_by(
            hash=hash_value).one_or_none()

    def is_hash_in_table(self, hash_value, table_model):
        """
        Return a logic value for if the hash exists in the given table
        """
        rows = self.row_with_hash(hash_value, table_model)
        return rows is not None

    @staticmethod
    def _msb_position(lsb_bit_position):
        """
        Find the start bit position using little-endian rather than
        the big-endian in the database
        """
        # reverse bit ordering in a 16-bit word to ensure defaults are in the
        # correct order (MSB first within each word)
        word = int(lsb_bit_position) // 16
        msb_bit_position = 15 - (int(lsb_bit_position) % 16)
        msb_bit_position += (16 * word)
        return msb_bit_position

    @staticmethod
    def _row2dict(row):
        """
        Return a database row as a python dictionary
        """
        data = {}
        for column in row.__table__.columns:
            # data[column.name] = str(getattr(row, column.name))
            data[column.name] = getattr(row, column.name)
        return data

    def get_last_system_uid(self):
        """
        Get the last entry from the system_versions table
        """
        # "SELECT max(system_uid) FROM system_versions"
        return self.session.query(
            SystemVersions, func.max(
                SystemVersions.system_uid)).first().SystemVersions.system_uid

    def get_max_subfw_uid(self, subsystem_name, fw_version,
                          fw_variant=None, fw_layer=None):
        """
        For the given configuration, return the subfw_uid
        """
        # "SELECT max(subfw_uid) FROM subsystem_firmware_versions
        # WHERE subsystem_name='$subsystem' and version=$fw_version
        # and variant=$fw_variant";
        subsys_firm_ver = self.get_subsys_firm_ver(
            subsystem_name=subsystem_name,
            fw_version=fw_version,
            fw_variant=fw_variant,
            fw_layer=fw_layer)
        return subsys_firm_ver.subfw_uid

