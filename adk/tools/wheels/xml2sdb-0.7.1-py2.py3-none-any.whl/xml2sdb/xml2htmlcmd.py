"""
This module contains the business logic for reading an Hydra Config XML file
and writing it to an HTML file for documentation
"""

#
# QUALCOMM_COPYRIGHT_STATEMENT
#

# Python imports
import argparse

import sys

# Package imports
from xml2sdb.writehtml import parse_xml_file, write_html


def build_html_from_xml(xml_file, html_file, xsd_file):
    """Write html documentation for contents of MiB xml file"""
    data = parse_xml_file(xml_file, xsd_file)
    write_html(data, html_file)


def _parse_args(args):
    """
    Define what commandline options are available
    """
    default_xsd = None

    parser = argparse.ArgumentParser(
        description="""Process chip config XML files and create HTML documentation""")
    parser.add_argument('-i', '--xml_file',
                        required=True,
                        help='location of input XML file')
    parser.add_argument('-o', '--html_file',
                        required=True,
                        help='location of HTML file')
    parser.add_argument('-x', '--xsd_file', default=default_xsd,
                        help='location of XML Schema file to use for validation')
    return parser.parse_args(args)


def run(args=None):
    """
    Main entry point when running on the command line
    """
    args = _parse_args(args)
    build_html_from_xml(args.xml_file, args.html_file, args.xsd_file)


if __name__ == '__main__':
    run(sys.argv[1:])
