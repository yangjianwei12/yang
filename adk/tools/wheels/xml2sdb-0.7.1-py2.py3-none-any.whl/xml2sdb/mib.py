"""
Collection of classes and function to read HydraMeta configuration information
from XML files
"""

#
# QUALCOMM_COPYRIGHT_STATEMENT
#

import logging
from lxml import etree, objectify

logger = logging.getLogger(__name__)


class Mib:
    """Store Hydra XML data read from XML file"""
    def __init__(self, xml_xsd='HydraMeta'):
        self.xml_xsd = xml_xsd
        if self.xml_xsd:
            xmlschema_doc = etree.parse(str(self.xml_xsd))
            xmlschema = etree.XMLSchema(xmlschema_doc)
            self.parser = objectify.makeparser(schema=xmlschema,
                                               remove_blank_text=False)
        self.xml_doc = None

    def parse(self, xml_file):
        """
        Read, verify and store XML data in an internal Python model
        """
        xml_string = self.read_xml_file(xml_file)
        self.make_xml_object(xml_string)

    @staticmethod
    def read_xml_file(xml_file):
        """
        Read XML file and returns string of document ready to pass to parser
        """
        logger.debug('Reading %s', xml_file)
        with open(xml_file, encoding='utf-8') as xml_fh:
            xml = xml_fh.readlines()
            xml_string = ''.join(xml).encode('utf-8')
        return xml_string

    def make_xml_object(self, xml_string):
        """
        Parse XML string. Can be parsed with or without schema checking against
        XSD file. Default is to check against schema.
        Stores the result in an internal Python model ready for use
        """
        if self.xml_xsd:
            self.xml_doc = objectify.fromstring(xml_string, self.parser)
        else:
            self.xml_doc = objectify.fromstring(xml_string)
