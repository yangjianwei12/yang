def main():
    runner(XPathCommand)
    
if __name__ == "__main__":
    main()
