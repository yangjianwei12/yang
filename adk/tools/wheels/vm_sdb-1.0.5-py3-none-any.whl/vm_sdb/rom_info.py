
from dataclasses import dataclass

@dataclass
class RomInfo:
    name: str
    version: str
    patch: str
