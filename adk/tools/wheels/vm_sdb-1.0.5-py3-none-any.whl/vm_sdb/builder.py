"""
Base class for common functionality
"""

from abc import ABCMeta, abstractmethod
from pathlib import Path

import logging

from vm_core.configure_logging import add_print_logging_level

from .config.database import DatabaseConfig
from .utils.os_variant import get_os_variant


add_print_logging_level()


class Builder(): # pylint: disable=too-few-public-methods
    """
    Common base class for SDBBuilder and DocBuilder
    """
    __metaclass__ = ABCMeta

    def __init__(self, chip_family, os_variant=None):
        self._log = logging.getLogger(__name__)
        self._chip_family = chip_family
        self._config = DatabaseConfig(chip_family)
        self._os_variant = get_os_variant(os_variant, chip_family, self._config.subsystems)
        self._subsystems = self._get_subsystems()

    def _get_expanded_xml_file(self, xml_file):
        return Path(str(xml_file).format(os=self._os_variant))

    def _get_subsystems(self):
        """
        Return a list of subsystems that include an xml data file
        """
        return [subsystem.name
                for subsystem in self._config.subsystems
                if Path(self._get_expanded_xml_file(subsystem.xml_file)).is_file()]

    @abstractmethod
    def build(self):
        """Perform the class specific build action."""
        raise RuntimeError('Not implemented')
