
from dataclasses import dataclass
from pathlib import Path

@dataclass
class SubsystemInfo:
    name: str
    id: str
    xml_file: Path
