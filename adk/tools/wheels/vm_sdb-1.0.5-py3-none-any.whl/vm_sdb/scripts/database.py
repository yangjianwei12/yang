'''
Wrapper script for running database generation module
'''

from pathlib import Path
from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
import logging

from vm_core.configure_logging import configure_logging, log_level_to_int
from vm_core.configure_logging_arguments import add_arguments as add_logging_arguments
from vm_core.package_info import package_version

from ..sdb import build
from ..version import __version__


def _get_parser():
    """
    create the parser
    """
    parser = ArgumentParser(
        description='Build database and database related documentation',
        formatter_class=ArgumentDefaultsHelpFormatter,
        epilog=package_version(__package__, __version__)
    )
    parser.add_argument(
        '-c', '--chip_family',
        nargs='*',
        required=True,
        dest='chip_families',
        help='List of chip families to include in the .sdb database. This is usually a single chip family'
    )
    parser.add_argument(
        '--os', '--os_variant',
        dest='os_variant',
        help='The os variant to select. If not specified, the first folder found in os/[chip_family] '
             'will be selected'
    )
    parser.add_argument(
        '-s', '--sdb',
        dest='sdb',
        type=Path,
        help='The full path to the database to be created. '
              'Default: adk/bin/[chip_family]/hydracore_config.sdb'
    )
    add_logging_arguments(parser)
    return parser


def process_commandline_arguments():
    parser = _get_parser()
    return parser.parse_args()


def _set_xml2sdb_log_level(log_level):
    # xml2sdb DEBUG logging is too verbose. Ensure it never goes above INFO
    logging.getLogger('xml2sdb').setLevel(max(log_level_to_int(log_level), logging.INFO))


def main():
    """
    This is a wrapper script for database generation tools
    """
    args = process_commandline_arguments()
    configure_logging(args.log_level)
    _set_xml2sdb_log_level(args.log_level)
    build(args.chip_families, args.sdb, args.os_variant)


if __name__ == '__main__':
    main()
