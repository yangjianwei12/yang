"""
A script to display a list of Console scripts provided by the package along with
the version of the package.
"""

from vm_core.package_info import PackageInfo

from ..version import __version__


def main():
    print(PackageInfo(__package__, __version__))


if __name__ == '__main__':
    main()
