
from pathlib import Path
import logging

from ..utils.adk_root import adk_sdb_mib_xml_root


logger = logging.getLogger(__name__)
OS_NAME = 'apps0'
OS_FOLDER = 'os'


def get_os_variant(os_variant, chip_family, subsystems):
    """
    Required
    Walk through all folders in os/[chip_family]/
    There should only be 1 folder and that will be the os_variant
    """
    if os_variant:
        # Always validate if an os_variant is passed in
        _validate(os_variant, chip_family)
        return os_variant
    if _os_in_subsystems(subsystems):
        os_folder = adk_sdb_mib_xml_root(OS_FOLDER, chip_family)
        logger.debug(f'Scanning folder: {os_folder}, to determine os_variant')
        folders = [folder for folder in os_folder.iterdir() if folder.is_dir()]
        if len(folders) == 0:
            logger.debug('No OS variants found')
            return None
        if len(folders) > 1:
            logger.warning(f'Possible multiple os_variants detected: {folders}')
        os_variant = folders[0].name
        logger.debug(f'Using OS: {os_variant}')
        return os_variant
    logger.debug(f'Subsystem: {OS_NAME} not in subsystems')
    return None

def _validate(os_variant, chip_family):
    os_path = adk_sdb_mib_xml_root(OS_FOLDER, chip_family)
    if not os_path.exists() and not os_path.is_dir():
        logger.debug(f'No chip family specific OS folder found: {os_path}')
        raise RuntimeError(f'Missing chip family folder for OS: {os_path}')
    os_variant_path = Path(os_path, os_variant)
    if not os_variant_path.is_dir():
        logger.debug(f'No OS Variant folder: {os_variant_path}')
        raise RuntimeError(f'Missing OS Variant folder: {os_variant_path}')

def _os_in_subsystems(subsystems):
    """Determine if there is an OS subsystem."""
    for subsystem in subsystems:
        if subsystem.name == OS_NAME:
            return True
    return False
