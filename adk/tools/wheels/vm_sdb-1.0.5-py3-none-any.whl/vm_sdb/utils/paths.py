"""
Determine the name of the sdb.

In priority order:
  1. Supplied name
  2. Defined in database config file
  3. Default defined in this file

"""

from pathlib import Path

from .adk_root import adk_destination_root

# for legacy support where no sdb path is provided in config file
DEFAULT_SDB_PATH = str(Path('adk', 'bin', '{chip_family}', 'hydracore_config.sdb'))
DEFAULT_DOCUMENTATION_PATH = str(Path('adk', 'bin', '{chip_family}'))

def _get_path(path, chip_family=None):
    if not path and not chip_family:
        raise RuntimeError('Must specify a chip family if no sdb name is provided')
    path = Path(str(path).format(chip_family=chip_family))
    if path.is_absolute():
        return path
    return Path(adk_destination_root(), path)


def get_sdb_path(sdb_path, config, chip_family=None):
    sdb_path = sdb_path or config.sdb_path or DEFAULT_SDB_PATH
    return _get_path(sdb_path, chip_family)


def get_documentation_path(documentation_path, config, chip_family=None):
    documentation_path = documentation_path or config.documentation_path or DEFAULT_DOCUMENTATION_PATH
    return _get_path(documentation_path, chip_family)
