"""
Helper methods to read root paths from environment variables
"""

from pathlib import Path
from os import getenv
import logging


logger = logging.getLogger(__name__)


ADK_ROOT_DEFAULT = '.'
ADK_ROOT = 'ADK_ROOT'
ADK_DESTINATION_ROOT = 'ADK_DESTINATION_ROOT'
ADK_SDB_MIB_XML_ROOT = 'ADK_SDB_MIB_XML_ROOT'


def _adk_root():
    """
    If the OS environment variable ADK_ROOT is set, return its value.
    Else return ADK_ROOT_DEFAULT
    """
    return getenv(ADK_ROOT, ADK_ROOT_DEFAULT)


def _adk_sdb_mib_xml_root():
    """
    If the OS environment variable ADK_SDB_MIB_XML_ROOT is set, return its value.
    Else return adk_root()
    """
    return getenv(ADK_SDB_MIB_XML_ROOT, _adk_root())


def _adk_destination_root():
    """
    If the OS environment variable ADK_DESTINATION_ROOT is set, return its value.
    Else return adk_root()
    """
    return getenv(ADK_DESTINATION_ROOT, _adk_root())


def adk_root(*args):
    """
    Return a Path object representing the path to the root of the ADK source, modified by *args.
    """
    path = Path(*args)
    if path.is_absolute():
        return path
    return Path(_adk_root(), path).resolve()


def adk_sdb_mib_xml_root(*args):
    """
    Return a Path object representing the path to the root folder where
    the sdb mib xml source is located.
    """
    path = Path(*args)
    if path.is_absolute():
        return path
    return Path(_adk_sdb_mib_xml_root(), path).resolve()


def adk_destination_root(*args):
    """
    Return a Path object representing the path where any dynamically created
    ADK files should be created, modified by *args.
    """
    path = Path(*args)
    if path.is_absolute():
        return path
    return Path(_adk_destination_root(), path).resolve()
