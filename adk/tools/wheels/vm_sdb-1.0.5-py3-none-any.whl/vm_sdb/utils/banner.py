"""
Display a banner
"""

import logging

def banner(title, logger=logging.debug): # pylint: disable=no-member
    """
    Display a banner heading string
    """
    length = len(title) + 4
    logger('-' * length)
    logger(f'| {title} |')
    logger('-' * length)
