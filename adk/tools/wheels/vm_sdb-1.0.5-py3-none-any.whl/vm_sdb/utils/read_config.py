"""
Helper function to read a json or yaml config file
"""

from pathlib import Path
import json
import logging
import yaml


def _json_handler(fp):  # pylint: disable=invalid-name
    return json.load(fp)


def _yaml_handler(fp):  # pylint: disable=invalid-name
    return yaml.load(fp, Loader=yaml.FullLoader)


def _get_handler(file_type):
    file_type = file_type.lower()
    if file_type == '.json':
        return _json_handler
    if file_type == '.yaml':
        return _yaml_handler
    raise RuntimeError(f'Unsupported file format: {file_type}')


def read_config(config_file, encoding='utf-8', file_not_found_ok=False, default_return=None):
    """ Read the json data file and return its contents as a dictionary object """
    # YAML files could return strings or dicts or lists, and json always returns a dict
    default_return = default_return if default_return is not None else {}
    logger = logging.getLogger(__name__)
    logger.debug(f'Reading: {config_file}')
    try:
        with open(config_file, 'r', encoding=encoding) as fp:  # pylint: disable=invalid-name
            file_type = Path(config_file).suffix
            try:
                data = _get_handler(file_type)(fp)
                return data
            except (json.decoder.JSONDecodeError, yaml.YAMLError):
                logger.error(f'Reading: {config_file}')
                raise
    except FileNotFoundError:
        if file_not_found_ok:
            logger.debug(f'File not found: {config_file}')
            return default_return
        logger.error(f'File not found error: {config_file}')
        raise
