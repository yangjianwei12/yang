"""
Module to build database
"""
from os import write as os_write
from os import close as os_close
from os import remove as os_remove
from xml.etree import cElementTree as ET

import tempfile

from xml2sdb.xml2sdbcmd import create_new, build_db_from_xml, build_system_info

from .builder import Builder
from .utils.paths import get_sdb_path
from .utils.banner import banner


class SDBBuilder(Builder): # pylint: disable=too-few-public-methods
    """
    Class for creating a config database by looking up the config
    metadata for the builds described in the network subsystem projects.
    """
    def _clean(self, sdb):
        """
        Ensure Folder exists and delete existing database
        """
        sdb.parent.mkdir(parents=True, exist_ok=True)
        if sdb.exists():
            sdb.unlink()

    def _create_empty_sdb(self, sdb):
        """
        Create an empty database file
        """
        self._clean(sdb)
        self._log.info(f'Creating empty database: {sdb}')
        create_new(str(sdb))

    def _get_version(self, xml_file):
        """
        Find version in subsystem XML file
        """
        xml_file = self._get_expanded_xml_file(xml_file)
        xml = ET.parse(xml_file).getroot()
        metadata = xml.find('metadata')
        xml_ver = metadata.attrib["version"]
        self._log.debug(f'xml_file: {xml_file}, version: {xml_ver}')
        return xml_ver

    def _get_sys_description(self):
        """
        Generate system description
        """
        versions = ', '.join([f'0x{self._config.chip_version_id:02X}',
                              f'0x{self._config.rom_info.version:04X}',
                              f'0x{0:04X}'])
        subsystems = '\n'.join([f'{subsystem.id}={self._get_version(subsystem.xml_file)}'
                                for subsystem in self._config.subsystems
                                if subsystem.name in self._subsystems])
        sdb_description = (
            f'{self._chip_family}\n'
            f'{self._config.rom_info.name}\n'
            f'{versions}\n'
            '0\n'
            f'{self._config.chip_id}_CONFIG\n'
            f'{self._config.chip_id} Configuration\n'
            'Generic\n'
            'now\n'
            f'{subsystems}'
        )
        self._log.debug(f'System Description:\n{sdb_description}')
        return sdb_description

    def _write_sys_desc(self, description):
        """
        Write database system description to a temporary file
        """
        handle, filename = tempfile.mkstemp()
        self._log.debug(f'Writing system descritpion to temporary file: {filename}')
        os_write(handle, bytes(description, 'utf-8'))
        os_close(handle)
        return filename

    def _add_sys_descr(self, sdb):
        """
        Add system description to database
        """
        self._log.print("Collecting system description information")
        system_descrition = self._get_sys_description()
        tmp_file = self._write_sys_desc(system_descrition)
        self._log.print("Adding system description")
        build_system_info(tmp_file, sdb)
        self._log.debug(f'Deleting temporary file: {tmp_file}')
        os_remove(tmp_file)

    def _add_subsystems_to_sdb(self, sdb):
        for subsystem in self._config.subsystems:
            if subsystem.name in self._subsystems:
                self._log.print(f'Adding: {subsystem.name}')
                xml_file = self._get_expanded_xml_file(subsystem.xml_file)
                self._log.debug(f'Adding: {xml_file} to sdb file')
                build_db_from_xml(xml_file, sdb, xsd_file=self._config.schema)
            else:
                self._log.debug(f'No xml file found for subsystem: {subsystem.id}')

    def build(self, **kwargs):
        """
        Run the overall process creating the database
        """
        banner(f'Build Database for {self._chip_family}')
        self._log.print(f'Building database for chip family: {self._chip_family}')
        self._log.info(f'Using schema: {self._config.schema}')
        sdb_path = kwargs.get('sdb_path')
        sdb = get_sdb_path(sdb_path, self._config, self._chip_family)
        self._create_empty_sdb(sdb)
        self._add_subsystems_to_sdb(sdb)
        self._add_sys_descr(sdb)
        self._log.print(f'Database successfully created: {sdb}')
