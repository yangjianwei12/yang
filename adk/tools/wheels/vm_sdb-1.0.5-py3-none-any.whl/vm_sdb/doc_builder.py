"""
Module to build documentation from database file
"""

from pathlib import Path

from xml2sdb.xml2htmlcmd import build_html_from_xml

from .builder import Builder
from .utils.banner import banner
from .utils.paths import get_documentation_path


class DocBuilder(Builder):  # pylint: disable=too-few-public-methods
    """
    Class for creating documentation for the specified chip
    """
    def _generate_docs(self, documentation_path):
        for subsystem in self._config.subsystems:
            if subsystem.name in self._subsystems:
                self._log.print(f'Generating documentation for: {subsystem.name}')
                xml_file = self._get_expanded_xml_file(subsystem.xml_file)
                documentation_path = get_documentation_path(documentation_path, self._config, self._chip_family)
                html_file = Path(documentation_path, f'{subsystem.id}.html')
                self._log.debug(f'Generating documentation: {html_file}')
                html_file.parent.mkdir(parents=True, exist_ok=True)
                build_html_from_xml(xml_file, html_file, xsd_file=self._config.schema)
            else:
                self._log.debug(f'No xml file found for subsystem: {subsystem.id}')

    def build(self, **kwargs):
        """Build the documentation."""
        banner('Build Database Documentation')
        self._log.print(f'Generating documentation for {self._chip_family}')
        self._log.info(f'Using schema: {self._config.schema}')
        documentation_path = kwargs.get('documentation_path')
        self._generate_docs(documentation_path)
        self._log.print(f'Documentation built for {self._chip_family}')
