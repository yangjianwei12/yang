"""
Build sdb database and html mib documentation
"""

from .doc_builder import DocBuilder
from .sdb_builder import SDBBuilder


def build(chip_families, sdb_path=None, documentation_path=None, os_variant=None):
    if not isinstance(chip_families, (list, tuple, set)):
        chip_families = [chip_families]
    for chip_family in chip_families:
        SDBBuilder(chip_family, os_variant).build(sdb_path=sdb_path)
        DocBuilder(chip_family, os_variant).build(documentation_path=documentation_path)
