"""
Common base class for config classes

Reads the config file, and provides a simple str function using yaml to output the data

Overrides
=========
All derived classes should override the yaml_tag class variable.

If derived classes require more control over printed class output then they
should override the to_yaml() function

"""

from abc import ABCMeta
from pathlib import Path
import logging

from yaml import dump, YAMLObject

from ..utils.adk_root import adk_root
from ..utils.read_config import read_config


class BaseConfig(YAMLObject):
    __metaclass__ = ABCMeta
    yaml_tag = '!BaseConfig'

    def __init__(self, config_file, file_not_found_ok=False):
        self._log = logging.getLogger(__name__)
        if not config_file.is_absolute():
            config_file = adk_root(config_file)
        self._config_file = config_file
        self._file_not_found_ok = file_not_found_ok
        self._config = read_config(self._config_file, file_not_found_ok=file_not_found_ok)
        self._set_attributes()

    def __str__(self):
        return dump(self, indent=2, sort_keys=False)

    def _set_attributes(self):
        """Make top level dictionary object from the config data available as attributes."""
        for key, value in self.config.items():
            setattr(self, key, value)

    @property
    def config(self):
        return self._config

    @classmethod
    def to_yaml(cls, dumper, data):
        if isinstance(data.config, dict):
            return dumper.represent_dict(data.config)
        if isinstance(data.config, list):
            return dumper.represent_list(data.config)
        raise RuntimeError(f'Unsupported data type: {type(data.config)}')
