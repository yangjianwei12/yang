"""
Read the database config file, and provide methods to access the data.
"""

from pathlib import Path
import logging

from .base_config import BaseConfig
from .common import database_config
from ..rom_info import RomInfo
from ..subsystem_info import SubsystemInfo
from ..utils.adk_root import adk_root, adk_sdb_mib_xml_root


logger = logging.getLogger(__name__)

class DatabaseConfig(BaseConfig):
    yaml_tag = '!DatabaseConfig'
    CONFIG_FILE = '{chip_family}.yaml'

    def __init__(self, chip_family):
        config_file = self.CONFIG_FILE.format(chip_family=chip_family)
        super().__init__(Path(database_config, config_file))

    @property
    def chip_version_id(self):
        return self._config['CHIP_VERSION_ID']

    @property
    def chip_id(self):
        return self._config['CHIP_ID']

    @property
    def rom_info(self):
        chip_rom_version = self._config['CHIP_ROM_VERSION']
        name = chip_rom_version.get('rom_name')
        version = chip_rom_version.get('rom_version', 0)
        patch =  chip_rom_version.get('rom_patch', 0)
        return RomInfo(name, version, patch)

    @property
    def sdb_path(self):
        path = self._config.get('SDB_PATH')
        return Path(path) if path else None

    @property
    def documentation_path(self):
        return Path(self._config.get('DOCUMENTATION_PATH'))

    @property
    def schema(self):
        schema = self._config.get('SCHEMA')
        if schema:
            return adk_root(self._config.get('SCHEMA'))
        return None

    @property
    def subsystems(self):
        subsystems = []
        if self._config.get('SUBSYSTEM_INFO'):
            for subsystem, data in self._config.get('SUBSYSTEM_INFO').items():
                xml_file = self._get_xml_file(data)
                if xml_file:
                    subsystems.append(SubsystemInfo(name=subsystem, id=data['sdb_name'], xml_file=xml_file))
                else:
                    logger.debug(f'Ignoring subsystem: {data["sdb_name"]}. xml_file is missing.')
        return subsystems

    def _get_xml_file(self, data):
        xml_file = Path(data.get('xml_file'))
        if not xml_file.is_absolute():
            xml_file = adk_sdb_mib_xml_root(xml_file)
        if xml_file.exists():
            return xml_file
        return None
