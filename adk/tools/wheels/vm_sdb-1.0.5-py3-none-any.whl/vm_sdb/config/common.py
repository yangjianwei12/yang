"""
Class to provide paths to common config files
"""

from pathlib import Path

from ..utils.adk_root import adk_root


database_config = adk_root('adk', 'tools', 'config_data', 'database')
