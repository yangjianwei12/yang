############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2013 - 2019 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
"""
Provides class QCC516x7x_QCC306x7xLabDevice.
"""
# pylint: disable=invalid-name
import textwrap
from csr.wheels.global_streams import iprint
from csr.dev.hw.address_space import AddressSpace
from csr.dev.framework.connection.trb import MRTSTrbTransConnection
from .qcc516x7x_qcc306x7x_device import QCC516x7x_QCC306x7xDevice
from .mixins.resettable_device import BootTimeoutResettableDevice


class QCC516x7x_QCC306x7xLabDevice(QCC516x7x_QCC306x7xDevice, BootTimeoutResettableDevice):
    """\
    QCC516x7x_QCC306x7x lab board (Base)
    """

    # BaseDevice compliance
    @property
    def name(self):
        return 'qcc516x7x_qcc306x7x-lab'

    @property
    def chips(self):

        return (self.components.chip,)

    @property
    def chip(self):
        '''
        A standard lab board has only one chip
        '''
        return self.components.chip

    @property
    def lpc_sockets(self):

        return None

    # Extensions

    @property
    def trb(self):
        '''
        The chip's Tbridge adapter connects directly to the physical Tbridge
        '''
        return self.components.chip.trb_in

