CHIP_VERSION_MAJOR = (0x50,)

def factory(chip_version, chip, transport, access_cache_type):
    
    from ..qcc516x7x_qcc306x7x_lab_device import QCC516x7x_QCC306x7xLabDevice
    return QCC516x7x_QCC306x7xLabDevice(chip, transport, access_cache_type)
