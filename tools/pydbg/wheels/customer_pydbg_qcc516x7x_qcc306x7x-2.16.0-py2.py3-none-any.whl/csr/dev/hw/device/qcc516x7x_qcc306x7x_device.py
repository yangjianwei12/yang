############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2019 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
"""
QCC516x7x_QCC306x7x device
"""
import time
from .base_device import BaseDevice
from csr.wheels.global_streams import iprint
from csr.wheels.bitsandbobs import NameSpace, construct_lazy_proxy, timeout_clock
from csr.dev.hw.address_space import AddressConnection, NullAccessCache
from csr.transport.trb_raw import TrbRaw

# The Apps service should start pretty quickly
APPS_SERVICE_START_TIMEOUT = 2.0

# We need to make sure we wait long enough for the Curator to do its
# thing - probe for SQIFs etc so that we're safe to send cucmds etc
# Currently the Curator is very slow to boot. It's running from a slow
# Fosc clock whilst using 1bit accesses for the SQIFs its typically taking
# 2.25s to boot into the 'operational' state.
CURATOR_BOOT_TIMEOUT = 4.0  # If it takes longer than 4s something is wrong.


class CuratorBootError(RuntimeError):
    """
    Curator took too long to boot
    """


class QCC516x7x_QCC306x7xDevice(BaseDevice):
    """
    Functionality common to all QCC516x7x_QCC306x7x devices
    """

    def __init__(self, chip, transport, access_cache_type=NullAccessCache):

        # Configure significant PCB-level Components
        #
        self.components = NameSpace()
        comps = self.components  # shorthand

        # Solder down the oven-ready chip
        #
        comps.chip = chip

        # ...and the debug transport
        comps.transport = transport

    @property
    def chip(self):
        return self.components.chip

    @property
    def chips(self):
        return [self.chip]

    @property
    def transport(self):
        return self.components.transport

    @property
    def name(self):
        return "QCC516x7x_QCC306x7x"

    @property
    def trb_raw(self):
        try:
            self._trb_raw
        except AttributeError:
            try:
                self._trb_raw = TrbRaw(self.transport)
            except TypeError:
                # We're evidently not on TRB
                self._trb_raw = None
        return self._trb_raw

    @property
    def dap(self):
        return self.chip.dap

