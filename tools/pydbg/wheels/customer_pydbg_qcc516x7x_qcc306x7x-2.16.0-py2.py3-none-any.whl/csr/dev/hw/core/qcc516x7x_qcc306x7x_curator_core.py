############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2019 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################

from .meta.i_core_info import XapCoreInfo
from .meta.io_struct_io_map_info import IoStructIOMapInfo
from csr.dev.hw.core.curator_core import CuratorCore
from csr.dev.model import interface
from .mixin.supports_custom_digits import SupportsCustomDigits


class QCC516x7x_QCC306x7xCuratorCoreInfo (XapCoreInfo, SupportsCustomDigits):
    """\
    Curator QCC516x7x_QCC306x7x 1pt0 Core meta-data.
    """
    DIGITS_SS_NAME = "curator"

    def __init__(self, custom_digits=None, second_gen_digits=False):

        SupportsCustomDigits.__init__(self, custom_digits=custom_digits)
        self._second_gen_digits = second_gen_digits
    # ICoreInfo compliance

    @property
    def io_map_info(self):

        try:
            self._io_map_info
        except AttributeError:
            if self.custom_io_struct:
                io_struct = self.custom_io_struct
            else:
                if self._second_gen_digits:
                    from ..io import qcc517x_qcc307x_curator_io_struct as io_struct
                else:
                    from ..io import qcc516x_qcc306x_curator_io_struct as io_struct

            self._io_map_info = IoStructIOMapInfo(io_struct, None,
                                                  self.layout_info)
        return self._io_map_info


class QCC516x7x_QCC306x7xCuratorCore (CuratorCore):
    """\
    Curator QCC516x7x_QCC306x7x 1pt0 Core.
    """

    def __init__(self, subsystem, second_gen_digits=False):

        CuratorCore.__init__(self, subsystem)
        self._second_gen_digits = second_gen_digits

    def populate(self, access_cache_type):

        CuratorCore.populate(self, access_cache_type)
    # BaseCore compliance

    @property
    def _info(self):

        try:
            self._core_info
        except AttributeError:
            self._core_info = QCC516x7x_QCC306x7xCuratorCoreInfo(custom_digits=
                                                     self.emulator_build,
                                                 second_gen_digits=self._second_gen_digits)
        return self._core_info

    # CuratorCore compliance
    @property
    def _is_running_from_rom(self):
        """
        Is the core configured to fetch code from ROM or SQIF?
        """
        return True 
    # Private
