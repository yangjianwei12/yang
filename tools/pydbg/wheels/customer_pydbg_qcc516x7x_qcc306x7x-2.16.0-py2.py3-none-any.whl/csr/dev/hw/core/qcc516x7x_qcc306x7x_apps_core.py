############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2014 - 2017 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
from .apps_p0_core import AppsP0Core
from .apps_p1_core import AppsP1Core
from .base_core import HasCoreInfoWithCustomDigits
from csr.wheels.global_streams import iprint
from csr.dev.hw.address_space import AddressMap, AccessView, NullAccessCache
from csr.wheels.bitsandbobs import NameSpace
from csr.dev.hw.mmu import AppsVMWindow
from csr.dev.hw.subsystem.host_subsystem import AppsHifTransform

from .meta.i_core_info import ICoreInfo
from .meta.io_struct_io_map_info import IoStructIOMapInfo
from .meta.i_core_info import Kalimba32CoreInfo
from .mixin.supports_custom_digits import SupportsCustomDigits


class QCC516x7x_QCC306x7xAppsCoreInfo (Kalimba32CoreInfo, SupportsCustomDigits):
    """\
    QCC516x7x_QCC306x7x Apps 1.0 P0 Core meta-data.
    """
    DIGITS_SS_NAME = "apps_sys"
    # ICoreInfo compliance

    def __init__(self, custom_digits=None):
        SupportsCustomDigits.__init__(self, custom_digits=custom_digits)

    @property
    def io_map_info(self):

        try:
            self._io_map_info
        except AttributeError:
            if self.custom_io_struct:
                io_struct = self.custom_io_struct
            else:
                io_struct = self._get_standard_io_struct()
            self._io_map_info = IoStructIOMapInfo(io_struct, None,
                                                  self.layout_info)
        return self._io_map_info

class QCC516x_QCC306xAppsCoreInfo(QCC516x7x_QCC306x7xAppsCoreInfo):
    
    def _get_standard_io_struct(self):
        from ..io import qcc516x_qcc306x_apps_io_struct as io_struct
        return io_struct

class QCC516x_QCC306xAppsP0Core(AppsP0Core, HasCoreInfoWithCustomDigits):
    """
    QCC516x7x_QCC306x7x 1.0 specific P0 Definition
    """
    CoreInfoType = QCC516x_QCC306xAppsCoreInfo
    P1_DATA_RAM_START =    0x00020000
    _info = property(HasCoreInfoWithCustomDigits._info.fget)


class QCC516x_QCC306xAppsP1Core(AppsP1Core, HasCoreInfoWithCustomDigits):
    """
    """
    CoreInfoType = QCC516x_QCC306xAppsCoreInfo
    P1_DATA_RAM_START =    0x00020000
    _info = property(HasCoreInfoWithCustomDigits._info.fget)




class QCC517x_QCC307xAppsCoreInfo(QCC516x7x_QCC306x7xAppsCoreInfo):
    
    def _get_standard_io_struct(self):
        from ..io import qcc517x_qcc307x_apps_io_struct as io_struct
        return io_struct



class QCC517x_QCC307xAppsP0Core(AppsP0Core, HasCoreInfoWithCustomDigits):
    
    CoreInfoType = QCC517x_QCC307xAppsCoreInfo
    P1_DATA_RAM_START =    0x00040000
    _info = property(HasCoreInfoWithCustomDigits._info.fget)
    
class QCC517x_QCC307xAppsP1Core(AppsP1Core, HasCoreInfoWithCustomDigits):
    
    CoreInfoType = QCC517x_QCC307xAppsCoreInfo
    P1_DATA_RAM_START =    0x00040000
    _info = property(HasCoreInfoWithCustomDigits._info.fget)
