############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2019 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################

from csr.dev.hw.chip.hydra_vm_chip import HydraVMChip
from csr.dev.hw.chip.mixins.has_reset_transaction import HasResetTransaction
from csr.dev.hw.chip.mixins.has_jtag_swd_debug_trans import HasJtagSwdDebugTrans
from csr.dev.hw.debug_bus_mux import ARMDAP
from csr.dev.hw.address_space import AddressSpace


class QCC516x7x_QCC306x7xChip (HydraVMChip, HasResetTransaction,
                    HasJtagSwdDebugTrans):

    def __init__(self, access_cache_type, bus_address_offset=0,
                 second_gen_digits=False):
        """\
        Params:-
        - access_cache_type    Memory Access Cache type/policy.
        """
        self._second_gen_digits = second_gen_digits
        HydraVMChip.__init__(self, access_cache_type, bus_address_offset=bus_address_offset)

    @property
    def num_subsystems(self):
        return 5 if self._second_gen_digits else 6

    @property
    def name(self):

        return "QCC516x7x_QCC306x7x"

    def setup_sqif_htol(self):
        '''
        Puts the SQIF chip in quad mode. Normally the curator ROM code should
        do this but the register pokes are different for the HTOL board SQIF.
        This is meant to be called manually before patching and loading the
        Apps code.
        '''
        apps = self.apps_subsystem.p0
        cur = self.curator_subsystem.core

        cur.pause()

        cur.fields["CHIP_PIO9_PIO11_MUX_CONTROL"] = 0xbbb
        cur.fields["CHIP_PIO12_PIO15_MUX_CONTROL"] = 0xbbb

        # Reset the SQIF chip
        apps.fields["SQIF_POKE_LAST"] = 0xf0

        # Wait for it to reconfigure
        time.sleep(0.100)

        # Enable quad mode see datasheet for S25FL128S

        # Set write enable
        apps.fields["SQIF_POKE_LAST"] = 0x6

        # Write the config register using the WRR 01h command
        apps.fields["SQIF_POKE"] = 0x1  # Command
        apps.fields["SQIF_POKE"] = 0x0  # Status register
        apps.fields["SQIF_POKE_LAST"] = 0x2  # Config register

        cur.run()

    @property
    def dap(self):
        try:
            self._dap
        except AttributeError:
            # There's a JTAG/SWD interface to the Zeagle core, but nothing else
            self._dap = ARMDAP([self.bt_subsystem.core],
                               {"bt" : ARMDAP.APIndex(0, "AHB")})
        return self._dap.port

    @property
    def gdbserver_mux(self):
        try:
            self._gdbserver_mux
        except AttributeError:
            self._gdbserver_mux = GdbserverMux([self.bt_subsystem.core])
        return self._gdbserver_mux.port

    GDBSERVER_PARAMS = {"jlink" :
                          {"bt" :  {"port" : 2331, "device" : "Cortex-M0"}}
                     }

    @property
    def raw_version(self):
        try:
            return HydraVMChip.raw_version.fget(self)
        except AddressSpace.NoAccess:
            # Curator isn't connected to the transport.  Just return default
            return 0xffff

    def bt_running_from_rom(self, bt):
        """
        Determine whether Bluetooth subsystem is running from ROM
        :param bt: bt core object
        :return: Bool - True: ROM, False: SQIF
        """
        return bt.fields.CLKGEN_REMAP_BOOT_FROM_RAM.BOOT_OPTION_ADDR_1800_0000 == 0

    def get_sqif_if_clk_rate(self, cur, ss):
        """
        Get the rate, in MHz, of QSPI clock source for 'ss'
        :param cur: curator core object
        :param ss: Name of subsystem of the interface to get the clock rate for
            Acceptable values:
                "Curator", "Apps", "BT", "Audio"
        :return: Integer - SQIF interface clock rate for 'ss'
        """

        if ss == "Audio" or ss == "Curator":
            sqif_if_clk_src_reg = cur.fields.CURATOR_SQIF_INTERFACE_CLK_SOURCES.SQIF_INTERFACE0_CLK_SOURCE
        elif ss == "BT" or ss == "Apps":
            sqif_if_clk_src_reg = cur.fields.CURATOR_SQIF_INTERFACE_CLK_SOURCES.SQIF_INTERFACE1_CLK_SOURCE
        else:
            raise ValueError("Unknown subsystem '%s'" % ss)

        if sqif_if_clk_src_reg.read() == 0:
            return 32
        elif sqif_if_clk_src_reg.read() == 1:
            return 80
        

    def _create_curator_subsystem(self):

        from csr.dev.hw.subsystem.qcc516x7x_qcc306x7x_curator_subsystem \
                                           import QCC516x7x_QCC306x7xCuratorSubsystem
        return QCC516x7x_QCC306x7xCuratorSubsystem(self, self.SSID.CURATOR,
                                    self._access_cache_type,
                                    second_gen_digits=self._second_gen_digits)

    def _create_host_subsystem(self):

        from csr.dev.hw.subsystem.qcc516x7x_qcc306x7x_host_subsystem \
                                                  import QCC516x7x_QCC306x7xHostSubsystem
        return QCC516x7x_QCC306x7xHostSubsystem(self, self.SSID.HOST,
                                      self._access_cache_type)

    def _create_apps_subsystem(self):
        if self._second_gen_digits:
            from csr.dev.hw.subsystem.qcc516x7x_qcc306x7x_apps_subsystem \
                         import QCC517x_QCC307xAppsSubsystem as AppsSubsystem
        else:
            from csr.dev.hw.subsystem.qcc516x7x_qcc306x7x_apps_subsystem \
                         import QCC516x_QCC306xAppsSubsystem as AppsSubsystem
                                                  
        return AppsSubsystem(self, self.SSID.APPS, self._access_cache_type)

    def _create_bt_subsystem(self):
        
        from csr.dev.hw.subsystem.bt_subsystem import SimpleBTSubsystem
        return SimpleBTSubsystem(self, self.SSID.BT, self._access_cache_type)

    def _create_audio_subsystem(self):
        from csr.dev.hw.subsystem.qcc516x7x_qcc306x7x_audio_subsystem \
                                                  import QCC516x7x_QCC306x7xAudioSubsystem
        return QCC516x7x_QCC306x7xAudioSubsystem(self, self.SSID.AUDIO,
                                      self._access_cache_type, "d00")



