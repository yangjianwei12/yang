CHIP_VERSION_MAJOR = (0x50,)

def factory(chip_version, access_cache_type):
    
    from ..qcc516x7x_qcc306x7x_chip import QCC516x7x_QCC306x7xChip
    return QCC516x7x_QCC306x7xChip(access_cache_type, second_gen_digits=chip_version.minor>1)
