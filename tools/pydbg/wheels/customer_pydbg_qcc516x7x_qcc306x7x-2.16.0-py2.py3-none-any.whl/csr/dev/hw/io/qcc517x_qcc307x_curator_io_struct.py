# -*- coding: utf-8 -*-
#------------------------------------------------------------------------------
# Automatically-generated memory-mapped registers IO file
#------------------------------------------------------------------------------

class c_enum(object):
   def __init__(self, parent, value, text, reg):
      self.parent = parent
      self.value  = value
      self.text   = text
      self.reg    = reg

class c_value(object):
   def __init__(self, parent, name, value, text):
      self.parent = parent
      self.name   = name
      self.value  = value
      self.text   = text

class c_bits(object):
   def __init__(self, parent, lsb, msb, mask, width, rw_flags, text):
      self.parent   = parent
      self.lsb      = lsb
      self.msb      = msb
      self.mask     = mask
      self.rw_flags = rw_flags
      self.width    = width
      self.text     = text

class c_reg(object):
   def __init__(self, addr, r, w, m, rw_flags, width, reset, local, ext_read, mod_name, group, text, locked_by, unlock_value, typedefd_io, safe_to_load, is_bank_ctrl, bank_ctrl_reg, constant):
      self.addr          = addr
      self.r             = r            # Readable
      self.w             = w            # Writeable
      self.m             = m            # Mixed register type
      self.rw_flags      = rw_flags     # RW flags
      self.width         = width
      self.local         = local
      self.ext_read      = ext_read
      self.mod_name      = mod_name
      self.text          = text
      self.group         = group
      self.reset         = reset
      self.locked_by     = locked_by
      self.unlock_value  = unlock_value
      self.safe_to_load  = safe_to_load
      self.typedefd_io   = typedefd_io
      self.is_bank_ctrl  = is_bank_ctrl
      self.bank_ctrl_reg = bank_ctrl_reg
      self.constant      = constant

class c_regarray(object):
   def __init__(self, addr, num_elements, element):
      self.addr = addr
      self.num_elements  = num_elements
      self.element = element


CURATOR_SUBSYSTEMS_CLK_SOURCES                                                   = c_reg(0xf00a, 1, 1, 0, "RW", 4, 0, 1, 0, "curator_sys", "ChipClkgenConfig", "Source selects for subsystem clocks", "", "", 1, 1, "", "", 0)
CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_APPS_CLK_SOURCE                           = c_bits(CURATOR_SUBSYSTEMS_CLK_SOURCES, 0, 0, 0x1, 1, "RW", "Select the clock source for Apps including Kalimbas and SDIO. 0=Scaled, 1=PLL")
CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_LED_CTRL_CLK_SOURCE                       = c_bits(CURATOR_SUBSYSTEMS_CLK_SOURCES, 1, 2, 0x6, 2, "RW", "Select the clock source for the LED Ctrl. 0=SOSC, 1=FOSC, 2=XTAL, 3=OFF.")
CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_AUDIO_DDS_CLK_SOURCE                      = c_bits(CURATOR_SUBSYSTEMS_CLK_SOURCES, 3, 3, 0x8, 1, "RW", "Select the clock source for PCM and SPDIF DDS. 0=XTAL, 1=PLL")
CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_APPS_CLK_SOURCE_SCALED                    = c_enum(CURATOR_SUBSYSTEMS_CLK_SOURCES, 0, "Select the clock source for Apps to be the Scaled clock", "CURATOR_SUBSYSTEMS_CLK_SOURCES")
CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_APPS_CLK_SOURCE_ADPLL                     = c_enum(CURATOR_SUBSYSTEMS_CLK_SOURCES, 1, "Select the clock source for Apps to be the ADPLL", "CURATOR_SUBSYSTEMS_CLK_SOURCES")
CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_LED_CTRL_CLK_SOURCE_SOSC                  = c_enum(CURATOR_SUBSYSTEMS_CLK_SOURCES, 0, "Select the clock source for LED Ctrl to be the SOSC", "CURATOR_SUBSYSTEMS_CLK_SOURCES")
CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_LED_CTRL_CLK_SOURCE_FOSC                  = c_enum(CURATOR_SUBSYSTEMS_CLK_SOURCES, 1, "Select the clock source for LED Ctrl to be the FOSC", "CURATOR_SUBSYSTEMS_CLK_SOURCES")
CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_LED_CTRL_CLK_SOURCE_XTAL                  = c_enum(CURATOR_SUBSYSTEMS_CLK_SOURCES, 2, "Select the clock source for LED Ctrl to be the XTAL", "CURATOR_SUBSYSTEMS_CLK_SOURCES")
CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_LED_CTRL_CLK_SOURCE_RESERVED              = c_enum(CURATOR_SUBSYSTEMS_CLK_SOURCES, 3, "RESERVED: LED Ctrl clock will be switched off", "CURATOR_SUBSYSTEMS_CLK_SOURCES")
CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_AUDIO_DDS_CLK_SOURCE_XTAL                 = c_enum(CURATOR_SUBSYSTEMS_CLK_SOURCES, 0, "Select the clock source for PCM and SPDIF DDS to be the XTAL", "CURATOR_SUBSYSTEMS_CLK_SOURCES")
CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_AUDIO_DDS_CLK_SOURCE_ADPLL                = c_enum(CURATOR_SUBSYSTEMS_CLK_SOURCES, 1, "Select the clock source for PCM and SPDIF DDS to be the ADPLL", "CURATOR_SUBSYSTEMS_CLK_SOURCES")
CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES                                              = c_reg(0xf00b, 1, 1, 0, "RW", 8, 2, 0, 0, "curator_sys", "ChipClkgenConfig", "Enables for each subsystem core clock", "", "", 1, 1, "", "", 0)
CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES.CURATOR_SUBSYS_CORE_CLK_ENABLES_RESERVED1    = c_bits(CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES, 0, 0, 0x1, 1, "RW", "No effects")
CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES.CURATOR_SUBSYS_CORE_CLK_ENABLES_HOST         = c_bits(CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES, 1, 1, 0x2, 1, "RW", "")
CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES.CURATOR_SUBSYS_CORE_CLK_ENABLES_BT           = c_bits(CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES, 2, 2, 0x4, 1, "RW", "")
CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES.CURATOR_SUBSYS_CORE_CLK_ENABLES_AUDIO        = c_bits(CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES, 3, 3, 0x8, 1, "RW", "XTAL for Audio-SS CPU ONLY")
CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES.CURATOR_SUBSYS_CORE_CLK_ENABLES_APPS         = c_bits(CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES, 4, 4, 0x10, 1, "RW", "")
CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES.CURATOR_SUBSYS_CORE_CLK_ENABLES_RESERVED2    = c_bits(CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES, 5, 5, 0x20, 1, "RW", "No effects")
CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES.CURATOR_SUBSYS_CORE_CLK_ENABLES_RESERVED3    = c_bits(CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES, 6, 6, 0x40, 1, "RW", "No effects")
CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES.CURATOR_SUBSYS_CORE_CLK_ENABLES_AUDIO_DIV    = c_bits(CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES, 7, 7, 0x80, 1, "RW", "AUDIO_CPU_XTAL_DIG_DIV Alternative Clock for Audio CPU, divided between 16 and 1MHz in Aux Macro. Also known as 'AoV' clock")
CURATOR_SUBSYSTEMS_DEBUG_SELECT_CTRL                                             = c_reg(0xf07c, 1, 1, 0, "RW", 3, 0, 0, 0, "curator_sys", "", "Ctrl=1, PRDYN RAM status signals is routed on the DEBUG_OUT bus, Reset = 0. Only 1-bit needs to be assigned to debug individual subsystems. This register should only be used during debug. ", "", "", 1, 1, "", "", 0)
CURATOR_SUBSYSTEMS_DEBUG_SELECT_CTRL.AUDIO_SYS_DEBUG_SELECT_CTRL                 = c_bits(CURATOR_SUBSYSTEMS_DEBUG_SELECT_CTRL, 0, 0, 0x1, 1, "RW", "")
CURATOR_SUBSYSTEMS_DEBUG_SELECT_CTRL.APPS_SYS_DEBUG_SELECT_CTRL                  = c_bits(CURATOR_SUBSYSTEMS_DEBUG_SELECT_CTRL, 1, 1, 0x2, 1, "RW", "")
CURATOR_SUBSYSTEMS_DEBUG_SELECT_CTRL.BT_SYS_DEBUG_SELECT_CTRL                    = c_bits(CURATOR_SUBSYSTEMS_DEBUG_SELECT_CTRL, 2, 2, 0x4, 1, "RW", "")
CURATOR_SUBSYSTEMS_EARLY_ISO_REM                                                 = c_reg(0xf07b, 1, 1, 0, "RW", 3, 0, 0, 0, "curator_sys", "", "Enable=1, Isolation is removed from a SS as soon as CORE_READY_OUT is ready, Reset = 0. This register should only be used during debug. ", "", "", 1, 1, "", "", 0)
CURATOR_SUBSYSTEMS_EARLY_ISO_REM.AUDIO_SYS_CURATOR_EARLY_ISO_REM                 = c_bits(CURATOR_SUBSYSTEMS_EARLY_ISO_REM, 0, 0, 0x1, 1, "RW", "AUDIO_SYS isolation early removal control")
CURATOR_SUBSYSTEMS_EARLY_ISO_REM.APPS_SYS_CURATOR_EARLY_ISO_REM                  = c_bits(CURATOR_SUBSYSTEMS_EARLY_ISO_REM, 1, 1, 0x2, 1, "RW", "APPS_SYS isolation early removal control")
CURATOR_SUBSYSTEMS_EARLY_ISO_REM.BT_SYS_CURATOR_EARLY_ISO_REM                    = c_bits(CURATOR_SUBSYSTEMS_EARLY_ISO_REM, 2, 2, 0x4, 1, "RW", "BT_SYS isolation early removal control")
CURATOR_SUBSYSTEMS_RUN_EN                                                        = c_reg(0xf021, 1, 1, 0, "RW", 5, 0, 1, 0, "curator_sys", "", "Sets whether the CPU's within each sub-system are allowed to run.", "", "", 1, 1, "", "", 0)
CURATOR_SUBSYSTEMS_RUN_EN.CURATOR_SYS__SYSTEM_BUS_HOST_SYS                       = c_bits(CURATOR_SUBSYSTEMS_RUN_EN, 1, 1, 0x2, 1, "RW", "TBus sub-system ID for host_sys")
CURATOR_SUBSYSTEMS_RUN_EN.CURATOR_SYS__SYSTEM_BUS_BT_SYS                         = c_bits(CURATOR_SUBSYSTEMS_RUN_EN, 2, 2, 0x4, 1, "RW", "TBus sub-system ID for bt_sys")
CURATOR_SUBSYSTEMS_RUN_EN.CURATOR_SYS__SYSTEM_BUS_APPS_SYS                       = c_bits(CURATOR_SUBSYSTEMS_RUN_EN, 4, 4, 0x10, 1, "RW", "TBus sub-system ID for apps_sys")
CURATOR_SUBSYSTEMS_RUN_EN.CURATOR_SYS__SYSTEM_BUS_CURATOR                        = c_bits(CURATOR_SUBSYSTEMS_RUN_EN, 0, 0, 0x1, 1, "RW", "TBus sub-system ID for curator")
CURATOR_SUBSYSTEMS_RUN_EN.CURATOR_SYS__SYSTEM_BUS_AUDIO_SYS                      = c_bits(CURATOR_SUBSYSTEMS_RUN_EN, 3, 3, 0x8, 1, "RW", "TBus sub-system ID for audio_sys")
CURATOR_SUBSYSTEMS_RUN_EN.CURATOR_SYS__SYSTEM_BUS_NUM_SUBSYSTEMS                 = c_enum(CURATOR_SUBSYSTEMS_RUN_EN, 5, "The total number of subsystems", "CURATOR_SUBSYSTEMS_RUN_EN")
CURATOR_SUBSYSTEMS_RUN_EN.CURATOR_SYS__SYSTEM_BUS_RANGE_LSB                      = c_enum(CURATOR_SUBSYSTEMS_RUN_EN, 0, "Range indicating lsb for bitfield registers.", "CURATOR_SUBSYSTEMS_RUN_EN")
CURATOR_SUBSYSTEMS_RUN_EN.CURATOR_SYS__SYSTEM_BUS_RANGE_MSB                      = c_enum(CURATOR_SUBSYSTEMS_RUN_EN, 4, "Range indicating msb for bitfield registers.", "CURATOR_SUBSYSTEMS_RUN_EN")
CURATOR_SUBSYSTEMS_UP                                                            = c_reg(0xf019, 1, 0, 0, "R", 5, 0, 0, 0, "curator_sys", "", "Register indicating which internal subsystems are up and read to respond to transactions.", "", "", 1, 1, "", "", 0)
CURATOR_SUBSYSTEMS_UP.CURATOR_SYS__SYSTEM_BUS_HOST_SYS                           = c_bits(CURATOR_SUBSYSTEMS_UP, 1, 1, 0x2, 1, "R", "TBus sub-system ID for host_sys")
CURATOR_SUBSYSTEMS_UP.CURATOR_SYS__SYSTEM_BUS_BT_SYS                             = c_bits(CURATOR_SUBSYSTEMS_UP, 2, 2, 0x4, 1, "R", "TBus sub-system ID for bt_sys")
CURATOR_SUBSYSTEMS_UP.CURATOR_SYS__SYSTEM_BUS_APPS_SYS                           = c_bits(CURATOR_SUBSYSTEMS_UP, 4, 4, 0x10, 1, "R", "TBus sub-system ID for apps_sys")
CURATOR_SUBSYSTEMS_UP.CURATOR_SYS__SYSTEM_BUS_CURATOR                            = c_bits(CURATOR_SUBSYSTEMS_UP, 0, 0, 0x1, 1, "R", "TBus sub-system ID for curator")
CURATOR_SUBSYSTEMS_UP.CURATOR_SYS__SYSTEM_BUS_AUDIO_SYS                          = c_bits(CURATOR_SUBSYSTEMS_UP, 3, 3, 0x8, 1, "R", "TBus sub-system ID for audio_sys")
CURATOR_SUBSYSTEMS_UP.CURATOR_SYS__SYSTEM_BUS_NUM_SUBSYSTEMS                     = c_enum(CURATOR_SUBSYSTEMS_UP, 5, "The total number of subsystems", "CURATOR_SUBSYSTEMS_UP")
CURATOR_SUBSYSTEMS_UP.CURATOR_SYS__SYSTEM_BUS_RANGE_LSB                          = c_enum(CURATOR_SUBSYSTEMS_UP, 0, "Range indicating lsb for bitfield registers.", "CURATOR_SUBSYSTEMS_UP")
CURATOR_SUBSYSTEMS_UP.CURATOR_SYS__SYSTEM_BUS_RANGE_MSB                          = c_enum(CURATOR_SUBSYSTEMS_UP, 4, "Range indicating msb for bitfield registers.", "CURATOR_SUBSYSTEMS_UP")

# -- General Curator registers and enumerations (reset by POR) --

CURATOR_SUBSYSTEMS_POWERED                                                       = c_reg(0xf01f, 1, 1, 0, "RW", 5, 3, 0, 0, "curator_sys_por", "", "Register setting which internal subsystems are enabled. It's only reset by power on resets (i.e. watchdog, SPI, host and sys_ctrl resets do not affect this register). That's so that you can core dump all subsystems after such resets.", "", "", 1, 1, "", "", 0)
CURATOR_SUBSYSTEMS_POWERED.CURATOR_SYS_POR__SYSTEM_BUS_HOST_SYS                  = c_bits(CURATOR_SUBSYSTEMS_POWERED, 1, 1, 0x2, 1, "RW", "TBus sub-system ID for host_sys")
CURATOR_SUBSYSTEMS_POWERED.CURATOR_SYS_POR__SYSTEM_BUS_BT_SYS                    = c_bits(CURATOR_SUBSYSTEMS_POWERED, 2, 2, 0x4, 1, "RW", "TBus sub-system ID for bt_sys")
CURATOR_SUBSYSTEMS_POWERED.CURATOR_SYS_POR__SYSTEM_BUS_APPS_SYS                  = c_bits(CURATOR_SUBSYSTEMS_POWERED, 4, 4, 0x10, 1, "RW", "TBus sub-system ID for apps_sys")
CURATOR_SUBSYSTEMS_POWERED.CURATOR_SYS_POR__SYSTEM_BUS_CURATOR                   = c_bits(CURATOR_SUBSYSTEMS_POWERED, 0, 0, 0x1, 1, "RW", "TBus sub-system ID for curator")
CURATOR_SUBSYSTEMS_POWERED.CURATOR_SYS_POR__SYSTEM_BUS_AUDIO_SYS                 = c_bits(CURATOR_SUBSYSTEMS_POWERED, 3, 3, 0x8, 1, "RW", "TBus sub-system ID for audio_sys")
CURATOR_SUBSYSTEMS_POWERED.CURATOR_SYS_POR__SYSTEM_BUS_NUM_SUBSYSTEMS            = c_enum(CURATOR_SUBSYSTEMS_POWERED, 5, "The total number of subsystems", "CURATOR_SUBSYSTEMS_POWERED")
CURATOR_SUBSYSTEMS_POWERED.CURATOR_SYS_POR__SYSTEM_BUS_RANGE_LSB                 = c_enum(CURATOR_SUBSYSTEMS_POWERED, 0, "Range indicating lsb for bitfield registers.", "CURATOR_SUBSYSTEMS_POWERED")
CURATOR_SUBSYSTEMS_POWERED.CURATOR_SYS_POR__SYSTEM_BUS_RANGE_MSB                 = c_enum(CURATOR_SUBSYSTEMS_POWERED, 4, "Range indicating msb for bitfield registers.", "CURATOR_SUBSYSTEMS_POWERED")
CURATOR_SYS_POR__SYSTEM_BUS_HOST_SYS                                             = c_enum(None, 1, "TBus sub-system ID for host_sys", "CURATOR_SYS_POR__SYSTEM_BUS")
CURATOR_SYS_POR__SYSTEM_BUS_BT_SYS                                               = c_enum(None, 2, "TBus sub-system ID for bt_sys", "CURATOR_SYS_POR__SYSTEM_BUS")
CURATOR_SYS_POR__SYSTEM_BUS_APPS_SYS                                             = c_enum(None, 4, "TBus sub-system ID for apps_sys", "CURATOR_SYS_POR__SYSTEM_BUS")
CURATOR_SYS_POR__SYSTEM_BUS_CURATOR                                              = c_enum(None, 0, "TBus sub-system ID for curator", "CURATOR_SYS_POR__SYSTEM_BUS")
CURATOR_SYS_POR__SYSTEM_BUS_AUDIO_SYS                                            = c_enum(None, 3, "TBus sub-system ID for audio_sys", "CURATOR_SYS_POR__SYSTEM_BUS")
CURATOR_SYS_POR__SYSTEM_BUS_NUM_SUBSYSTEMS                                       = c_enum(None, 5, "The total number of subsystems", "CURATOR_SYS_POR__SYSTEM_BUS")
CURATOR_SYS_POR__SYSTEM_BUS_RANGE_LSB                                            = c_enum(None, 0, "Range indicating lsb for bitfield registers.", "CURATOR_SYS_POR__SYSTEM_BUS")
CURATOR_SYS_POR__SYSTEM_BUS_RANGE_MSB                                            = c_enum(None, 4, "Range indicating msb for bitfield registers.", "CURATOR_SYS_POR__SYSTEM_BUS")

# -- Debug control registers --

DBG_BRK_CLEAR                                                                    = c_reg(0xf834, 1, 1, 0, "RW", 3, 0, 1, 0, "debug", "", "Writing a 1 to a bit in this register clears the break signal to the corresponding processor (ie bit 0 affects P0, bit 1 P1 etc). Usually the break condition is only cleared when the xap stops, however it won't stop if the break is treaded as a virtual break by the xap. In this case the break needs to be cleared manually by using this register", "", "", 0, 0, "", "", 0)
DBG_BRK_CLEAR.DBG_BRK_CLEAR                                                      = c_bits(DBG_BRK_CLEAR, 0, 2, 0x7, 3, "RW", "")
DBG_EMU_CMD                                                                      = c_reg(0xf81d, 1, 1, 0, "RW", 8, 0, 1, 0, "debug", "", "Register that controls debug modes of XAP (Async reset from RST_HARD, so settings are preserved across watchdog, host, and debug resets)", "", "", 0, 0, "", "", 0)
DBG_EMU_CMD.DBG_EMU_CMD_XAP_STEP                                                 = c_bits(DBG_EMU_CMD, 0, 0, 0x1, 1, "RW", "Set to allow XAP to single step. RUN_B must also be high to cause single step to occur")
DBG_EMU_CMD.DBG_EMU_CMD_XAP_RUN_B                                                = c_bits(DBG_EMU_CMD, 1, 1, 0x2, 1, "RW", "Clear to allow XAP to run")
DBG_EMU_CMD.DBG_EMU_CMD_XAP_BRK                                                  = c_bits(DBG_EMU_CMD, 2, 2, 0x4, 1, "RW", "Set to cause the XAP to stop at the end of the next instruction")
DBG_EMU_CMD.DBG_EMU_CMD_XAP_WAKEUP                                               = c_bits(DBG_EMU_CMD, 3, 3, 0x8, 1, "RW", "Set to wake XAP from a sleep instruction")
DBG_EMU_CMD.DBG_EMU_CMD_BREAK_ALL                                                = c_bits(DBG_EMU_CMD, 4, 4, 0x10, 1, "RW", "If this bit is set, any breakpoints that are hit will cause all processors to stop, not just the processor that hit the breakpoint. NOTE: This is a global setting and not per processor.")
DBG_EMU_CMD.DBG_EMU_CMD_UNUSED_5                                                 = c_bits(DBG_EMU_CMD, 5, 5, 0x20, 1, "RW", "Unused")
DBG_EMU_CMD.DBG_EMU_CMD_UNUSED_6                                                 = c_bits(DBG_EMU_CMD, 6, 6, 0x40, 1, "RW", "Unused")
DBG_EMU_CMD.DBG_EMU_CMD_UNUSED_7                                                 = c_bits(DBG_EMU_CMD, 7, 7, 0x80, 1, "RW", "Unused")

HOST_SYS_REG_ACCESS_SUBSYS_IN_ADDR_EN                                            = c_reg(0xf717, 1, 1, 0, "RW", 16, 1, 0, 0, "host_sys_config", "", "Bitmask. 1: Enable subsystem of SSID=bit n  to use address bit [19:16] to pretend to be another SSID with bits 31:20 set to 12'b0000_0000_1010", "", "", 0, 1, "", "", 0)
HOST_SYS_REG_ACCESS_SUBSYS_IN_ADDR_EN.HOST_SYS_REG_ACCESS_SUBSYS_IN_ADDR_EN      = c_bits(HOST_SYS_REG_ACCESS_SUBSYS_IN_ADDR_EN, 0, 15, 0xffff, 16, "RW", "")
MMU_HOST_SUBSYSTEM_BLOCK_SELECT                                                  = c_reg(0xf8d9, 1, 1, 0, "RW", 4, 0, 0, 0, "mmu", "", "Select which host subsystem block to talk to when accessing registers.", "", "", 0, 1, "", "", 0)
MMU_HOST_SUBSYSTEM_BLOCK_SELECT.MMU_HOST_SUBSYSTEM_BLOCK_SELECT                  = c_bits(MMU_HOST_SUBSYSTEM_BLOCK_SELECT, 0, 3, 0xf, 4, "RW", "")

MMU_PROC_GW1_CONFIG                                                              = c_reg(0x65, 1, 1, 0, "RW", 32, 0, 0, 0, "mmu", "", "Processor 0 generic window 1 configuration register.", "", "", 0, 1, "", "", 0)
MMU_PROC_GW1_CONFIG.MMU_GW_CONFIG_BANK_SELECT_LOW                                = c_bits(MMU_PROC_GW1_CONFIG, 0, 15, 0xffff, 16, "RW", "Bank select for remote subsystem accesses (Low word)")
MMU_PROC_GW1_CONFIG.MMU_GW_CONFIG_BANK_SELECT_HIGH                               = c_bits(MMU_PROC_GW1_CONFIG, 16, 20, 0x1f0000, 5, "RW", "Bank select for remote subsystem accesses (High word)")
MMU_PROC_GW1_CONFIG.MMU_GW_CONFIG_BLOCK_ID                                       = c_bits(MMU_PROC_GW1_CONFIG, 21, 24, 0x1e00000, 4, "RW", "Block ID for remote subsystem accesses")
MMU_PROC_GW1_CONFIG.MMU_GW_CONFIG_SUBSYSTEM_ID                                   = c_bits(MMU_PROC_GW1_CONFIG, 25, 28, 0x1e000000, 4, "RW", "Subsystem ID for remote subsystem accesses")
MMU_PROC_GW1_CONFIG.MMU_GW_CONFIG_MAPPING                                        = c_bits(MMU_PROC_GW1_CONFIG, 29, 31, 0xe0000000, 3, "RW", "Mapping for which memory region to access")
MMU_PROC_GW1_CONFIG.MMU_GW_CONFIG_BANK_SELECT_SHIFT                              = c_enum(MMU_PROC_GW1_CONFIG, 11, "The amount bank select is shifted left before adding it to the XAP's generic window address.", "MMU_PROC_GW1_CONFIG")
MMU_PROC_GW2_CONFIG                                                              = c_reg(0x67, 1, 1, 0, "RW", 32, 0, 0, 0, "mmu", "", "Processor 0 generic window 2 configuration register.", "", "", 0, 1, "", "", 0)
MMU_PROC_GW2_CONFIG.MMU_GW_CONFIG_BANK_SELECT_LOW                                = c_bits(MMU_PROC_GW2_CONFIG, 0, 15, 0xffff, 16, "RW", "Bank select for remote subsystem accesses (Low word)")
MMU_PROC_GW2_CONFIG.MMU_GW_CONFIG_BANK_SELECT_HIGH                               = c_bits(MMU_PROC_GW2_CONFIG, 16, 20, 0x1f0000, 5, "RW", "Bank select for remote subsystem accesses (High word)")
MMU_PROC_GW2_CONFIG.MMU_GW_CONFIG_BLOCK_ID                                       = c_bits(MMU_PROC_GW2_CONFIG, 21, 24, 0x1e00000, 4, "RW", "Block ID for remote subsystem accesses")
MMU_PROC_GW2_CONFIG.MMU_GW_CONFIG_SUBSYSTEM_ID                                   = c_bits(MMU_PROC_GW2_CONFIG, 25, 28, 0x1e000000, 4, "RW", "Subsystem ID for remote subsystem accesses")
MMU_PROC_GW2_CONFIG.MMU_GW_CONFIG_MAPPING                                        = c_bits(MMU_PROC_GW2_CONFIG, 29, 31, 0xe0000000, 3, "RW", "Mapping for which memory region to access")
MMU_PROC_GW2_CONFIG.MMU_GW_CONFIG_BANK_SELECT_SHIFT                              = c_enum(MMU_PROC_GW2_CONFIG, 11, "The amount bank select is shifted left before adding it to the XAP's generic window address.", "MMU_PROC_GW2_CONFIG")
MMU_PROC_GW3_CONFIG                                                              = c_reg(0x69, 1, 1, 0, "RW", 32, 0, 0, 0, "mmu", "", "Processor 0 generic window 3 configuration register.", "", "", 0, 1, "", "", 0)
MMU_PROC_GW3_CONFIG.MMU_GW_CONFIG_BANK_SELECT_LOW                                = c_bits(MMU_PROC_GW3_CONFIG, 0, 15, 0xffff, 16, "RW", "Bank select for remote subsystem accesses (Low word)")
MMU_PROC_GW3_CONFIG.MMU_GW_CONFIG_BANK_SELECT_HIGH                               = c_bits(MMU_PROC_GW3_CONFIG, 16, 20, 0x1f0000, 5, "RW", "Bank select for remote subsystem accesses (High word)")
MMU_PROC_GW3_CONFIG.MMU_GW_CONFIG_BLOCK_ID                                       = c_bits(MMU_PROC_GW3_CONFIG, 21, 24, 0x1e00000, 4, "RW", "Block ID for remote subsystem accesses")
MMU_PROC_GW3_CONFIG.MMU_GW_CONFIG_SUBSYSTEM_ID                                   = c_bits(MMU_PROC_GW3_CONFIG, 25, 28, 0x1e000000, 4, "RW", "Subsystem ID for remote subsystem accesses")
MMU_PROC_GW3_CONFIG.MMU_GW_CONFIG_MAPPING                                        = c_bits(MMU_PROC_GW3_CONFIG, 29, 31, 0xe0000000, 3, "RW", "Mapping for which memory region to access")
MMU_PROC_GW3_CONFIG.MMU_GW_CONFIG_BANK_SELECT_SHIFT                              = c_enum(MMU_PROC_GW3_CONFIG, 11, "The amount bank select is shifted left before adding it to the XAP's generic window address.", "MMU_PROC_GW3_CONFIG")
MMU_PROC_IO_LOG_ADDR                                                             = c_reg(0x64, 1, 1, 0, "RW", 16, 0, 0, 0, "mmu", "", "Address to use when processor 0 accesses the IO log window in one of the Generic Windows. This supports all memory map locations.", "", "", 0, 1, "", "", 0)
MMU_PROC_IO_LOG_ADDR.MMU_PROC_IO_LOG_ADDR                                        = c_bits(MMU_PROC_IO_LOG_ADDR, 0, 15, 0xffff, 16, "RW", "")
MMU_REG_ACCESS_TIMEOUT_VALUE                                                     = c_reg(0xf8b5, 1, 1, 0, "RW", 16, 2989, 0, 0, "mmu", "", "When register accesses time out, the value returned comes from this register, default value 2989 (0x0BAD)", "", "", 0, 1, "", "", 0)
MMU_REG_ACCESS_TIMEOUT_VALUE.MMU_REG_ACCESS_TIMEOUT_VALUE                        = c_bits(MMU_REG_ACCESS_TIMEOUT_VALUE, 0, 15, 0xffff, 16, "RW", "")
MMU_SPI_GW1_CONFIG                                                               = c_reg(0xf955, 1, 1, 0, "RW", 32, 0, 0, 0, "mmu", "", "SPI generic window 1 configuration register.", "", "", 0, 1, "", "", 0)
MMU_SPI_GW1_CONFIG.MMU_GW_CONFIG_BANK_SELECT_LOW                                 = c_bits(MMU_SPI_GW1_CONFIG, 0, 15, 0xffff, 16, "RW", "Bank select for remote subsystem accesses (Low word)")
MMU_SPI_GW1_CONFIG.MMU_GW_CONFIG_BANK_SELECT_HIGH                                = c_bits(MMU_SPI_GW1_CONFIG, 16, 20, 0x1f0000, 5, "RW", "Bank select for remote subsystem accesses (High word)")
MMU_SPI_GW1_CONFIG.MMU_GW_CONFIG_BLOCK_ID                                        = c_bits(MMU_SPI_GW1_CONFIG, 21, 24, 0x1e00000, 4, "RW", "Block ID for remote subsystem accesses")
MMU_SPI_GW1_CONFIG.MMU_GW_CONFIG_SUBSYSTEM_ID                                    = c_bits(MMU_SPI_GW1_CONFIG, 25, 28, 0x1e000000, 4, "RW", "Subsystem ID for remote subsystem accesses")
MMU_SPI_GW1_CONFIG.MMU_GW_CONFIG_MAPPING                                         = c_bits(MMU_SPI_GW1_CONFIG, 29, 31, 0xe0000000, 3, "RW", "Mapping for which memory region to access")
MMU_SPI_GW1_CONFIG.MMU_GW_CONFIG_BANK_SELECT_SHIFT                               = c_enum(MMU_SPI_GW1_CONFIG, 11, "The amount bank select is shifted left before adding it to the XAP's generic window address.", "MMU_SPI_GW1_CONFIG")
MMU_SPI_GW2_CONFIG                                                               = c_reg(0xf957, 1, 1, 0, "RW", 32, 0, 0, 0, "mmu", "", "SPI generic window 2 configuration register.", "", "", 0, 1, "", "", 0)
MMU_SPI_GW2_CONFIG.MMU_GW_CONFIG_BANK_SELECT_LOW                                 = c_bits(MMU_SPI_GW2_CONFIG, 0, 15, 0xffff, 16, "RW", "Bank select for remote subsystem accesses (Low word)")
MMU_SPI_GW2_CONFIG.MMU_GW_CONFIG_BANK_SELECT_HIGH                                = c_bits(MMU_SPI_GW2_CONFIG, 16, 20, 0x1f0000, 5, "RW", "Bank select for remote subsystem accesses (High word)")
MMU_SPI_GW2_CONFIG.MMU_GW_CONFIG_BLOCK_ID                                        = c_bits(MMU_SPI_GW2_CONFIG, 21, 24, 0x1e00000, 4, "RW", "Block ID for remote subsystem accesses")
MMU_SPI_GW2_CONFIG.MMU_GW_CONFIG_SUBSYSTEM_ID                                    = c_bits(MMU_SPI_GW2_CONFIG, 25, 28, 0x1e000000, 4, "RW", "Subsystem ID for remote subsystem accesses")
MMU_SPI_GW2_CONFIG.MMU_GW_CONFIG_MAPPING                                         = c_bits(MMU_SPI_GW2_CONFIG, 29, 31, 0xe0000000, 3, "RW", "Mapping for which memory region to access")
MMU_SPI_GW2_CONFIG.MMU_GW_CONFIG_BANK_SELECT_SHIFT                               = c_enum(MMU_SPI_GW2_CONFIG, 11, "The amount bank select is shifted left before adding it to the XAP's generic window address.", "MMU_SPI_GW2_CONFIG")
MMU_SPI_GW3_CONFIG                                                               = c_reg(0xf959, 1, 1, 0, "RW", 32, 0, 0, 0, "mmu", "", "SPI generic window 3 configuration register.", "", "", 0, 1, "", "", 0)
MMU_SPI_GW3_CONFIG.MMU_GW_CONFIG_BANK_SELECT_LOW                                 = c_bits(MMU_SPI_GW3_CONFIG, 0, 15, 0xffff, 16, "RW", "Bank select for remote subsystem accesses (Low word)")
MMU_SPI_GW3_CONFIG.MMU_GW_CONFIG_BANK_SELECT_HIGH                                = c_bits(MMU_SPI_GW3_CONFIG, 16, 20, 0x1f0000, 5, "RW", "Bank select for remote subsystem accesses (High word)")
MMU_SPI_GW3_CONFIG.MMU_GW_CONFIG_BLOCK_ID                                        = c_bits(MMU_SPI_GW3_CONFIG, 21, 24, 0x1e00000, 4, "RW", "Block ID for remote subsystem accesses")
MMU_SPI_GW3_CONFIG.MMU_GW_CONFIG_SUBSYSTEM_ID                                    = c_bits(MMU_SPI_GW3_CONFIG, 25, 28, 0x1e000000, 4, "RW", "Subsystem ID for remote subsystem accesses")
MMU_SPI_GW3_CONFIG.MMU_GW_CONFIG_MAPPING                                         = c_bits(MMU_SPI_GW3_CONFIG, 29, 31, 0xe0000000, 3, "RW", "Mapping for which memory region to access")
MMU_SPI_GW3_CONFIG.MMU_GW_CONFIG_BANK_SELECT_SHIFT                               = c_enum(MMU_SPI_GW3_CONFIG, 11, "The amount bank select is shifted left before adding it to the XAP's generic window address.", "MMU_SPI_GW3_CONFIG")
MMU_SPI_IO_LOG_ADDR                                                              = c_reg(0xf8ce, 1, 1, 0, "RW", 16, 0, 0, 0, "mmu", "", "Address to use when SPI accesses the IO log window in one of the generic windows. This supports all memory map locations.", "", "", 0, 1, "", "", 0)
MMU_SPI_IO_LOG_ADDR.MMU_SPI_IO_LOG_ADDR                                          = c_bits(MMU_SPI_IO_LOG_ADDR, 0, 15, 0xffff, 16, "RW", "")
MMU_GW_CONFIG_BANK_SELECT_SHIFT                                                  = c_enum(None, 11, "The amount bank select is shifted left before adding it to the XAP's generic window address.", "MMU_GW_CONFIG")
MMU_GW_CONFIG_BANK_SELECT_LOW                                                    = c_enum(None, 0, "Bank select for remote subsystem accesses (Low word)", "MMU_GW_CONFIG")
MMU_GW_CONFIG_BANK_SELECT_HIGH                                                   = c_enum(None, 16, "Bank select for remote subsystem accesses (High word)", "MMU_GW_CONFIG")
MMU_GW_CONFIG_BLOCK_ID                                                           = c_enum(None, 21, "Block ID for remote subsystem accesses", "MMU_GW_CONFIG")
MMU_GW_CONFIG_SUBSYSTEM_ID                                                       = c_enum(None, 25, "Subsystem ID for remote subsystem accesses", "MMU_GW_CONFIG")
MMU_GW_CONFIG_MAPPING                                                            = c_enum(None, 29, "Mapping for which memory region to access", "MMU_GW_CONFIG")
MMU_GW_CONFIG_IO_LOG                                                             = c_enum(None, 0, "Select generic window to access IO log window", "MMU_GW_CONFIG_MAPPING_ENUM")
MMU_GW_CONFIG_PROGRAM_MEMORY_EXT                                                 = c_enum(None, 1, "Select generic window to access this processor's non-volatile program memory, probably ROM but could be Flash.", "MMU_GW_CONFIG_MAPPING_ENUM")
MMU_GW_CONFIG_PROGRAM_MEMORY_INT_RAM                                             = c_enum(None, 2, "Select generic window to access this processor's internal program RAM", "MMU_GW_CONFIG_MAPPING_ENUM")
MMU_GW_CONFIG_REMOTE_SUBSYSTEM                                                   = c_enum(None, 3, "Select generic window to access a remote subsystem", "MMU_GW_CONFIG_MAPPING_ENUM")
MMU_GW_CONFIG_JANITOR                                                            = c_enum(None, 4, "Select generic window to access the Janitor's memory map", "MMU_GW_CONFIG_MAPPING_ENUM")
MMU_MIN_BUFFER_SIZE_MASK                                                         = c_enum(None, 63, "Minimum buffer size mask", "MMU_MIN_BUFFER_SIZE")
MMU_PORT_P0_WRITE                                                                = c_enum(None, 0, "Processor 0 write port", "MMU_PORT")
MMU_PORT_P0_READ                                                                 = c_enum(None, 1, "Processor 0 read port", "MMU_PORT")
MMU_PROC_READ_PORTS_DISABLE_READ_CACHE_P0                                        = c_enum(None, 0, "Disable the read cache for processor 0 MMU port", "MMU_PROC_READ_PORTS")
# -- Non-volatile memory interface registers --

NV_MEM_ADDR_MAP_CFG                                                              = c_reg(0xfb40, 1, 1, 0, "RW", 5, 0, 1, 0, "nv_mem", "", "", "", "", 0, 0, "", "", 0)
NV_MEM_ADDR_MAP_CFG.NV_MEM_ADDR_MAP_CFG_ORDER                                    = c_bits(NV_MEM_ADDR_MAP_CFG, 0, 3, 0xf, 4, "RW", "Writing to this register overrides the results of the LPC detection and memory map configuration and sets up the memory map according to NV_MEM_ADDR_MAP_CFG_ORDER_ENUM. Note, that this field is divided into 2 subfields: [3:2] for the high window and [1:0] for the low window")
NV_MEM_ADDR_MAP_CFG.NV_MEM_ADDR_MAP_CFG_LPC_DETECT_OVERRIDE                      = c_bits(NV_MEM_ADDR_MAP_CFG, 4, 4, 0x10, 1, "RW", "Writing 1 to this bit stops the auto memory map configuration process. Normally this shouldn't be used, but it could be useful if for the LPC detection fails to complete.")
NV_MEM_ADDR_MAP_CFG_STATUS                                                       = c_reg(0xfb41, 1, 0, 0, "R", 7, 0, 0, 0, "nv_mem", "", "The state of the memory map and LPC detection process", "", "", 0, 1, "", "", 0)
NV_MEM_ADDR_MAP_CFG_STATUS.NV_MEM_ADDR_MAP_CFG_STATUS_ORDER                      = c_bits(NV_MEM_ADDR_MAP_CFG_STATUS, 0, 3, 0xf, 4, "R", "The current address map configuration, see NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_STATUS.NV_MEM_ADDR_MAP_CFG_MEM_MAP_CFG_DONE                  = c_bits(NV_MEM_ADDR_MAP_CFG_STATUS, 4, 4, 0x10, 1, "R", "1 if the memory map configuration is complete")
NV_MEM_ADDR_MAP_CFG_STATUS.NV_MEM_ADDR_MAP_CFG_LPC_DETECT_VALID                  = c_bits(NV_MEM_ADDR_MAP_CFG_STATUS, 5, 5, 0x20, 1, "R", "1 if the LPC slave detection process has finished and the value of NV_MEM_ADDR_MAP_CFG_LPC_DETECT is now valid.")
NV_MEM_ADDR_MAP_CFG_STATUS.NV_MEM_ADDR_MAP_CFG_LPC_DETECT                        = c_bits(NV_MEM_ADDR_MAP_CFG_STATUS, 6, 6, 0x40, 1, "R", "1 if an LPC slave has been detected, otherwise 0")
NV_MEM_DEBUG_SEL                                                                 = c_reg(0xfb42, 1, 1, 0, "RW", 5, 0, 0, 0, "nv_mem", "", "Selects which debug bus is routed to the top level debug mux", "", "", 0, 1, "", "", 0)
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT                                             = c_bits(NV_MEM_DEBUG_SEL, 0, 4, 0x1f, 5, "RW", "Selects what information is output on NV MEM's 16bit debug bus output")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_LPC_1                          = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_LPC_1", 0, "LPC debug 1")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_LPC_2                          = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_LPC_2", 1, "LPC debug 2")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_LPC_3                          = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_LPC_3", 2, "LPC debug 3")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_LPC_4                          = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_LPC_4", 3, "LPC debug 4")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_LPC_5                          = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_LPC_5", 4, "LPC debug 5")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_NVMEM_1                        = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_NVMEM_1", 5, "NV MEM debug 1")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_NVMEM_2                        = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_NVMEM_2", 6, "NV MEM debug 2")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_NVMEM_3                        = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_NVMEM_3", 7, "NV MEM debug 3")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_DSPLPC_1                       = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_DSPLPC_1", 8, "DSP LPC debug 1")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_DSPLPC_2                       = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_DSPLPC_2", 9, "DSP LPC debug 2")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_DSPLPC_3                       = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_DSPLPC_3", 10, "DSP LPC debug 3")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_DSPLPC_4                       = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_DSPLPC_4", 11, "DSP LPC debug 4")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_DSPLPC_5                       = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_DSPLPC_5", 12, "DSP LPC debug 5")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_ROMDATA_15TO00                 = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_ROMDATA_15TO00", 13, "ROM data bits 15:00")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_ROMDATA_31TO16                 = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_ROMDATA_31TO16", 14, "ROM data bits 31:16")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_ROMDATA_47TO32                 = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_ROMDATA_47TO32", 15, "ROM data bits 47:32")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_ROMDATA_63TO48                 = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_ROMDATA_63TO48", 16, "ROM data bits 63:48")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_ROMADDR_15TO00                 = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_ROMADDR_15TO00", 17, "ROM address bits 15:00")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_ROMADDR_17TO16                 = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_ROMADDR_17TO16", 18, "ROM address bits 17:16")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_DSPLPC_WRW                     = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_DSPLPC_WRW", 19, "DSP LPC Write, Read, and Wait")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_SQIF                           = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_SQIF", 20, "SQIF top level")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_SQIF_HUB_1                     = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_SQIF_HUB_1", 21, "SQIF hub 1")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_SQIF_HUB_2                     = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_SQIF_HUB_2", 22, "SQIF hub 2")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_SQIF_BUF_XP                    = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_SQIF_BUF_XP", 23, "SQIF XP buffer")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_SQIF_BUF_XD                    = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_SQIF_BUF_XD", 24, "SQIF XD buffer")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_SQIF_BUF_KP                    = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_SQIF_BUF_KP", 25, "SQIF KP buffer")
NV_MEM_DEBUG_SEL.NV_MEM_DEBUG_SELECT.NV_MEM_DEBUG_SQIF_BUF_KD                    = c_value(NV_MEM_DEBUG_SEL, "NV_MEM_DEBUG_SQIF_BUF_KD", 26, "SQIF KD buffer")
NV_MEM_ADDR_MAP_CFG_HIGH_SQIF_LOW_ROM                                            = c_enum(None, 4, "0x0-0x3FFFFF = ROM,  0x400000-0x7FFFFF = SQIF", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_HIGH_ROM_LOW_SQIF                                            = c_enum(None, 1, "0x0-0x3FFFFF = SQIF, 0x400000-0x7FFFFF = ROM", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_HIGH_SQIF_LOW_SQIF                                           = c_enum(None, 5, "0x0-0x7FFFFF = SQIF", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_HIGH_ROM_LOW_ROM                                             = c_enum(None, 0, "0x0-0x7FFFFF = ROM", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_HIGH_MASK                                                    = c_enum(None, 12, "Positive mask for high memory window selection bits", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_LOW_MASK                                                     = c_enum(None, 3, "Positive mask for low memory window selection bits", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_HIGH_ROM_MASK                                                = c_enum(None, 0, "0x400000-0x7FFFFF = ROM", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_HIGH_SQIF_MASK                                               = c_enum(None, 4, "0x400000-0x7FFFFF = SQIF", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_HIGH_RAM_MASK                                                = c_enum(None, 8, "0x400000-0x7FFFFF = RAM", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_LOW_ROM_MASK                                                 = c_enum(None, 0, "0x0-0x3FFFFF = ROM", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_LOW_SQIF_MASK                                                = c_enum(None, 1, "0x0-0x3FFFFF = SQIF", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_LOW_RAM_MASK                                                 = c_enum(None, 2, "0x0-0x3FFFFF = RAM", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_ROM_SEL                                                      = c_enum(None, 0, "ROM selection value", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_SQIF_SEL                                                     = c_enum(None, 1, "SQIF selection value", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_RAM_SEL                                                      = c_enum(None, 2, "RAM selection value", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_NOTHING_SEL                                                  = c_enum(None, 3, "No memory selection value", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")
NV_MEM_ADDR_MAP_CFG_NO_ROM_LPC_RAM                                               = c_enum(None, 15, "No ROM, LPC or RAM mapped", "NV_MEM_ADDR_MAP_CFG_ORDER_ENUM")

USB2_ENDPOINT_SELECT                                                             = c_reg(0xf790, 1, 1, 0, "RW", 6, 0, 0, 0, "usb2_per_ss", "", "Select endpoint index to configure", "", "", 0, 1, "USB2_EP_CONFIG_BYTES_RCVD_THIS_TRANSFER,USB2_EP_CONFIG_CLEAR,USB2_EP_CONFIG_DATA_SEQUENCE,USB2_EP_CONFIG_DEVICE_ADDRESS,USB2_EP_CONFIG_DEVICE_ADDRESS_READ,USB2_EP_CONFIG_ENABLES,USB2_EP_CONFIG_ENABLES_READ,USB2_EP_CONFIG_ENDPOINT_NUMBER_AND_TYPE,USB2_EP_CONFIG_ENDPOINT_NUMBER_AND_TYPE_READ,USB2_EP_CONFIG_MAX_PACKET_SIZE,USB2_EP_CONFIG_MAX_PACKET_SIZE_READ,USB2_EP_CONFIG_NUM_PACKETS_RCVD_THIS_TRANSFER,USB2_EP_CONFIG_PROTOCOL,USB2_EP_CONFIG_PROTOCOL_READ,USB2_EP_CONFIG_RX_ADD_BUFFER_SPACE,USB2_EP_CONFIG_RX_FREE_SPACE_IN_BUFFER,USB2_EP_CONFIG_RX_MMU_BUFFER_HANDLE,USB2_EP_CONFIG_RX_MMU_BUFFER_HANDLE_READ,USB2_EP_CONFIG_RX_PACKETS_PER_TRANSFER,USB2_EP_CONFIG_RX_PACKETS_PER_TRANSFER_READ,USB2_EP_CONFIG_SSID_READ,USB2_EP_CONFIG_STATUS,USB2_EP_CONFIG_TX_ISOCH_MAX_PACKETS,USB2_EP_CONFIG_TX_ISOCH_MAX_PACKETS_READ,USB2_EP_CONFIG_TX_TD_BUFFER,USB2_EP_CONFIG_TX_TD_BUFFER_READ,USB2_TX_EP_STATUS", "", 0)
USB2_ENDPOINT_SELECT.USB2_ENDPOINT_SELECT_INDEX                                  = c_bits(USB2_ENDPOINT_SELECT, 0, 4, 0x1f, 5, "RW", "Endpoint Index")
USB2_ENDPOINT_SELECT.USB2_ENDPOINT_SELECT_RX_NOT_TX                              = c_bits(USB2_ENDPOINT_SELECT, 5, 5, 0x20, 1, "RW", "1: OUT/Rx endpoints. 0: IN/Tx endpoints. ")

WATCHDOG_DELAY                                                                   = c_reg(0xf440, 1, 1, 0, "RW", 32, 65535, 0, 0, "watchdog", "", "This is the reset value for the watchdog countdown. The reset value is 0xFFFF which allows a countdown period of 8 seconds. The maximum value of 0xFFFFFFFF allows for a sleep time of around 150 hours", "", "", 0, 1, "", "", 0)
WATCHDOG_DISABLE                                                                 = c_reg(0xf442, 1, 1, 0, "RW", 16, 0, 1, 0, "watchdog", "", "Writing the 3 disable codes in sequence to this register will disable the watchdog. Writing WATCHDOG_DEBUG_CODE3 instead of WATCHDOG_DISABLE_CODE3 will set the watchdog into debug mode. Each correct code written will advance the WATCHDOG_STATUS by 1 until it reaches 3. A status of 3 indicates that the watchdog has been disabled A status of 4 indicates that the watchdog is in debug mode. If an incorrect code is written at any time, the status will revert to 0 (enabled). The watchdog will not stop counting down until all three codes have been written correctly.", "", "", 0, 1, "", "", 0)
WATCHDOG_DISABLE.WATCHDOG_DISABLE_CODE1                                          = c_enum(WATCHDOG_DISABLE, 26420, "First disable code: 0x6734", "WATCHDOG_DISABLE")
WATCHDOG_DISABLE.WATCHDOG_DISABLE_CODE2                                          = c_enum(WATCHDOG_DISABLE, 54975, "Second disable code: 0xD6BF", "WATCHDOG_DISABLE")
WATCHDOG_DISABLE.WATCHDOG_DISABLE_CODE3                                          = c_enum(WATCHDOG_DISABLE, 49950, "Third disable code: 0xC31E", "WATCHDOG_DISABLE")
WATCHDOG_DISABLE.WATCHDOG_DEBUG_CODE3                                            = c_enum(WATCHDOG_DISABLE, 15794, "Debug activation code- used after disable code1 and disable code 2: 0x3DB2", "WATCHDOG_DISABLE")
WATCHDOG_ENABLE                                                                  = c_reg(0xf443, 1, 1, 0, "RW", 1, 0, 1, 0, "watchdog", "", "Writing any value enables the watchdog regardless of its previous state and resets its state machine to 0.", "", "", 0, 1, "", "", 0)
WATCHDOG_ENABLE.WATCHDOG_ENABLE                                                  = c_bits(WATCHDOG_ENABLE, 0, 0, 0x1, 1, "RW", "")
WATCHDOG_KICK                                                                    = c_reg(0xf444, 1, 1, 0, "RW", 1, 0, 1, 0, "watchdog", "", "Writing to this register causes the countdown value to be reset to the value stored in WATCHDOG_DELAY.", "", "", 0, 1, "", "", 0)
WATCHDOG_KICK.WATCHDOG_KICK                                                      = c_bits(WATCHDOG_KICK, 0, 0, 0x1, 1, "RW", "")
WATCHDOG_KICK_PENDING                                                            = c_reg(0xf445, 1, 0, 0, "R", 1, 0, 0, 0, "watchdog", "", "This indicates that WATCHDOG_KICK has been written to recently, but has not yet been transferred to the slow clock domain to reset the countdown value.", "", "", 0, 1, "", "", 0)
WATCHDOG_KICK_PENDING.WATCHDOG_KICK_PENDING                                      = c_bits(WATCHDOG_KICK_PENDING, 0, 0, 0x1, 1, "R", "")
WATCHDOG_SLOW_KICK_PENDING                                                       = c_reg(0xf447, 1, 0, 0, "R", 1, 0, 0, 0, "watchdog", "", "This indicates that the WATCHDOG_KICK has got as far as the slow clock domain, and the countdown reset will occur on the next slow clock edge.", "", "", 0, 1, "", "", 0)
WATCHDOG_SLOW_KICK_PENDING.WATCHDOG_SLOW_KICK_PENDING                            = c_bits(WATCHDOG_SLOW_KICK_PENDING, 0, 0, 0x1, 1, "R", "")
WATCHDOG_STATUS                                                                  = c_reg(0xf446, 1, 0, 0, "R", 4, 0, 0, 0, "watchdog", "", "This indicates the current status of the enable/disable state machine. The states are: 0 - Enabled; 1 - Disable1; 2 - Disable2; 3 - Disabled; 4 - Debug mode. The watchdog is not fully disabled until it is in state 3. In addition, bit 3 is set if the watchdog has fired in debug mode.", "", "", 0, 1, "", "", 0)
WATCHDOG_STATUS.WATCHDOG_STATUS                                                  = c_bits(WATCHDOG_STATUS, 0, 3, 0xf, 4, "R", "")

