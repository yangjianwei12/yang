############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2017 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################

from csr.wheels.global_streams import iprint
from .mixins.is_qcc516x7x_qcc306x7x import IsQCC516x7x_QCC306x7x
from .apps_subsystem import AppsSubsystem
from ..core.meta.i_core_info import Kalimba32CoreInfo
from ..address_space import AddressMap, BankedAddressSpace, NullAccessCache,\
AccessView
import time


class QCC516x7x_QCC306x7xAppsSubsystem(AppsSubsystem, IsQCC516x7x_QCC306x7x):
    '''
    Class representing a QCC516x7x_QCC306x7x-flavoured Apps subsystem
    
    Note: we inherit from IsQCC516x7x_QCC306x7x on principle, but in fact the only 
    thing this gives us is _create_host_subsystem_view, which isn't useful
    because the Apps memory map has all the HIF subsystems mapped in separately.
    '''

    def __init__(self, chip, ss_id, access_cache_type):

        AppsSubsystem.__init__(self, chip, ss_id, access_cache_type)

    def safe_state(self):
        """
        Force the subsystem into a 'safe' known state. This will stop
        the subsystem running, reset it and 
        """

        # Get the Curator object to access it's registers
        cur = self.curator.core

        # Pause the Curator to prevent it altering registers
        cur.pause()

        # Put the APPS subsystem into a known state.
        # QCC512X_QCC302X needs an additional clock enable - clock sources possibly in future too
        cur.fields.CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES.CURATOR_SUBSYS_CORE_CLK_ENABLES_APPS = 1

        cur.fields['CURATOR_SUBSYSTEMS_RUN_EN'] = 0x03
        # Power cycle the APPS subsystem
        cur.fields['CURATOR_SUBSYSTEMS_POWERED'] = 0x03
        time.sleep(0.2)
        cur.fields['CURATOR_SUBSYSTEMS_POWERED'] = 0x13
        time.sleep(0.2)

    def config_sqif_pios(self, bank=0):
        """
        The firmware should request these as resources from the Curator.
        During testing it may be necessary to forcible take these PIOs
        """
        # Get the Curator object to access it's registers
        cur = self.curator.core

        STRONG_PULL_DOWN_4MA = 0x19
        STRONG_PULL_UP_4MA = 0x39
        STRONG_PULL_UP = 0x38

        # Configure the SQIF's PIOs
        # This is QCC516x7x_QCC306x7x specific
        if bank == 0:
            if cur.fw.efuse_data.fields("EFUSE_BITFIELDS_STACKED_FLASH", True)[0] == 0:
                # Set the pulls etc. suitable for SPI mode only
                cur.fields['PAD_CONTROL_SQIF_1_D0'] = STRONG_PULL_DOWN_4MA
                cur.fields['PAD_CONTROL_SQIF_1_D1'] = STRONG_PULL_DOWN_4MA
                cur.fields['PAD_CONTROL_SQIF_1_D2'] = STRONG_PULL_UP
                cur.fields['PAD_CONTROL_SQIF_1_D3'] = STRONG_PULL_UP
                cur.fields['PAD_CONTROL_SQIF_1_CLK'] = STRONG_PULL_DOWN_4MA
                cur.fields['PAD_CONTROL_SQIF_1_CS0'] = STRONG_PULL_UP_4MA

                # Configure the SQIF PIOs (SQIF1 - [9:14])
                cur.fields['CHIP_PIO9_PIO11_MUX_CONTROL'] = (cur.iodefs.IO_FUNC_SEL_SQIF_NORMAL * 0x0111)
                cur.fields['CHIP_PIO12_PIO15_MUX_CONTROL'] = (cur.iodefs.IO_FUNC_SEL_SQIF_NORMAL * 0x0111)

            else:
                # Set the pulls etc. suitable for SPI mode only
                cur.fields['PAD_CONTROL_SQIF_3_D0'] = STRONG_PULL_DOWN_4MA
                cur.fields['PAD_CONTROL_SQIF_3_D1'] = STRONG_PULL_DOWN_4MA
                cur.fields['PAD_CONTROL_SQIF_3_D2'] = STRONG_PULL_UP
                cur.fields['PAD_CONTROL_SQIF_3_D3'] = STRONG_PULL_UP
                cur.fields['PAD_CONTROL_SQIF_3_CLK'] = STRONG_PULL_DOWN_4MA
                cur.fields['PAD_CONTROL_SQIF_3_CS0'] = STRONG_PULL_UP_4MA

                # Configure the SQIF PIOs (SQIF3 - [34:39])
                cur.fields['CHIP_PIO32_PIO35_MUX_CONTROL'] = (cur.iodefs.IO_FUNC_SEL_SQIF_NORMAL * 0x1100)
                cur.fields['CHIP_PIO36_PIO39_MUX_CONTROL'] = (cur.iodefs.IO_FUNC_SEL_SQIF_NORMAL * 0x1111)

            # SQIF register clock enable, this SHOULD be unnecessary
            self.p0.fields.CLKGEN_ENABLES.CLKGEN_SQIF0_REGS_EN = 1
        else:
            raise NotImplementedError("QCC516x7x_QCC306x7x has only one Apps SQIF interface (bank0)")

    # CORE CLOCKS vaues that go into apps subsystem
    _core_clks = {
        0 : 32000.0, # Scaled
        1 : 80000.0, # PLL
        }

    def get_nr_of_processor_clocks_per_ms(self):
        """
        Nr of processor clocks per ms
        """
        cur = self.curator.core
        if (self._chip.is_emulation):
            return 20000.0
        else:
            core_clk_in_sel = int(cur.fields.CURATOR_SUBSYSTEMS_CLK_SOURCES.CURATOR_APPS_CLK_SOURCE.read())
            return self._core_clks[core_clk_in_sel]

    def get_current_subsystem_clock_mhz(self):
        # same as cpu clock on qcc512x_qcc302x
        return self.get_nr_of_processor_clocks_per_ms() / 1000.0

class QCC516x_QCC306xAppsSubsystem(QCC516x7x_QCC306x7xAppsSubsystem):

    P0_DATA_RAM_SIZE  = 48
    P1_DATA_RAM_SIZE  = 80
    SHARED_RAM_SIZE   = 64
    TCM0_SIZE         = 32
    TCM1_SIZE         = 32
    P0_CACHE_RAM_SIZE = 32
    P1_CACHE_RAM_SIZE = 32
    P0_CACHE_TAG_RAM_SIZE = 2
    P1_CACHE_TAG_RAM_SIZE = 2


    def __init__(self, chip, ss_id, access_cache_type):
        # cache the bus interrupt registers bank start address,
        # we will need it in QCC516x7x_QCC306x7xAppsSubsystem.__init__
        from csr.dev.hw.core.qcc516x7x_qcc306x7x_apps_core import QCC516x_QCC306xAppsCoreInfo
        core_info = QCC516x_QCC306xAppsCoreInfo(custom_digits=chip.emulator_build)
        if core_info.custom_io_struct:
            BUS_INT_MASK = getattr(core_info.custom_io_struct, "BUS_INT_MASK")
        else:
            # This is a temporary kludge to enable this code to work for
            # testing purposes for people (like me) who don't yet have access to
            # the QCC516x7x_QCC306x7x emulator builds area.
            try:
                from csr.dev.hw.io.qcc516x_qcc306x_apps_io_struct import BUS_INT_MASK
            except ImportError:
                iprint("WARNING: Getting BUS_INT_MASK from QCC514X_QCC304X register map while constructing Apps SS memory maps!")
                from csr.dev.hw.io.qcc514x_qcc304x_apps_d00_io_struct import BUS_INT_MASK
        self._bus_int_bank_start = BUS_INT_MASK.addr
        
        QCC516x7x_QCC306x7xAppsSubsystem.__init__(self, chip, ss_id, access_cache_type)

    @property
    def _core_types(self):
        from csr.dev.hw.core.qcc516x7x_qcc306x7x_apps_core import QCC516x_QCC306xAppsP0Core, \
        QCC516x_QCC306xAppsP1Core
        return QCC516x_QCC306xAppsP0Core, QCC516x_QCC306xAppsP1Core
    
    @property
    def sqif_trb_address_block_id(self):
        '''
        Returns a list (indexed by sqif device number) of tuples of TRB address
        and block IDs at which the SQIF contents can be read.
        See http://cognidox/vdocs/CS-333748-DC-LATEST.pdf
        '''
        return [(0xB0000000, 0), (0xD0000000, 0)]

class QCC517x_QCC307xAppsSubsystem(QCC516x7x_QCC306x7xAppsSubsystem):

    P0_DATA_RAM_SIZE  = 48
    P1_DATA_RAM_SIZE  = 256
    SHARED_RAM_SIZE   = 64
    TCM0_SIZE         = 32
    TCM1_SIZE         = 32
    P0_CACHE_RAM_SIZE = 32
    P1_CACHE_RAM_SIZE = 32
    P0_CACHE_TAG_RAM_SIZE = 2
    P1_CACHE_TAG_RAM_SIZE = 2
    
    def __init__(self, chip, ss_id, access_cache_type):
        # cache the bus interrupt registers bank start address,
        # we will need it in QCC516x7x_QCC306x7xAppsSubsystem.__init__
        from csr.dev.hw.core.qcc516x7x_qcc306x7x_apps_core import QCC517x_QCC307xAppsCoreInfo
        core_info = QCC517x_QCC307xAppsCoreInfo(custom_digits=chip.emulator_build)
        if core_info.custom_io_struct:
            BUS_INT_MASK = getattr(core_info.custom_io_struct, "BUS_INT_MASK")
        else:
            # This is a temporary kludge to enable this code to work for
            # testing purposes for people (like me) who don't yet have access to
            # the QCC516x7x_QCC306x7x emulator builds area.
            try:
                from csr.dev.hw.io.qcc517x_qcc307x_apps_io_struct import BUS_INT_MASK
            except ImportError:
                iprint("WARNING: Getting BUS_INT_MASK from QCC514X_QCC304X register map while constructing Apps SS memory maps!")
                from csr.dev.hw.io.qcc514x_qcc304x_apps_d01_io_struct import BUS_INT_MASK
        self._bus_int_bank_start = BUS_INT_MASK.addr
        
        QCC516x7x_QCC306x7xAppsSubsystem.__init__(self, chip, ss_id, access_cache_type)

    @property
    def _core_types(self):
        from csr.dev.hw.core.qcc516x7x_qcc306x7x_apps_core import QCC517x_QCC307xAppsP0Core, \
        QCC517x_QCC307xAppsP1Core
        return QCC517x_QCC307xAppsP0Core, QCC517x_QCC307xAppsP1Core

    @property
    def sqif_trb_address_block_id(self):
        '''
        Returns a list (indexed by sqif device number) of tuples of TRB address
        and block IDs at which the SQIF contents can be read.
        See http://cognidox/vdocs/CS-333748-DC-LATEST.pdf
        '''
        return [(0xB0000000, 0), (0xD0000000, 0)]



