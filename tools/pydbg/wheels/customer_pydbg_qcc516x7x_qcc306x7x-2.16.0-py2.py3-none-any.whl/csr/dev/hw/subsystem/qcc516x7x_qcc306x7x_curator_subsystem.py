############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2019 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
"""
Provides hardware specific information for curator subsystem on qcc516x7x_qcc306x7x D00 chip:
QCC516x7x_QCC306x7xCuratorSubsystem and QCC516x7x_QCC306x7xCurator1pt0Subsystem.
"""
from contextlib import contextmanager
from collections import OrderedDict
from csr.wheels.global_streams import iprint
from csr.dev.hw.sqif import SqifInterface
from csr.dev.hw.address_space import AddressSpace
from .curator_subsystem import CuratorSubsystem
from .mixins.is_qcc516x7x_qcc306x7x import IsQCC516x7x_QCC306x7x

#
# TODO This shouldn't be the same as QCC514X_QCC304X - find new values
#

class QCC516x7x_QCC306x7xCuratorSubsystem(CuratorSubsystem, IsQCC516x7x_QCC306x7x):
    """
    QCC516x7x_QCC306x7x-specific Curator functionality
    """
    def __init__(self, chip, ss_id, access_cache_type, second_gen_digits=False):
        
        CuratorSubsystem.__init__(self, chip, ss_id, access_cache_type)
        
        self._second_gen_digits = second_gen_digits

    @property
    def sqif(self):
        '''
        The represents the SQIF hardware block on the Curator subsystem,
        which is used as a ROM replacement during development.
        '''
        # Construct lazily...
        try:
            self._sqif
        except AttributeError:
            self._sqif = SqifInterface(self.core)

        return self._sqif

    @property
    def siflash(self):
        '''
        The represents the Serial flash support for ALL subsystems
        implemented in the Curator firmware using the Hydra Protocols.

        Since this is a chip wide function it is implemented now in the
        CSRA6810XChip object but this 'softlink' from the Curator Object
        is retained for backwards compatibility.
        '''
        return self.chip.siflash

    def bulk_erase(self, bank=0):
        """
        Most basic way to completely erase the Curator SQIF.

        ONlY Uses register peeks and pokes so does need to have have had
        firmware specified.

        SHOULD be able to erase a SQIF regardless of the system state.
        """

        # Get the Curator object to access it's registers
        cur = self.chip.curator_subsystem.core

        iprint ("About to erase the Curator SQIF")

        # Belt and braces Pause the XAP
        cur.pause()
        cur.fields["CURATOR_SUBSYSTEMS_RUN_EN"] = 0

        self.config_sqif_pios()
        self.sqif_clk_enable()
        self.sqif.minimal_config()
        self.sqif.bulk_erase_helper()

    def config_sqif_pios(self):
        """
        The Janitor should have configured before the Curator boots.
        During testing it may be necessary to forcible take these PIOs
        """

        # Get the Curator object to access it's registers
        cur = self.chip.curator_subsystem.core

        # Configure the SQIF PIOs (SQIF4 - [40:45])
        cur.fields['CHIP_PIO40_PIO43_MUX_CONTROL'] = (cur.iodefs.IO_FUNC_SEL_SQIF_NORMAL * 0x1111)
        cur.fields['CHIP_PIO44_PIO47_MUX_CONTROL'] = (cur.iodefs.IO_FUNC_SEL_SQIF_NORMAL * 0x0011)

        STRONG_PULL_DOWN_4MA = 0x19
        STRONG_PULL_UP_4MA = 0x39
        STRONG_PULL_UP = 0x38

        # Set the pulls etc. Settings same as janitor ROM (SPI mode)
        cur.fields['PAD_CONTROL_SQIF_4_D0'] = STRONG_PULL_DOWN_4MA
        cur.fields['PAD_CONTROL_SQIF_4_D1'] = STRONG_PULL_DOWN_4MA
        cur.fields['PAD_CONTROL_SQIF_4_D2'] = STRONG_PULL_UP
        cur.fields['PAD_CONTROL_SQIF_4_D3'] = STRONG_PULL_UP
        cur.fields['PAD_CONTROL_SQIF_4_CLK'] = STRONG_PULL_DOWN_4MA
        cur.fields['PAD_CONTROL_SQIF_4_CS0'] = STRONG_PULL_UP_4MA

    def sqif_clk_enable(self):
        """
        Enable the SQIF clock
        """

        # Get the Curator object to access its registers
        cur = self.chip.curator_subsystem.core

        # Set both clock sources to be 32MHz (XTAL or FOSC). SQIF interfaces will get the same 32MHz source
        # that is being used to clock Curator. Therefore, we can rely on Curator to manage the FOSC gate and
        # do not have to worry about that here. See CS-00416949-DD for more detail.
        cur.fields.CURATOR_SQIF_INTERFACE_CLK_SOURCES = 0
        cur.fields.CURATOR_SQIF_INTERFACE_CLK_ENABLES.SQIF_CLK_CURATOR = 1

    def _get_clock_info(self):
        # pylint: disable=too-many-locals
        cur = self.chip.curator_subsystem.core
        gen_enb_dis = ["Off", "On"]
        spll_enb_dis = ["SPLL: On", "SPLL: Off"]
        mpll_enb_dis = ["MPLL: On", "MPLL: Off"]
        spll_clocks = ["SPLL clock o/p: 48MHz:Off, 80MHz:Off, 120MHz:Off",
                       "SPLL clock o/p: 48MHz:On, 80MHz:Off, 120MHz:Off",
                       "SPLL clock o/p: 48MHz:Off, 80MHz:On, 120MHz:Off",
                       "SPLL clock o/p: 48MHz:On, 80MHz:On, 120MHz:Off",
                       "SPLL clock o/p: 48MHz:Off, 80MHz:Off, 120MHz:On ",
                       "SPLL clock o/p: 48MHz:On, 80MHz:Off, 120MHz:On",
                       "SPLL clock o/p: 48MHz:Off, 80MHz:On, 120MHz:On ",
                       "SPLL clock o/p: 48MHz:On, 80MHz:On, 120MHz:On"]
        lock_state = ["Unlocked", "Locked"]
        sqif_if_clk_src = ["FOSC", "XTAL", "PLL", "Undefined"]
        bt_clk_src = ["XTAL", "PLL", "NCO", "Undefined"]
        aud_eng_clk_src = ["AOV", "XTAL"]
        aud_cpu_clk_src = ["AOV", "XTAL", "PLL", "PLL_TURBO"]
        apps_clk_src = ["FOSC", "XTAL", "PLL", "Undefined"]
        host_clk_src = ["FOSC", "XTAL"]
        cur_clk_src = ["FOSC", "XTAL"]
        led_clk_src = ["SOSC", "Undefined", "FOSC", "XTAL"]
        xtal_sel_div = ["XTAL", "XTAL/2", "XTAL/4", "XTAL/8", "XTAL/16",
                        "XTAL/32", "Disabled", "Disabled"]
        state_descriptions = OrderedDict((
            ("gen_enb_dis", gen_enb_dis),
            ("spll_enb_dis", spll_enb_dis),
            ("mpll_enb_dis", mpll_enb_dis),
            ("spll_clocks", spll_clocks),
            ("lock_state", lock_state),
            ("sqif_if_clk_src", sqif_if_clk_src),
            ("bt_clk_src", bt_clk_src),
            ("aud_eng_clk_src", aud_eng_clk_src),
            ("aud_cpu_clk_src", aud_cpu_clk_src),
            ("apps_clk_src", apps_clk_src),
            ("host_clk_src", host_clk_src),
            ("cur_clk_src", cur_clk_src),
            ("led_clk_src", led_clk_src),
            ("xtal_sel_div", xtal_sel_div)
            ))

        # This has format "Clock Reg/Description",
        #                 ("Register", Offset, Mask, State description index)
        clocks = OrderedDict((
            ("CURATOR_SUBSYS_CORE_CLK_ENABLES_HOST",
             ("CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES", 1, 1, "gen_enb_dis")),
            ("CURATOR_SUBSYS_CORE_CLK_ENABLES_BT",
             ("CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES", 2, 1, "gen_enb_dis")),
            ("CURATOR_SUBSYS_CORE_CLK_ENABLES_AUDIO",
             ("CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES", 3, 1, "gen_enb_dis")),
            ("CURATOR_SUBSYS_CORE_CLK_ENABLES_APPS",
             ("CURATOR_SUBSYSTEMS_CORE_CLK_ENABLES", 4, 1, "gen_enb_dis")),
            ("(FORCE_)CLK_TBUS",
             ("CURATOR_SUBSYSTEMS_ANC_CLK_ENABLES", 0, 1, "gen_enb_dis")),
            ("CLK_BT_LO_TO_SS",
             ("CURATOR_SUBSYSTEMS_ANC_CLK_ENABLES", 1, 1, "gen_enb_dis")),
            ("CLK_AUDIO_ENGINE",
             ("CURATOR_SUBSYSTEMS_ANC_CLK_ENABLES", 2, 1, "gen_enb_dis")),
            ("CLK_CURATOR_SMPS",
             ("CURATOR_SUBSYSTEMS_ANC_CLK_ENABLES", 3, 1, "gen_enb_dis")),
            ("CLK_LED_CTRL",
             ("CURATOR_SUBSYSTEMS_ANC_CLK_ENABLES", 4, 1, "gen_enb_dis")),
            ("SQIF_CLK_CURATOR",
             ("CURATOR_SQIF_INTERFACE_CLK_ENABLES", 0, 1, "gen_enb_dis")),
            ("SQIF_CLK_BT",
             ("CURATOR_SQIF_INTERFACE_CLK_ENABLES", 1, 1, "gen_enb_dis")),
            ("SQIF_CLK_AUDIO",
             ("CURATOR_SQIF_INTERFACE_CLK_ENABLES", 2, 1, "gen_enb_dis")),
            ("SQIF_CLK_APPS0",
             ("CURATOR_SQIF_INTERFACE_CLK_ENABLES", 3, 1, "gen_enb_dis")),
            ("SQIF_CLK_APPS1",
             ("CURATOR_SQIF_INTERFACE_CLK_ENABLES", 4, 1, "gen_enb_dis")),
            ("AUX_ANA_XTAL_SEL_CLK (Bit 0 - Audio Ana. Clk)",
             ("AUX_ANA_CTRL1", 0, 1, "gen_enb_dis")),
            ("AUX_ANA_XTAL_SEL_CLK (Bit 1 - BT Ana. Clk)",
             ("AUX_ANA_CTRL1", 1, 1, "gen_enb_dis")),
            ("AUX_ANA_XTAL_DIG_CTRL_CURATOR_CLK_DIV_GATE_EN",
             ("AUX_ANA_XTAL_DIG_CTRL", 5, 1, "gen_enb_dis")),
            ("AUX_ANA_XTAL_SEL_DIV",
             ("AUX_ANA_CTRL8", 8, 7, "xtal_sel_div")),
            ("AUX_ANA_XTAL_DIG_CTRL_CURATOR_CLK_GATE_EN",
             ("AUX_ANA_XTAL_DIG_CTRL", 4, 1, "gen_enb_dis")),
            ("AUX_DI_XTL_SPARE (Bit 0 - CLK_DIG from XTAL)",
             ("AUX_ANA_CTRL33", 0, 1, "gen_enb_dis")),
            ("SQIF_INTERFACE0_CLK_SOURCE",
             ("CURATOR_SQIF_INTERFACE_CLK_SOURCES", 0, 3, "sqif_if_clk_src")),
            ("SQIF_INTERFACE1_CLK_SOURCE",
             ("CURATOR_SQIF_INTERFACE_CLK_SOURCES", 2, 3, "sqif_if_clk_src")),
            ("MILDRED_CHIP_CLKGEN_CTRL_CURATOR_CLK_SOURCE",
             ("MILDRED_CHIP_CLKGEN_CTRL", 1, 1, "cur_clk_src")),
            ("CURATOR_BT_SS_CLK_SOURCE",
             ("CURATOR_SUBSYSTEMS_CLK_SOURCES", 0, 3, "bt_clk_src")),
            ("CURATOR_AUDIO_ENGINE_CLK_SOURCE",
             ("CURATOR_SUBSYSTEMS_CLK_SOURCES", 2, 1, "aud_eng_clk_src")),
            ("CURATOR_AUDIO_CPU_CLK_SOURCE",
             ("CURATOR_SUBSYSTEMS_CLK_SOURCES", 3, 3, "aud_cpu_clk_src")),
            ("CURATOR_APPS_CLK_SOURCE",
             ("CURATOR_SUBSYSTEMS_CLK_SOURCES", 5, 3, "apps_clk_src")),
            ("CURATOR_HOST_CLK_SOURCE",
             ("CURATOR_SUBSYSTEMS_CLK_SOURCES", 7, 1, "host_clk_src")),
            ("CURATOR_LED_CTRL_CLK_SOURCE",
             ("CURATOR_SUBSYSTEMS_CLK_SOURCES", 8, 3, "led_clk_src")),
            ("AUX_ANA_SPLL_PD",
             ("AUX_ANA_CTRL10", 15, 1, "spll_enb_dis")),
            ("AUX_DO_SPLL_LOCK",
             ("AUX_ANA_STATUS1", 0, 1, "lock_state")),
            ("AUX_ANA_SYS_DIV_EN",
             ("AUX_ANA_CTRL19", 0, 7, "spll_clocks")),
            ("AUX_ANA_MPLL_PD",
             ("AUX_ANA_CTRL20", 15, 1, "mpll_enb_dis")),
            ("AUX_DO_MPLL_LOCK",
             ("AUX_ANA_STATUS2", 0, 1, "lock_state")),
            ("NCO_PLL_EN",
             ("NCO_PLL_EN", 0, 1, "gen_enb_dis")),
            ("NCO_PLL_STATUS_PLL_LOCKED",
             ("NCO_PLL_STATUS", 3, 1, "lock_state"))))

        # Create a report dictionary
        clock_info = OrderedDict()

        for index, clk_info in clocks.items():
            try:
                clk_state = cur.fields[clk_info[0]]
                raw_value = (int(clk_state) >> clk_info[1]) & clk_info[2]
                descr = state_descriptions.get(clk_info[3])
                clock_value = descr[raw_value]
                clock_info[index] = clock_value
            except KeyError:
                pass
        return clock_info

    def reset_reset_protection(self):
        """
        Reset the reset protection timer
        """
        import time
        # First, clear the reset timer in case it has just been triggered.
        # This is done by setting PMU_DA_RST_PROT_ARM_B high then low again.

        self.core.fields.PMU_CTRL5 |= 0x10
        time.sleep(0.001)
        self.core.fields.PMU_CTRL5 &= ~0x10
        time.sleep(0.001)

    def enable_reset_protection(self):
        """
        Enable the reset protection circuit in the PMU
        """
        #
        # We're going to enable the pmu reset protection so that the chip will
        # keep the ka system (ie janitor power) on for about 2 seconds (1 second
        # min), when we reset the chip. Otherwise the reset will turn the chip
        # off. We could wiggle the sys ctrl line to turn the chip back on,
        # but that requires the sys ctrl to work. Our chosen method only needs
        # the reset line to work (and the TRB interface).
        #
        try:
            self.reset_reset_protection()
            self.core.fields.PMU_CTRL5 |= 0x20
        except (AddressSpace.ReadFailure, AddressSpace.WriteFailure):
            # The curator may not be responsive. Don't prevent resetting
            # in that case.
            pass

    @contextmanager
    def reset_protection(self):
        """
        Context manager for reset protection circuit when
        resetting the chip.
        """
        self.enable_reset_protection()
        try:
            yield
        finally:
            self.reset_reset_protection()


    def _create_curator_core(self, access_cache_type):
        from csr.dev.hw.core.qcc516x7x_qcc306x7x_curator_core \
            import QCC516x7x_QCC306x7xCuratorCore
        core = QCC516x7x_QCC306x7xCuratorCore(self, second_gen_digits=self._second_gen_digits)
        core.populate(access_cache_type)
        return core



