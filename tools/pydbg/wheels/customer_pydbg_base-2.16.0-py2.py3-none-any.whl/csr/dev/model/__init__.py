############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2013 - 2016 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
"""
Device Debugging Resource Models

As well as composite Device Models this includes abstractions of related
resources such as FirmwareBuilds.
"""
